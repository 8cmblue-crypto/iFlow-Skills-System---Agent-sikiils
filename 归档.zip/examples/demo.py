#!/usr/bin/env python3
"""
iFlow 技能系统使用示例
演示核心功能的完整使用流程
"""

import sys
import os
import json
import time
from pathlib import Path

# 添加技能路径
sys.path.insert(0, str(Path(__file__).parent / "skills" / "command-skills"))
sys.path.insert(0, str(Path(__file__).parent / "skills" / "memory-system"))
sys.path.insert(0, str(Path(__file__).parent / "skills" / "task-coordinator"))

def example_memory_operations():
    """示例：记忆系统操作"""
    print("🧠 === 记忆系统操作示例 ===")
    
    try:
        from memory_manager import MemoryManager
        
        # 创建记忆管理器
        manager = MemoryManager()
        
        # 存储记忆
        print("1. 存储用户记忆...")
        result = manager.store_memory(
            key="user_preference_skills_loader",
            value="用户偏好使用快速技能加载器：python3 load_skills_quick.py",
            category="user_preference",
            metadata={
                "importance": "high",
                "tags": ["用户偏好", "技能加载", "快速操作"],
                "title": "技能加载方式偏好"
            }
        )
        print(f"   ✅ 存储结果: {result['status']}")
        
        # 检索记忆
        print("2. 检索用户记忆...")
        memory = manager.retrieve_memory("user_preference_skills_loader")
        if memory and memory['status'] == 'success':
            print(f"   ✅ 检索成功: {memory['data']['value'][:50]}...")
        
        # 搜索记忆
        print("3. 搜索相关记忆...")
        results = manager.search_memories("技能加载")
        print(f"   ✅ 找到 {len(results)} 条相关记忆")
        
        # 智能记忆处理
        print("4. 智能记忆处理...")
        try:
            from soulful_memory import process_conversation_with_soul
            conversation = "用户今天学习了iFlow技能系统的使用，掌握了记忆管理和任务协调功能"
            result = process_conversation_with_soul(conversation)
            print("   ✅ 情感记忆处理完成")
        except Exception as e:
            print(f"   ⚠️ 情感记忆处理跳过: {e}")
        
    except Exception as e:
        print(f"   ❌ 记忆系统操作失败: {e}")
    
    print()

def example_skills_loading():
    """示例：技能快速加载"""
    print("⚡ === 技能快速加载示例 ===")
    
    try:
        from quick_skills_loader import QuickSkillsLoader
        
        # 创建快速加载器
        loader = QuickSkillsLoader()
        
        # 加载技能
        print("1. 快速加载所有技能...")
        start_time = time.time()
        result = loader.load_skills()
        load_time = time.time() - start_time
        
        print(f"   ✅ 加载完成! 耗时: {load_time:.4f}秒")
        print(f"   📊 总技能数: {result['total_skills']}")
        print(f"   ✅ 成功: {len(result['loaded_skills'])}")
        print(f"   ⚡ 缓存命中: {result.get('cache_hit', False)}")
        
        # 显示加载的技能
        if result['loaded_skills']:
            print("2. 已加载的技能:")
            for skill in result['loaded_skills'][:3]:  # 只显示前3个
                print(f"   • {skill['skill']} v{skill['version']}")
        
        # 查看缓存状态
        print("3. 缓存状态:")
        status = loader.get_cache_status()
        print(f"   • 快速缓存有效: {'✅' if status['quick_cache_valid'] else '❌'}")
        print(f"   • 缓存文件数: {status['cache_files_count']}")
        print(f"   • 总大小: {status['total_cache_size_kb']:.2f} KB")
        
    except Exception as e:
        print(f"   ❌ 技能加载失败: {e}")
    
    print()

def example_task_coordination():
    """示例：任务协调"""
    print("🎯 === 任务协调示例 ===")
    
    try:
        # 检查配置文件
        config_file = Path(__file__).parent / "config" / "agent_host_assignment_example.json"
        if not config_file.exists():
            print("   ⚠️ 配置文件不存在，跳过任务协调示例")
            return
        
        from agent_host_assignment_manager import AgentHostAssignmentManager
        
        # 创建任务管理器
        manager = AgentHostAssignmentManager(str(config_file))
        
        # 获取分配摘要
        print("1. Agent分配状态:")
        summary = manager.get_assignment_summary()
        print(f"   • 配置主机数: {len(summary['hosts'])}")
        print(f"   • 总Agent数: {summary['total_agents']}")
        print(f"   • 浮动Agent数: {len(summary['floating_agents'])}")
        
        # 显示主机详情
        print("2. 主机配置:")
        for host in summary['hosts']:
            print(f"   • {host['name']} ({host['ip']})")
            print(f"     用户: {host['user']}")
            print(f"     Agent数: {len(host['assigned_agents'])}")
        
        # 模拟单Agent任务（不实际执行）
        print("3. 任务分配示例:")
        task_config = {
            "task": "市场分析",
            "parameters": {
                "target": "竞品分析",
                "scope": "全球市场"
            },
            "priority": "high"
        }
        
        # 找到合适的Agent
        suitable_agents = []
        for host in summary['hosts']:
            for agent in host['assigned_agents']:
                if "市场分析" in agent.get('capabilities', []):
                    suitable_agents.append(agent['agent_id'])
        
        if suitable_agents:
            print(f"   ✅ 找到合适Agent: {suitable_agents[0]}")
            print(f"   📋 任务配置: {task_config['task']}")
        else:
            print("   ⚠️ 未找到合适的Agent")
        
    except Exception as e:
        print(f"   ❌ 任务协调示例失败: {e}")
    
    print()

def example_memory_sharing():
    """示例：记忆共享"""
    print("🔄 === 记忆共享示例 ===")
    
    try:
        # 检查记忆共享文件
        memory_scripts = Path(__file__).parent / "skills" / "shared-memory"
        if not memory_scripts.exists():
            print("   ⚠️ 记忆共享模块不存在，跳过示例")
            return
        
        # 模拟记忆共享操作
        print("1. 记忆共享配置:")
        print("   • MCP协议通信")
        print("   • 跨主机记忆同步")
        print("   • 分布式记忆管理")
        
        print("2. 共享流程:")
        print("   • 启动记忆服务器")
        print("   • 客户端连接同步")
        print("   • 记忆数据传输")
        print("   • 冲突解决机制")
        
    except Exception as e:
        print(f"   ❌ 记忆共享示例失败: {e}")
    
    print()

def example_remote_control():
    """示例：远程控制"""
    print("🌐 === 远程控制示例 ===")
    
    try:
        # 检查远程控制文件
        remote_scripts = Path(__file__).parent / "skills" / "remote-control"
        if not remote_scripts.exists():
            print("   ⚠️ 远程控制模块不存在，跳过示例")
            return
        
        print("1. 远程控制功能:")
        print("   • SSH连接管理")
        print("   • 远程Agent协调")
        print("   • 跨主机任务分发")
        
        print("2. 连接配置:")
        print("   • 主机: 192.168.31.144 (用户: 林浩)")
        print("   • 主机: 192.168.31.77 (用户: linhao)")
        print("   • 协议: SSH + Python脚本")
        
    except Exception as e:
        print(f"   ❌ 远程控制示例失败: {e}")
    
    print()

def main():
    """主函数 - 运行所有示例"""
    print("🚀 iFlow 技能系统使用示例")
    print("=" * 60)
    print()
    
    # 检查发布包结构
    print("📁 检查发布包结构...")
    base_path = Path(__file__).parent
    required_dirs = ["skills", "config", "docs"]
    
    for dir_name in required_dirs:
        dir_path = base_path / dir_name
        exists = dir_path.exists()
        print(f"   • {dir_name}/: {'✅' if exists else '❌'}")
    
    print()
    
    # 运行各种示例
    example_memory_operations()
    example_skills_loading()
    example_task_coordination()
    example_memory_sharing()
    example_remote_control()
    
    print("🎉 === 示例演示完成 ===")
    print()
    print("📖 更多信息请查看:")
    print("   • README.md - 完整文档")
    print("   • QUICK_START.md - 快速开始")
    print("   • config/ - 配置文件示例")

if __name__ == "__main__":
    main()