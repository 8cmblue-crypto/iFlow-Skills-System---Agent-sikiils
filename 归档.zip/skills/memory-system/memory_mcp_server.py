#!/usr/bin/env python3
"""
MCP记忆服务器 - 将我们的记忆系统包装成真正的MCP服务
让所有iflow实例都能共享记忆
"""

import asyncio
import json
from typing import Any, Dict, List
import sys
import os

# 添加当前目录到Python路径
sys.path.append('/vol1/1000/iflow')

from mcp.server import Server
from mcp.server.models import InitializationOptions
from mcp.server.stdio import stdio_server
from mcp.types import (
    Resource,
    Tool,
    TextContent,
    ImageContent,
    EmbeddedResource,
    LoggingLevel
)

# 导入我们的记忆系统
from memory_manager import MemoryManager
from soulful_memory import process_conversation_with_soul
from memory_recall import recall_memory_agent_zero_style

class MemoryMCPServer:
    def __init__(self):
        self.server = Server("memory-mcp")
        self.memory_manager = MemoryManager()
        
        # 注册MCP工具
        self.setup_tools()
        self.setup_resources()
    
    def setup_tools(self):
        """设置MCP工具"""
        
        @self.server.list_tools()
        async def list_tools() -> List[Tool]:
            return [
                Tool(
                    name="store_memory",
                    description="存储记忆信息",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "key": {"type": "string", "description": "记忆键名"},
                            "value": {"type": "string", "description": "记忆内容"},
                            "category": {"type": "string", "description": "记忆类别", "default": "general"}
                        },
                        "required": ["key", "value"]
                    }
                ),
                Tool(
                    name="retrieve_memory",
                    description="检索记忆信息",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "key": {"type": "string", "description": "记忆键名"}
                        },
                        "required": ["key"]
                    }
                ),
                Tool(
                    name="search_memories",
                    description="搜索记忆",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "query": {"type": "string", "description": "搜索查询"},
                            "category": {"type": "string", "description": "按类别过滤"}
                        },
                        "required": ["query"]
                    }
                ),
                Tool(
                    name="process_conversation",
                    description="处理对话并自动提取记忆",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "user_input": {"type": "string", "description": "用户输入"},
                            "ai_response": {"type": "string", "description": "AI回答"}
                        },
                        "required": ["user_input"]
                    }
                ),
                Tool(
                    name="recall_memory",
                    description="智能回忆记忆",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "question": {"type": "string", "description": "问题"},
                            "context": {"type": "array", "items": {"type": "string"}, "description": "上下文历史"}
                        },
                        "required": ["question"]
                    }
                ),
                Tool(
                    name="list_all_memories",
                    description="列出所有记忆",
                    inputSchema={
                        "type": "object",
                        "properties": {}
                    }
                ),
                Tool(
                    name="delete_memory",
                    description="删除记忆",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "key": {"type": "string", "description": "记忆键名"}
                        },
                        "required": ["key"]
                    }
                )
            ]
        
        @self.server.call_tool()
        async def call_tool(name: str, arguments: Dict[str, Any]) -> List[TextContent]:
            try:
                if name == "store_memory":
                    result = self.memory_manager.store_memory(
                        key=arguments["key"],
                        value=arguments["value"],
                        category=arguments.get("category", "general")
                    )
                    return [TextContent(type="text", text=json.dumps(result, ensure_ascii=False))]
                
                elif name == "retrieve_memory":
                    memory = self.memory_manager.retrieve_memory(arguments["key"])
                    if memory:
                        return [TextContent(type="text", text=json.dumps(memory, ensure_ascii=False))]
                    else:
                        return [TextContent(type="text", text=json.dumps({"error": "记忆不存在"}, ensure_ascii=False))]
                
                elif name == "search_memories":
                    results = self.memory_manager.search_memories(
                        arguments["query"],
                        arguments.get("category")
                    )
                    return [TextContent(type="text", text=json.dumps({"results": results}, ensure_ascii=False))]
                
                elif name == "process_conversation":
                    result = process_conversation_with_soul(
                        arguments["user_input"],
                        arguments.get("ai_response")
                    )
                    return [TextContent(type="text", text=json.dumps(result, ensure_ascii=False))]
                
                elif name == "recall_memory":
                    result = recall_memory_agent_zero_style(
                        arguments["question"],
                        arguments.get("context", [])
                    )
                    return [TextContent(type="text", text=json.dumps(result, ensure_ascii=False))]
                
                elif name == "list_all_memories":
                    result = self.memory_manager.list_all_memories()
                    return [TextContent(type="text", text=json.dumps(result, ensure_ascii=False))]
                
                elif name == "delete_memory":
                    result = self.memory_manager.delete_memory(arguments["key"])
                    return [TextContent(type="text", text=json.dumps(result, ensure_ascii=False))]
                
                else:
                    return [TextContent(type="text", text=json.dumps({"error": f"未知工具: {name}"}, ensure_ascii=False))]
                    
            except Exception as e:
                return [TextContent(type="text", text=json.dumps({"error": str(e)}, ensure_ascii=False))]
    
    def setup_resources(self):
        """设置MCP资源"""
        
        @self.server.list_resources()
        async def list_resources() -> List[Resource]:
            return [
                Resource(
                    uri="memory://user_memories",
                    name="用户记忆",
                    description="所有用户记忆数据",
                    mimeType="application/json"
                ),
                Resource(
                    uri="memory://status",
                    name="记忆系统状态",
                    description="记忆系统运行状态",
                    mimeType="application/json"
                )
            ]
        
        @self.server.read_resource()
        async def read_resource(uri: str) -> str:
            if uri == "memory://user_memories":
                result = self.memory_manager.list_all_memories()
                return json.dumps(result, ensure_ascii=False)
            elif uri == "memory://status":
                status = {
                    "total_memories": self.memory_manager.list_all_memories().get('total_count', 0),
                    "memory_file": "/vol1/1000/iflow/user_memories.json",
                    "status": "running"
                }
                return json.dumps(status, ensure_ascii=False)
            else:
                raise ValueError(f"未知资源: {uri}")

async def main():
    """启动MCP服务器"""
    memory_server = MemoryMCPServer()
    
    # 使用stdio传输
    async with stdio_server() as (read_stream, write_stream):
        await memory_server.server.run(
            read_stream,
            write_stream,
            InitializationOptions(
                server_name="memory-mcp",
                server_version="1.0.0",
                capabilities=memory_server.server.get_capabilities(
                    notification_options=None,
                    experimental_capabilities=None,
                ),
            ),
        )

if __name__ == "__main__":
    asyncio.run(main())