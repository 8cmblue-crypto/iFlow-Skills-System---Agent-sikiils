#!/usr/bin/env python3
"""
简化的MCP客户端 - 直接调用记忆系统
"""

import sys
import json
sys.path.append('/vol1/1000/iflow')

from memory_manager import MemoryManager
from soulful_memory import process_conversation_with_soul
from memory_recall import recall_memory_agent_zero_style

def main():
    if len(sys.argv) < 3:
        print("用法: python3 memory_mcp_client.py <tool_name> <arguments_json>")
        return
    
    tool_name = sys.argv[1]
    try:
        arguments = json.loads(sys.argv[2])
    except json.JSONDecodeError:
        print("❌ 参数JSON格式错误")
        return
    
    # 创建记忆管理器
    manager = MemoryManager()
    
    try:
        if tool_name == "store_memory":
            result = manager.store_memory(
                key=arguments["key"],
                value=arguments["value"],
                category=arguments.get("category", "general")
            )
        
        elif tool_name == "retrieve_memory":
            memory = manager.retrieve_memory(arguments["key"])
            result = memory if memory else {"error": "记忆不存在"}
        
        elif tool_name == "search_memories":
            results = manager.search_memories(
                arguments["query"],
                arguments.get("category")
            )
            result = {"results": results}
        
        elif tool_name == "process_conversation":
            result = process_conversation_with_soul(
                arguments["user_input"],
                arguments.get("ai_response")
            )
        
        elif tool_name == "recall_memory":
            result = recall_memory_agent_zero_style(
                arguments["question"],
                arguments.get("context", [])
            )
        
        elif tool_name == "list_all_memories":
            result = manager.list_all_memories()
        
        elif tool_name == "delete_memory":
            result = manager.delete_memory(arguments["key"])
        
        else:
            result = {"error": f"未知工具: {tool_name}"}
        
        print(json.dumps(result, ensure_ascii=False))
        
    except Exception as e:
        print(json.dumps({"error": str(e)}, ensure_ascii=False))

if __name__ == "__main__":
    main()
