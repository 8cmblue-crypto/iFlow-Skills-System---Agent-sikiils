#!/usr/bin/env python3
"""
Agent Zero风格的智能记忆检索系统
使用AI生成查询、语义搜索、智能过滤
"""

import json
import re
from typing import List, Dict, Any, Optional
from memory_manager import MemoryManager

class AgentZeroStyleMemoryRecall:
    def __init__(self):
        self.memory_manager = MemoryManager()
        
        # 记忆区域定义 - 借鉴Agent Zero
        self.MemoryArea = {
            'FRAGMENTS': '对话片段和事实',
            'SOLUTIONS': '解决方案和技能', 
            'PREFERENCES': '偏好和习惯',
            'MAIN': '主要知识'
        }
        
        # 搜索配置
        self.search_config = {
            'max_search': 12,
            'max_result': 5,
            'similarity_threshold': 0.3,
            'enable_post_filter': True
        }
    
    def should_search_memory(self, question: str) -> bool:
        """判断是否应该搜索记忆 - 借鉴Agent Zero的规则"""
        
        question_lower = question.lower()
        
        # 忽略的话题 - 借鉴Agent Zero
        ignored_topics = [
            r'你好|hello|hi',
            r'天气怎么样|weather',
            r'现在几点|what time',
            r'谢谢|thank',
            r'再见|bye|goodbye'
        ]
        
        for pattern in ignored_topics:
            if re.search(pattern, question_lower):
                return False
        
        # 检查是否涉及个人信息或事实
        personal_patterns = [
            r'我.*?名字|我叫|我是谁',
            r'我.*?公司|我在.*?工作',
            r'我.*?喜欢|我.*?讨厌|我.*?习惯',
            r'我.*?会|我.*?擅长',
            r'怎么.*?称呼|叫我'
        ]
        
        for pattern in personal_patterns:
            if re.search(pattern, question_lower):
                return True
        
        # 检查是否有具体实体询问
        if any(word in question_lower for word in ['什么', '哪个', '哪里', '谁', '怎么']):
            return True
        
        return False
    
    def generate_search_query(self, question: str, context_history: List[str] = None) -> str:
        """生成搜索查询 - 模拟Agent Zero的AI生成查询"""
        
        # 如果没有上下文，直接使用问题
        if not context_history:
            return question
        
        # 简化版本的查询生成逻辑
        question_lower = question.lower()
        
        # 提取关键实体
        entities = []
        
        # 个人信息实体
        if any(word in question_lower for word in ['名字', '叫什么', '姓名']):
            entities.append('用户姓名')
        
        if any(word in question_lower for word in ['公司', '工作', '单位']):
            entities.append('工作单位')
        
        if any(word in question_lower for word in ['喜欢', '讨厌', '习惯']):
            entities.append('个人偏好')
        
        if any(word in question_lower for word in ['会', '擅长', '技能']):
            entities.append('技能能力')
        
        if any(word in question_lower for word in ['称呼', '怎么叫']):
            entities.append('称呼偏好')
        
        # 如果识别到实体，返回实体组合
        if entities:
            return ' '.join(entities)
        
        # 否则返回问题本身
        return question
    
    def search_memories_by_similarity(self, query: str) -> List[Dict[str, Any]]:
        """基于相似度搜索记忆"""
        
        all_memories = self.memory_manager.list_all_memories()
        
        if not all_memories or 'memories' not in all_memories:
            return []
        
        # 计算相似度
        scored_memories = []
        
        for key, memory in all_memories['memories'].items():
            memory_content = memory.get('value', '')
            
            # 简化的相似度计算
            similarity_score = self._calculate_similarity(query, memory_content)
            
            if similarity_score >= self.search_config['similarity_threshold']:
                scored_memories.append({
                    'key': key,
                    'content': memory_content,
                    'score': similarity_score,
                    'category': memory.get('category', 'unknown'),
                    'metadata': memory.get('metadata', {})
                })
        
        # 按相似度排序
        scored_memories.sort(key=lambda x: x['score'], reverse=True)
        
        # 限制搜索结果数量
        return scored_memories[:self.search_config['max_search']]
    
    def _calculate_similarity(self, query: str, memory: str) -> float:
        """计算查询与记忆的相似度"""
        
        query_lower = query.lower()
        memory_lower = memory.lower()
        
        # 关键词匹配
        query_words = set(query_lower.split())
        memory_words = set(memory_lower.split())
        
        if not query_words or not memory_words:
            return 0.0
        
        # Jaccard相似度
        intersection = query_words & memory_words
        union = query_words | memory_words
        
        if not union:
            return 0.0
        
        jaccard_similarity = len(intersection) / len(union)
        
        # 语义权重 - 特定词汇的权重更高
        semantic_keywords = {
            '用户': 0.3,
            '姓名': 0.3,
            '公司': 0.3,
            '工作': 0.3,
            '喜欢': 0.2,
            '讨厌': 0.2,
            '习惯': 0.2,
            '技能': 0.2,
            '称呼': 0.3
        }
        
        semantic_score = 0.0
        for keyword, weight in semantic_keywords.items():
            if keyword in query_lower and keyword in memory_lower:
                semantic_score += weight
        
        # 组合得分
        total_score = jaccard_similarity + semantic_score
        
        return min(total_score, 1.0)
    
    def filter_relevant_memories(self, memories: List[Dict[str, Any]], question: str) -> List[Dict[str, Any]]:
        """智能过滤相关记忆 - 模拟Agent Zero的AI过滤"""
        
        if not memories:
            return []
        
        # 简化版本的智能过滤
        filtered_memories = []
        question_lower = question.lower()
        
        for memory in memories:
            content = memory['content'].lower()
            
            # 相关性判断规则
            is_relevant = False
            
            # 直接关键词匹配
            if any(word in content for word in question_lower.split()):
                is_relevant = True
            
            # 语义相关性
            if '名字' in question_lower and '姓名' in content:
                is_relevant = True
            elif '公司' in question_lower and '工作' in content:
                is_relevant = True
            elif '喜欢' in question_lower and '喜欢' in content:
                is_relevant = True
            elif '技能' in question_lower and ('会' in content or '掌握' in content):
                is_relevant = True
            elif '称呼' in question_lower and ('叫' in content or '称呼' in content):
                is_relevant = True
            
            # 排除无价值的记忆
            if len(content) < 10 or content in ['用户信息', '个人偏好']:
                is_relevant = False
            
            if is_relevant:
                filtered_memories.append(memory)
        
        # 限制结果数量
        return filtered_memories[:self.search_config['max_result']]
    
    def generate_memory_response(self, question: str, memories: List[Dict[str, Any]]) -> Optional[str]:
        """生成基于记忆的自然响应"""
        
        if not memories:
            return None
        
        # 选择最相关的记忆
        best_memory = memories[0]['content']
        
        # 根据问题类型生成响应
        question_lower = question.lower()
        
        if any(word in question_lower for word in ['名字', '叫什么', '姓名']):
            return f"根据记忆，{best_memory}"
        elif any(word in question_lower for word in ['公司', '工作', '单位']):
            return f"根据记忆，{best_memory}"
        elif any(word in question_lower for word in ['喜欢', '讨厌', '习惯']):
            return f"根据记忆，{best_memory}"
        elif any(word in question_lower for word in ['会', '擅长', '技能']):
            return f"根据记忆，{best_memory}"
        elif any(word in question_lower for word in ['称呼', '怎么叫']):
            return f"根据记忆，{best_memory}"
        else:
            return f"根据记忆，{best_memory}"
    
    def process_question_with_agent_zero_style(self, question: str, context_history: List[str] = None) -> Dict[str, Any]:
        """使用Agent Zero风格处理问题"""
        
        # 1. 判断是否应该搜索记忆
        if not self.should_search_memory(question):
            return {
                "use_memory": False,
                "memory_response": None,
                "reason": "问题不需要记忆搜索",
                "search_performed": False
            }
        
        # 2. 生成搜索查询
        search_query = self.generate_search_query(question, context_history)
        
        # 如果查询为空或只有破折号，不搜索
        if not search_query or search_query.strip() == '-':
            return {
                "use_memory": False,
                "memory_response": None,
                "reason": "没有生成有效的搜索查询",
                "search_performed": True
            }
        
        # 3. 执行相似度搜索
        searched_memories = self.search_memories_by_similarity(search_query)
        
        if not searched_memories:
            return {
                "use_memory": False,
                "memory_response": None,
                "reason": "没有找到匹配的记忆",
                "search_performed": True,
                "search_query": search_query
            }
        
        # 4. 智能过滤
        if self.search_config['enable_post_filter']:
            relevant_memories = self.filter_relevant_memories(searched_memories, question)
        else:
            relevant_memories = searched_memories[:self.search_config['max_result']]
        
        if not relevant_memories:
            return {
                "use_memory": False,
                "memory_response": None,
                "reason": "没有找到相关的记忆",
                "search_performed": True,
                "search_query": search_query,
                "searched_count": len(searched_memories)
            }
        
        # 5. 生成响应
        memory_response = self.generate_memory_response(question, relevant_memories)
        
        return {
            "use_memory": True,
            "memory_response": memory_response,
            "reason": f"找到{len(relevant_memories)}条相关记忆",
            "search_performed": True,
            "search_query": search_query,
            "searched_count": len(searched_memories),
            "relevant_count": len(relevant_memories),
            "relevant_memories": [mem['content'] for mem in relevant_memories]
        }

# 全局Agent Zero风格记忆检索实例
agent_zero_memory_recall = AgentZeroStyleMemoryRecall()

def recall_memory_agent_zero_style(question: str, context_history: List[str] = None) -> Dict[str, Any]:
    """使用Agent Zero风格回忆记忆 - 主要接口"""
    return agent_zero_memory_recall.process_question_with_agent_zero_style(question, context_history)

if __name__ == "__main__":
    # 测试Agent Zero风格的记忆检索
    print("=== Agent Zero风格记忆检索测试 ===\n")
    
    # 添加一些测试记忆
    from soulful_memory import process_conversation_with_soul
    
    test_conversations = [
        ("我叫林浩，在浙江尚纬电商工作", "很高兴认识您！"),
        ("我喜欢被叫做浩哥", "好的，浩哥！"),
        ("我会Python和机器学习", "这些都是很实用的技能"),
        ("我喜欢跑步和阅读", "很好的兴趣爱好")
    ]
    
    print("📝 添加测试记忆...")
    for user_input, ai_response in test_conversations:
        result = process_conversation_with_soul(user_input, ai_response)
        print(f"  - {result['message']}")
    
    print("\n🧠 测试Agent Zero风格记忆检索...")
    
    test_questions = [
        "我叫什么名字？",
        "我在哪里工作？", 
        "我应该怎么称呼自己？",
        "我有什么技能？",
        "今天天气怎么样？",
        "你好"
    ]
    
    for question in test_questions:
        print(f"\n问题: {question}")
        
        result = recall_memory_agent_zero_style(question)
        
        if result['use_memory']:
            print(f"🎯 记忆回答: {result['memory_response']}")
            print(f"📊 搜索查询: {result.get('search_query', 'N/A')}")
            print(f"📈 搜索结果: {result.get('searched_count', 0)} -> {result.get('relevant_count', 0)}")
        else:
            print(f"❌ 无记忆: {result['reason']}")
            if result.get('search_performed'):
                print(f"🔍 搜索查询: {result.get('search_query', 'N/A')}")

if __name__ == "__main__":
    # 测试记忆回忆系统
    print("=== 智能记忆回忆测试 ===\n")
    
    # 首先添加一些测试记忆
    test_conversations = [
        ("我叫林浩，在浙江尚纬电商工作", "很高兴认识您！"),
        ("我喜欢被叫做浩哥", "好的，浩哥！"),
        ("我会Python和机器学习", "这些都是很实用的技能"),
        ("我喜欢跑步和阅读", "很好的兴趣爱好")
    ]
    
    print("📝 添加测试记忆...")
    for user_input, ai_response in test_conversations:
        result = process_conversation_with_soul(user_input, ai_response)
        print(f"  - {result['message']}")
    
    print("\n🧠 测试记忆回忆...")
    
    test_questions = [
        "我叫什么名字？",
        "我在哪里工作？",
        "我应该怎么称呼自己？",
        "我会什么技能？",
        "今天天气怎么样？"
    ]
    
    for question in test_questions:
        print(f"\n问题: {question}")
        
        result = recall_memory_agent_zero_style(question)
        
        if result['use_memory']:
            print(f"🎯 记忆回答: {result['memory_response']}")
            print(f"📊 原因: {result['reason']}")
        else:
            print(f"❌ 无记忆: {result['reason']}")