#!/usr/bin/env python3
"""
记忆系统启动器 - 在新的iflow会话中自动加载记忆系统
确保每次启动时都能正确记忆和回忆
"""

import os
import sys
from datetime import datetime

def initialize_memory_system():
    """初始化记忆系统"""
    print("🧠 正在初始化iFlow记忆系统...")
    
    # 检查记忆文件是否存在
    memory_file = "/vol1/1000/iflow/user_memories.json"
    if not os.path.exists(memory_file):
        print("⚠️ 记忆文件不存在，创建新的记忆系统")
        return False
    
    # 加载记忆系统组件
    try:
        from memory_manager import MemoryManager
        from soulful_memory import process_conversation_with_soul
        from memory_recall import recall_memory_agent_zero_style
        from intelligent_memory_system import process_conversation_intelligently, generate_intelligent_response
        
        print("✅ 记忆系统组件加载成功")
        
        # 检查关键记忆
        manager = MemoryManager()
        all_memories = manager.list_all_memories()
        
        if all_memories.get('total_count', 0) > 0:
            print(f"📊 已加载 {all_memories['total_count']} 条记忆")
            
            # 检查用户偏好
            preferred_name = manager.retrieve_memory("preferred_name_final")
            if preferred_name:
                print(f"👤 用户偏好称呼: {preferred_name['data']['value']}")
            
            # 检查用户姓名
            name_note = manager.retrieve_memory("name_preference_note_2025")
            if name_note:
                print(f"📝 用户信息: {name_note['data']['value'][:50]}...")
            
            return True
        else:
            print("📭 记忆系统为空")
            return False
            
    except Exception as e:
        print(f"❌ 记忆系统初始化失败: {e}")
        return False

def get_memory_status():
    """获取记忆系统状态"""
    try:
        from memory_manager import MemoryManager
        from intelligent_memory_system import get_memory_system_status
        
        manager = MemoryManager()
        status = get_memory_system_status()
        
        return {
            "initialized": True,
            "total_memories": manager.list_all_memories().get('total_count', 0),
            "system_status": status,
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        return {
            "initialized": False,
            "error": str(e),
            "timestamp": datetime.now().isoformat()
        }

def test_memory_system():
    """测试记忆系统功能"""
    print("\n🧪 测试记忆系统功能...")
    
    try:
        from memory_recall import recall_memory_agent_zero_style
        
        # 测试记忆回忆
        test_questions = [
            "我应该怎么称呼自己？",
            "我叫什么名字？"
        ]
        
        for question in test_questions:
            print(f"\n❓ 测试问题: {question}")
            result = recall_memory_agent_zero_style(question)
            
            if result['use_memory']:
                print(f"✅ 记忆回答: {result['memory_response']}")
            else:
                print(f"❌ 无记忆: {result['reason']}")
        
        return True
        
    except Exception as e:
        print(f"❌ 记忆系统测试失败: {e}")
        return False

def main():
    """主函数 - 记忆系统启动流程"""
    print("=" * 50)
    print("🚀 iFlow记忆系统启动器")
    print("=" * 50)
    
    # 1. 初始化记忆系统
    if not initialize_memory_system():
        print("❌ 记忆系统初始化失败")
        return False
    
    # 2. 获取记忆状态
    status = get_memory_status()
    print(f"\n📊 记忆系统状态: {status}")
    
    # 3. 测试记忆功能
    if not test_memory_system():
        print("❌ 记忆系统测试失败")
        return False
    
    print("\n✅ 记忆系统启动完成，可以正常使用！")
    return True

# 导出主要函数供外部调用
def load_memory_system():
    """加载记忆系统 - 供外部调用"""
    return initialize_memory_system()

def check_memory_status():
    """检查记忆状态 - 供外部调用"""
    return get_memory_status()

if __name__ == "__main__":
    main()