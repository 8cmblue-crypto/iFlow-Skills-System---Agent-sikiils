#!/usr/bin/env python3
"""
记忆系统详细分析器
"""

import json
from datetime import datetime
from collections import defaultdict

def analyze_memories():
    """详细分析记忆内容"""
    
    # 读取记忆文件
    try:
        with open('user_memories.json', 'r', encoding='utf-8') as f:
            memories = json.load(f)
    except FileNotFoundError:
        print("❌ 记忆文件不存在")
        return
    
    print("🧠 iFlow记忆系统详细分析报告")
    print("=" * 60)
    print(f"📊 总记忆数量: {len(memories)} 条")
    print(f"📅 分析时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print()
    
    # 按类别分组
    categories = defaultdict(list)
    for key, memory in memories.items():
        categories[memory['category']].append({
            'key': key,
            'value': memory['value'],
            'created_at': memory['created_at'],
            'metadata': memory.get('metadata', {})
        })
    
    # 显示各类别记忆
    print("📋 记忆类别统计:")
    print("-" * 40)
    for category, items in sorted(categories.items()):
        print(f"🔸 {category}: {len(items)} 条")
    
    print("\n" + "=" * 60)
    print("📝 详细记忆内容:")
    
    # 重要记忆优先显示
    priority_categories = ['user_preference', 'technical', 'personal']
    
    for category in priority_categories:
        if category in categories:
            print(f"\n🎯 {category.upper()} ({len(categories[category])} 条):")
            print("-" * 50)
            
            for i, item in enumerate(categories[category][:10], 1):  # 只显示前10条
                created_time = item['created_at'][:19]  # 只显示到秒
                value = item['value']
                if len(value) > 80:
                    value = value[:80] + "..."
                
                print(f"  {i:2d}. [{created_time}] {value}")
                
                # 显示重要元数据
                metadata = item.get('metadata', {})
                if metadata:
                    if 'importance' in metadata:
                        print(f"      重要性: {metadata['importance']}")
                    if 'type' in metadata:
                        print(f"      类型: {metadata['type']}")
            
            if len(categories[category]) > 10:
                print(f"      ... 还有 {len(categories[category]) - 10} 条记忆")
    
    # 其他类别
    other_categories = [cat for cat in categories.keys() if cat not in priority_categories]
    for category in sorted(other_categories):
        print(f"\n📌 {category.upper()} ({len(categories[category])} 条):")
        print("-" * 30)
        
        # 只显示几个示例
        for i, item in enumerate(categories[category][:3], 1):
            value = item['value']
            if len(value) > 60:
                value = value[:60] + "..."
            print(f"  {i}. {value}")
        
        if len(categories[category]) > 3:
            print(f"  ... 还有 {len(categories[category]) - 3} 条")
    
    # 记忆提取方式分析
    print(f"\n" + "=" * 60)
    print("🔍 记忆提取方式分析:")
    
    extraction_methods = defaultdict(int)
    for item in memories.values():
        metadata = item.get('metadata', {})
        if 'auto_extracted' in metadata:
            extraction_methods['自动提取'] += 1
        elif 'smart_extracted' in metadata:
            extraction_methods['智能提取'] += 1
        elif 'extraction_method' in metadata:
            method = metadata['extraction_method']
            extraction_methods[method] += 1
        else:
            extraction_methods['手动存储'] += 1
    
    for method, count in extraction_methods.items():
        print(f"  • {method}: {count} 条")
    
    # 最新记忆
    print(f"\n" + "=" * 60)
    print("🕐 最新5条记忆:")
    
    latest_memories = sorted(
        [(key, mem) for key, mem in memories.items()],
        key=lambda x: x[1]['created_at'],
        reverse=True
    )[:5]
    
    for i, (key, mem) in enumerate(latest_memories, 1):
        created_time = mem['created_at'][:19]
        category = mem['category']
        value = mem['value'][:60] + "..." if len(mem['value']) > 60 else mem['value']
        print(f"  {i}. [{created_time}] {category}: {value}")
    
    print(f"\n🎉 记忆分析完成！")

if __name__ == "__main__":
    analyze_memories()