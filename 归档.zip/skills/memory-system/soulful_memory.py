#!/usr/bin/env python3
"""
有灵魂的记忆系统 - 借鉴Agent Zero的记忆实现
记住完整的故事，而不是冷冰冰的标签
"""

import json
import re
from datetime import datetime
from typing import List, Dict, Any
from memory_manager import MemoryManager

class SoulfulMemory:
    def __init__(self):
        self.memory_manager = MemoryManager()
        
        # 记忆类型定义
        self.MemoryArea = {
            'FRAGMENTS': '对话片段和事实',
            'SOLUTIONS': '解决方案和技能', 
            'PREFERENCES': '偏好和习惯',
            'RELATIONSHIPS': '关系和互动'
        }
    
    def extract_memories_from_conversation(self, user_input: str, ai_response: str = None) -> List[str]:
        """从对话中提取有价值的记忆 - 借鉴Agent Zero的智能提取"""
        
        # 构建完整的对话上下文
        conversation_context = f"用户: {user_input}"
        if ai_response:
            conversation_context += f"\n助手: {ai_response}"
        
        # 智能提取规则 - 基于Agent Zero的原则
        extraction_patterns = {
            # 个人身份信息
            'personal_identity': [
                r'我叫([^，。！？\s]+)',
                r'我的名字是([^，。！？\s]+)',
                r'我是([^，。！？\s]+)(?=的|$|[，。！？])',
            ],
            
            # 工作和专业信息
            'work_info': [
                r'我在([^，。！？\s]+)工作',
                r'我的公司是([^，。！？\s]+)',
                r'我是([^，。！？\s]*(?:工程师|架构师|经理|总监|开发者|设计师))',
                r'我(?:做|担任|从事)([^，。！？\s]+)',
            ],
            
            # 偏好和习惯
            'preferences': [
                r'我喜欢([^，。！？\s]+)',
                r'我讨厌([^，。！？\s]+)',
                r'我习惯([^，。！？\s]+)',
                r'我(?:希望|想要)([^，。！？\s]+)',
            ],
            
            # 称呼偏好
            'name_preference': [
                r'(?:请|希望|喜欢)(?:叫我|称呼我)([^，。！？\s]+)',
                r'叫我([^，。！？\s]+)吧',
            ],
            
            # 技能和能力
            'skills': [
                r'我会([^，。！？\s]+)',
                r'我擅长([^，。！？\s]+)',
                r'我能([^，。！？\s]+)',
            ],
        }
        
        extracted_memories = []
        
        # 应用提取规则
        for category, patterns in extraction_patterns.items():
            for pattern in patterns:
                matches = re.finditer(pattern, user_input)
                for match in matches:
                    raw_value = match.group(1).strip()
                    
                    # 构建有温度的记忆描述
                    memory_text = self._craft_meaningful_memory(raw_value, category, user_input)
                    
                    if memory_text and self._is_valuable_memory(memory_text):
                        extracted_memories.append(memory_text)
        
        # 智能合并相关记忆
        merged_memories = self._merge_related_memories(extracted_memories)
        
        return merged_memories
    
    def _craft_meaningful_memory(self, value: str, category: str, original_context: str) -> str:
        """构建有温度的记忆描述"""
        
        # 根据类别构建不同的记忆描述
        if category == 'personal_identity':
            return f"用户的姓名是{value}"
            
        elif category == 'work_info':
            # 判断是否包含职位信息
            if any(job in original_context for job in ['工程师', '架构师', '经理', '总监', '开发者', '设计师']):
                return f"用户在{value}工作，从事技术相关工作"
            else:
                return f"用户在{value}工作"
                
        elif category == 'preferences':
            if '喜欢' in original_context:
                return f"用户喜欢{value}，这是用户的兴趣爱好"
            elif '讨厌' in original_context:
                return f"用户讨厌{value}，这是用户的偏好"
            elif '习惯' in original_context:
                return f"用户习惯{value}，这是用户的生活习惯"
                
        elif category == 'name_preference':
            return f"用户希望被称为{value}，这是用户的称呼偏好"
            
        elif category == 'skills':
            return f"用户掌握{value}技能，这是用户的专业能力"
        
        return None
    
    def _is_valuable_memory(self, memory_text: str) -> bool:
        """判断记忆是否有价值 - 借鉴Agent Zero的过滤规则"""
        
        # 排除无价值内容
        if not memory_text or len(memory_text) < 5:
            return False
            
        # 排除疑问句
        if any(char in memory_text for char in ['？', '?']):
            return False
            
        # 排除无意义词汇
        meaningless_patterns = [
            r'什么.*?公司',
            r'怎么.*?称呼',
            r'哪里.*?工作',
            r'不知道',
            r'不清楚',
            r'忘了',
            r'不记得'
        ]
        
        for pattern in meaningless_patterns:
            if re.search(pattern, memory_text):
                return False
        
        return True
    
    def _merge_related_memories(self, memories: List[str]) -> List[str]:
        """智能合并相关记忆 - 避免碎片化"""
        
        if len(memories) <= 1:
            return memories
        
        merged = []
        used_indices = set()
        
        for i, memory1 in enumerate(memories):
            if i in used_indices:
                continue
                
            # 查找相关记忆进行合并
            related_memories = [memory1]
            related_indices = {i}
            
            for j, memory2 in enumerate(memories):
                if j != i and j not in used_indices:
                    if self._are_memories_related(memory1, memory2):
                        related_memories.append(memory2)
                        related_indices.add(j)
            
            # 合并相关记忆
            if len(related_memories) > 1:
                merged_memory = self._merge_memory_group(related_memories)
                merged.append(merged_memory)
                used_indices.update(related_indices)
            else:
                merged.append(memory1)
                used_indices.add(i)
        
        return merged
    
    def _are_memories_related(self, memory1: str, memory2: str) -> bool:
        """判断两个记忆是否相关"""
        
        # 提取关键实体
        entities1 = set(re.findall(r'用户(?:的姓名是|在|喜欢|讨厌|习惯|希望被称为|掌握)([^，。！？\s]+)', memory1))
        entities2 = set(re.findall(r'用户(?:的姓名是|在|喜欢|讨厌|习惯|希望被称为|掌握)([^，。！？\s]+)', memory2))
        
        # 如果有共同实体，则相关
        return bool(entities1 & entities2)
    
    def _merge_memory_group(self, memories: List[str]) -> str:
        """合并一组相关的记忆"""
        
        # 按类型合并
        identity_info = []
        work_info = [] 
        preference_info = []
        skill_info = []
        
        for memory in memories:
            if '姓名是' in memory:
                identity_info.append(memory)
            elif '在' in memory and '工作' in memory:
                work_info.append(memory)
            elif any(word in memory for word in ['喜欢', '讨厌', '习惯', '希望被称为']):
                preference_info.append(memory)
            elif '掌握' in memory:
                skill_info.append(memory)
        
        # 构建合并后的记忆
        merged_parts = []
        
        if identity_info:
            merged_parts.extend(identity_info)
            
        if work_info:
            merged_parts.extend(work_info)
            
        if preference_info:
            merged_parts.extend(preference_info)
            
        if skill_info:
            merged_parts.extend(skill_info)
        
        # 用逗号连接，形成完整描述
        return '，'.join(merged_parts)
    
    def store_memories(self, memories: List[str]) -> Dict[str, Any]:
        """存储记忆到记忆管理系统"""
        
        stored_count = 0
        results = []
        
        for memory in memories:
            # 检查是否已存在相似记忆
            existing = self.memory_manager.search_memories(memory)
            if existing:
                continue
            
            # 确定记忆区域
            area = self._determine_memory_area(memory)
            
            # 生成唯一键
            timestamp = datetime.now().strftime('%H%M%S')
            key = f"soulful_{area.lower()}_{timestamp}"
            
            # 存储记忆
            result = self.memory_manager.store_memory(
                key=key,
                value=memory,
                category=area,
                metadata={
                    "extraction_method": "soulful_memory",
                    "timestamp": datetime.now().isoformat(),
                    "memory_type": "intelligent_extraction"
                }
            )
            
            if result['status'] == 'success':
                stored_count += 1
                results.append(memory)
        
        return {
            "stored_count": stored_count,
            "memories": results,
            "total_extracted": len(memories)
        }
    
    def _determine_memory_area(self, memory: str) -> str:
        """确定记忆所属区域"""
        
        if any(word in memory for word in ['姓名是', '叫']):
            return 'FRAGMENTS'
        elif any(word in memory for word in ['工作', '从事']):
            return 'FRAGMENTS'
        elif any(word in memory for word in ['喜欢', '讨厌', '习惯', '希望被称为']):
            return 'PREFERENCES'
        elif any(word in memory for word in ['掌握', '擅长', '会']):
            return 'SKILLS'
        else:
            return 'FRAGMENTS'
    
    def process_conversation(self, user_input: str, ai_response: str = None) -> Dict[str, Any]:
        """处理一次对话，提取并存储有价值的记忆"""
        
        # 1. 提取记忆
        extracted_memories = self.extract_memories_from_conversation(user_input, ai_response)
        
        if not extracted_memories:
            return {
                "processed": True,
                "memories_found": 0,
                "memories_stored": 0,
                "message": "本次对话中没有发现值得记忆的信息"
            }
        
        # 2. 存储记忆
        storage_result = self.store_memories(extracted_memories)
        
        return {
            "processed": True,
            "memories_found": len(extracted_memories),
            "memories_stored": storage_result['stored_count'],
            "extracted_memories": extracted_memories,
            "stored_memories": storage_result['memories'],
            "message": f"成功提取并存储了{storage_result['stored_count']}条有价值的记忆"
        }

# 全局有灵魂的记忆实例
soulful_memory = SoulfulMemory()

def process_conversation_with_soul(user_input: str, ai_response: str = None) -> Dict[str, Any]:
    """处理对话并提取有灵魂的记忆 - 主要接口"""
    return soulful_memory.process_conversation(user_input, ai_response)

if __name__ == "__main__":
    # 测试有灵魂的记忆系统
    print("=== 有灵魂的记忆系统测试 ===\n")
    
    test_conversations = [
        ("我叫王伟，在阿里云做架构师", "很高兴认识您，王伟！"),
        ("我喜欢跑步和阅读，讨厌熬夜", "跑步和阅读都是很好的习惯"),
        ("请叫我伟哥吧", "好的，伟哥！"),
        ("我会Python和Go语言", "这些都是很实用的编程语言"),
        ("今天天气怎么样？", "抱歉，我无法获取实时天气信息"),
        ("我什么公司来着？", "您之前提到在阿里云工作")
    ]
    
    for user_input, ai_response in test_conversations:
        print(f"用户: {user_input}")
        if ai_response:
            print(f"助手: {ai_response}")
        
        result = process_conversation_with_soul(user_input, ai_response)
        
        print(f"🧠 记忆处理: {result['message']}")
        
        if result['memories_found'] > 0:
            print("📝 提取的记忆:")
            for memory in result['extracted_memories']:
                print(f"  - {memory}")
        
        print("-" * 50)
