#!/usr/bin/env python3
"""
智能记忆检索系统 - 根据问题内容自动检索相关记忆
"""

import json
import re
from datetime import datetime

class SmartMemorySearch:
    def __init__(self):
        self.memory_file = "/vol1/1000/iflow/user_memories.json"
        self.memories = {}
        self.load_memories()
    
    def load_memories(self):
        """加载所有记忆"""
        try:
            with open(self.memory_file, 'r', encoding='utf-8') as f:
                self.memories = json.load(f)
        except Exception:
            self.memories = {}
    
    def search_relevant_memories(self, question):
        """根据问题智能检索相关记忆"""
        question_lower = question.lower()
        relevant_memories = []
        
        # 关键词映射
        keyword_patterns = {
            # 称呼相关
            'name_patterns': ['名字', '叫什么', '称呼', '怎么叫', '姓名'],
            # 公司相关  
            'company_patterns': ['公司', '工作', '单位', '企业', '老板'],
            # 偏好相关
            'preference_patterns': ['喜欢', '讨厌', '偏好', '习惯', '爱好'],
            # 个人信息
            'personal_patterns': ['我', '自己', '我的', '个人'],
        }
        
        # 检索相关记忆
        for key, memory in self.memories.items():
            value = memory.get("value", "").lower()
            relevance_score = 0
            
            # 计算相关性分数
            for category, patterns in keyword_patterns.items():
                for pattern in patterns:
                    if pattern in question_lower and any(p in value for p in patterns):
                        relevance_score += 3
                    elif pattern in question_lower:
                        relevance_score += 1
                    elif any(p in value for p in patterns):
                        relevance_score += 1
            
            # 直接关键词匹配
            if any(word in question_lower for word in value.split()):
                relevance_score += 2
            
            if relevance_score > 0:
                relevant_memories.append({
                    "content": memory.get("value"),
                    "score": relevance_score,
                    "category": memory.get("category"),
                    "created_at": memory.get("created_at")
                })
        
        # 按相关性排序
        relevant_memories.sort(key=lambda x: x["score"], reverse=True)
        return relevant_memories[:3]  # 返回最相关的3条
    
    def get_memory_context(self, question):
        """获取问题的记忆上下文"""
        relevant = self.search_relevant_memories(question)
        
        if not relevant:
            return None
        
        context = "🧠 相关记忆:\n"
        for i, mem in enumerate(relevant, 1):
            context += f"{i}. {mem['content']}\n"
        
        return context

# 全局实例
memory_search = SmartMemorySearch()

def search_memory_for_question(question):
    """为问题检索相关记忆"""
    return memory_search.get_memory_context(question)

if __name__ == "__main__":
    # 测试
    test_questions = [
        "我应该怎么称呼你？",
        "我的公司是做什么的？", 
        "我喜欢什么？",
        "今天天气怎么样？"
    ]
    
    for q in test_questions:
        print(f"问题: {q}")
        result = search_memory_for_question(q)
        if result:
            print(result)
        else:
            print("无相关记忆")
        print("-" * 30)
