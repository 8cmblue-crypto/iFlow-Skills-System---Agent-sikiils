---
name: shared-memory-system
version: 1.0.0
description: >
智能记忆共享系统，为AI Agent提供跨会话、跨实例的记忆能力。
支持用户个人信息、偏好、技能、工作信息的持久化存储和智能检索。
当需要记住用户信息、回忆历史对话、或提供个性化回答时使用此技能。
适用于任何需要记忆功能的AI Agent实例。

author: 林浩 <老大@iflow.com>
license: MIT
tags: [memory, personalization, user-profile, cross-session]
allowed_tools: [bash, python3]
required_context: []
---

# 智能记忆共享系统

## 概述
这是一个基于Agent Skills规范的智能记忆系统，允许AI Agent跨会话、跨实例共享记忆。系统采用Agent Zero风格的智能检索，提供有温度的记忆存储和自然的回忆体验。

## 核心功能
- **智能记忆提取**: 从对话中自动提取有价值的个人信息
- **Agent Zero风格检索**: 基于语义相似度的智能回忆
- **跨实例共享**: 所有iflow实例共享同一记忆库
- **有温度记忆**: 自然语言描述，避免冷冰冰的标签

## 前置条件
- Python 3.11+ 环境
- 记忆文件路径: `/vol1/1000/iflow/user_memories.json`
- 依赖模块: memory_manager.py, soulful_memory.py, memory_recall.py

## 工作流程

### 1. 记忆存储流程
```python
# 处理对话并提取记忆
from soulful_memory import process_conversation_with_soul
result = process_conversation_with_soul(user_input, ai_response)
```

### 2. 记忆检索流程
```python
# 智能回忆记忆
from memory_recall import recall_memory_agent_zero_style
result = recall_memory_agent_zero_style(question)
```

### 3. 完整集成流程
```python
# 使用集成系统
from intelligent_memory_system import process_conversation_intelligently, generate_intelligent_response

# 处理对话
memory_result = process_conversation_intelligently(user_input, ai_response)

# 生成记忆增强回答
response_result = generate_intelligent_response(question, planned_response)
```

## 使用场景

### 个人信息管理
- 用户姓名、称呼偏好
- 工作单位、职位信息
- 联系方式、地址

### 偏好习惯记录
- 兴趣爱好
- 喜欢/讨厌的事物
- 生活习惯

### 技能能力跟踪
- 专业技能
- 工具使用能力
- 语言能力

### 技术信息存储
- 脚本使用方法
- 配置信息
- 工作流程

## 最佳实践

### 1. 记忆提取原则
- 只记录完整、有价值的信息
- 避免记录疑问句、天气等临时信息
- 合并相关信息，避免碎片化

### 2. 智能检索策略
- 使用Agent Zero风格的语义搜索
- 基于相似度阈值过滤
- AI二次验证相关性

### 3. 跨实例同步
- 所有实例共享同一JSON文件
- 实时读写，无需额外同步机制
- 支持并发访问

## 示例用法

### 基础记忆操作
```bash
# 存储记忆
python3 memory_mcp_client.py store_memory '{"key": "user_name", "value": "林浩", "category": "personal"}'

# 检索记忆
python3 memory_mcp_client.py retrieve_memory '{"key": "user_name"}'

# 搜索记忆
python3 memory_mcp_client.py search_memories '{"query": "工作单位"}'
```

### 智能对话处理
```bash
# 处理对话并自动提取记忆
python3 memory_mcp_client.py process_conversation '{"user_input": "我叫张三，在阿里工作"}'

# 智能回忆记忆
python3 memory_mcp_client.py recall_memory '{"question": "我叫什么名字？"}'
```

### 集成到AI Agent
```python
from memory_mcp_client import SharedMemoryClient

client = SharedMemoryClient()

# 在对话中使用
def process_user_message(message):
    # 1. 检查是否需要回忆记忆
    memory_result = client.recall_memory(message)
    
    if memory_result["use_memory"]:
        return memory_result["memory_response"]
    
    # 2. 生成正常回答
    response = generate_normal_response(message)
    
    # 3. 处理对话并提取新记忆
    client.process_conversation(message, response)
    
    return response
```

## 故障排查

### 常见问题

**Q: 记忆文件不存在**
A: 系统会自动创建记忆文件，无需手动创建

**Q: 记忆检索不准确**
A: 检查相似度阈值设置，可调整search_config中的similarity_threshold

**Q: 跨实例记忆不同步**
A: 确保所有实例使用相同的记忆文件路径

**Q: 记忆提取过于频繁**
A: 调整should_search_memory的触发条件，避免无意义对话触发记忆

### 调试方法
```bash
# 查看记忆状态
python3 memory_system_launcher.py

# 查看所有记忆
python3 memory_mcp_client.py list_all_memories '{}'

# 测试记忆功能
python3 memory_usage_guide.py
```

## 技术架构

### 核心组件
- **memory_manager.py**: 基础记忆存储和检索
- **soulful_memory.py**: 有温度的记忆提取
- **memory_recall.py**: Agent Zero风格智能检索
- **intelligent_memory_system.py**: 完整集成系统

### 数据格式
```json
{
  "key": {
    "value": "记忆内容",
    "category": "记忆类别",
    "created_at": "创建时间",
    "metadata": {}
  }
}
```

### 记忆分类
- **user_preference**: 用户偏好信息
- **personal**: 个人信息
- **work**: 工作相关信息
- **skills**: 技能能力
- **technical**: 技术信息
- **FRAGMENTS**: 对话片段
- **PREFERENCES**: 偏好习惯
- **SKILLS**: 专业技能

## 版本历史
- v1.0.0: 初始版本，支持基础记忆存储和检索
- 支持Agent Zero风格智能检索
- 支持跨实例记忆共享
- 支持有温度的记忆提取

## 扩展性
系统设计为模块化架构，支持：
- 新增记忆提取规则
- 自定义检索算法
- 扩展记忆分类
- 集成外部存储系统

## 安全考虑
- 记忆文件权限控制
- 输入验证和清理
- 避免敏感信息泄露
- 支持记忆加密存储