#!/usr/bin/env python3
"""
记忆技能启动器 - 简化版本
可以直接在任何iflow实例中使用
"""

import sys
import os
import json

# 添加记忆系统路径
current_dir = os.path.dirname(os.path.abspath(__file__))
iflow_dir = os.path.dirname(os.path.dirname(current_dir))
sys.path.insert(0, iflow_dir)

def recall_memory(question):
    """智能回忆记忆"""
    try:
        from memory_recall import recall_memory_agent_zero_style
        return recall_memory_agent_zero_style(question)
    except ImportError:
        return {"use_memory": False, "memory_response": "记忆系统未初始化"}

def store_memory(key, value, category="user_preference"):
    """存储记忆"""
    try:
        from memory_manager import MemoryManager
        manager = MemoryManager()
        result = manager.store_memory(key, value, category)
        return {"success": True, "message": result["message"]}
    except Exception as e:
        return {"success": False, "error": str(e)}

def show_memory_status():
    """显示记忆状态"""
    try:
        from memory_manager import MemoryManager
        manager = MemoryManager()
        memories = manager.list_all_memories()
        
        print("🧠 记忆系统状态:")
        print(f"  总记忆数: {memories['total_count']}")
        
        # 查找用户偏好
        preferred_name = None
        user_name = None
        
        for key, memory in memories['memories'].items():
            if 'preferred_name' in key and 'final' in key:
                preferred_name = memory['value']
            elif 'user_name' in key:
                user_name = memory['value']
        
        print(f"  用户姓名: {user_name or '未设置'}")
        print(f"  偏好称呼: {preferred_name or '未设置'}")
        
        return True
    except Exception as e:
        print(f"❌ 状态检查失败: {str(e)}")
        return False

def main():
    """主函数"""
    if len(sys.argv) < 2:
        print("🧠 记忆技能 - 简化版")
        print("用法: python3 simple_memory_skill.py <command> [args]")
        print("命令:")
        print("  recall <question>     - 智能回忆记忆")
        print("  store <key> <value>   - 存储记忆")
        print("  status                - 查看记忆状态")
        return
    
    command = sys.argv[1].lower()
    
    if command == "recall":
        if len(sys.argv) < 3:
            print("❌ recall 命令需要问题参数")
            return
        
        question = " ".join(sys.argv[2:])
        result = recall_memory(question)
        
        if result["use_memory"]:
            print(f"🧠 记忆回答: {result['memory_response']}")
        else:
            print("❌ 没有找到相关记忆")
    
    elif command == "store":
        if len(sys.argv) < 4:
            print("❌ store 命令需要 key 和 value 参数")
            return
        
        key = sys.argv[2]
        value = " ".join(sys.argv[3:])
        result = store_memory(key, value)
        
        if result["success"]:
            print(f"✅ 记忆已存储: {key}")
        else:
            print(f"❌ 存储失败: {result.get('error', '未知错误')}")
    
    elif command == "status":
        show_memory_status()
    
    else:
        print(f"❌ 未知命令: {command}")

if __name__ == "__main__":
    main()