#!/usr/bin/env python3
"""
智能记忆共享系统 - Agent Skills 脚本
提供跨iflow实例的记忆功能
"""

import sys
import os
import json
from pathlib import Path

# 添加技能路径到Python路径
skill_path = Path(__file__).parent.parent
sys.path.insert(0, str(skill_path))

try:
    from memory_mcp_client import recall_memory, store_memory, process_conversation, list_all_memories
except ImportError:
    print("❌ 记忆系统模块未找到，请确保记忆文件在正确位置")
    sys.exit(1)

def main():
    """主函数 - 处理命令行调用"""
    if len(sys.argv) < 2:
        print("用法: python3 memory_skill.py <command> [args]")
        print("命令:")
        print("  recall <question>     - 智能回忆记忆")
        print("  store <key> <value>   - 存储记忆")
        print("  process <user_input>  - 处理对话并提取记忆")
        print("  list                  - 列出所有记忆")
        print("  status                - 查看记忆状态")
        return
    
    command = sys.argv[1].lower()
    
    if command == "recall":
        if len(sys.argv) < 3:
            print("❌ recall 命令需要问题参数")
            return
        
        question = " ".join(sys.argv[2:])
        result = recall_memory(question)
        
        if result["use_memory"]:
            print(f"🧠 记忆回答: {result['memory_response']}")
            if result.get("reason"):
                print(f"📊 原因: {result['reason']}")
        else:
            print("❌ 没有找到相关记忆")
    
    elif command == "store":
        if len(sys.argv) < 4:
            print("❌ store 命令需要 key 和 value 参数")
            return
        
        key = sys.argv[2]
        value = " ".join(sys.argv[3:])
        result = store_memory(key, value, "skill_generated")
        
        if result["success"]:
            print(f"✅ 记忆已存储: {key}")
        else:
            print(f"❌ 存储失败: {result.get('error', '未知错误')}")
    
    elif command == "process":
        if len(sys.argv) < 3:
            print("❌ process 命令需要用户输入参数")
            return
        
        user_input = " ".join(sys.argv[2:])
        ai_response = "好的，我已收到您的信息。"
        
        result = process_conversation(user_input, ai_response)
        
        if result["success"]:
            print(f"📝 对话已处理，提取了 {result['memories_found']} 条记忆")
            for memory in result.get("extracted_memories", []):
                print(f"  - {memory}")
        else:
            print(f"❌ 处理失败: {result.get('error', '未知错误')}")
    
    elif command == "list":
        result = list_all_memories({})
        
        if result["success"]:
            memories = result["memories"]
            print(f"📋 共有 {len(memories)} 条记忆:")
            for key, memory in memories.items():
                print(f"  {key}: {memory['value'][:50]}...")
        else:
            print(f"❌ 列表获取失败: {result.get('error', '未知错误')}")
    
    elif command == "status":
        try:
            from memory_system_launcher import check_memory_status
            status = check_memory_status()
            
            print("🧠 记忆系统状态:")
            print(f"  总记忆数: {status['total_memories']}")
            print(f"  用户偏好: {status.get('preferred_name', '未设置')}")
            print(f"  系统状态: {'正常' if status.get('initialized') else '未初始化'}")
            
        except Exception as e:
            print(f"❌ 状态检查失败: {str(e)}")
    
    else:
        print(f"❌ 未知命令: {command}")

if __name__ == "__main__":
    main()