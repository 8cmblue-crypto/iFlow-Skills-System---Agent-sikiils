# 记忆系统快速参考

## 核心API
```python
from memory_mcp_client import recall_memory, store_memory, process_conversation

# 智能回忆
result = recall_memory("我应该怎么称呼自己？")

# 存储记忆
result = store_memory("key", "value", "category")

# 处理对话
result = process_conversation("用户输入", "AI回答")
```

## 命令行工具
```bash
# 回忆记忆
python3 scripts/memory_skill.py recall "我叫什么名字？"

# 存储记忆
python3 scripts/memory_skill.py store "user_name" "张三"

# 处理对话
python3 scripts/memory_skill.py process "我在阿里工作"

# 查看状态
python3 scripts/memory_skill.py status
```

## 记忆分类
- **user_preference**: 用户偏好
- **personal**: 个人信息
- **work**: 工作信息
- **skills**: 技能能力
- **technical**: 技术信息

## 智能检索触发条件
- 包含"我叫"、"我是"、"我的"等个人信息
- 包含"应该怎么"、"什么"等疑问词
- 包含"公司"、"工作"、"技能"等关键词

## 最佳实践
1. 记忆内容要完整、有价值
2. 避免记录临时信息
3. 使用自然语言描述
4. 定期检查记忆状态