# 任务分配协同技能记忆要点

## 核心架构
- **工作流程**: 任务拆解器 → Agent匹配器 → 协同分配 → 文件同步 → 并行执行 → 结果聚合 → 成果输出
- **支持能力**: 多Agent协作、智能任务分配、冲突解决、文件同步、结果聚合

## Agent匹配算法
- **评分维度**: 
  - 能力匹配权重: 0.4
  - 可用性权重: 0.3  
  - 专长匹配权重: 0.2
  - 负载均衡权重: 0.1
- **匹配策略**: 多维度评分，选择最适合的Agent

## 结果聚合机制
- **冲突解决策略**:
  - merge: 合并冲突内容
  - prioritize: 按Agent优先级
  - combine: 组合结果
  - vote: 投票机制
- **聚合功能**: 收集多Agent结果、检测冲突、生成报告

## 文件同步系统
- **冲突策略**:
  - timestamp: 按时间戳解决
  - size: 按文件大小解决
  - content: 按内容相似度解决
  - manual: 手动解决
- **同步功能**: 跨Agent文件同步、共享工作空间、元数据管理

## 任务拆解策略
- **高复杂度**: 分析规划 → 核心实现 → 测试验证 → 文档编写
- **中等复杂度**: 准备分析 → 执行实现 → 验证整理
- **低复杂度**: 简单拆解或不拆解

## Agent类型体系
1. general-purpose: 通用Agent
2. plan-agent: 规划Agent
3. explore-agent: 探索Agent
4. frontend-design-claude2: 前端设计
5. code-review-agent: 代码审查
6. test-agent: 测试
7. documentation-agent: 文档生成

## 核心配置参数
- max_concurrent_tasks: 50
- task_timeout: 600秒
- retry_attempts: 3次
- agent_timeout: 300秒
- result_retention: 30天

## 核心API
- coordinate_collaborative_task(): 协调任务
- collect_and_aggregate_results(): 收集聚合结果
- sync_files_for_task(): 同步文件
- get_collaboration_status(): 获取状态
- generate_task_report(): 生成报告

## 目录结构规范
```
skills/task-coordinator/
├── scripts/     # 核心脚本
├── assets/      # 配置文件
├── templates/   # 模板文件
├── logs/        # 日志
├── results/     # 执行结果
└── sessions/    # 会话数据
```

## 演示测试重要性
- 创建demo脚本测试完整工作流程
- 验证各组件协同工作
- 确保技能可用性
- 提供使用示例

## 最佳实践
1. 模块化设计，各组件职责清晰
2. 完善的错误处理和日志记录
3. 灵活的配置管理
4. 全面的演示和测试
5. 详细的文档说明

## 技术要点
- 使用dataclass定义数据结构
- 实现线程安全的文件同步
- 支持多种冲突解决策略
- 提供实时状态监控
- 生成详细的执行报告