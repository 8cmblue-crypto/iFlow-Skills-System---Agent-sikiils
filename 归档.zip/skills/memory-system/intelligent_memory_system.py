#!/usr/bin/env python3
"""
完整的智能记忆系统 - 集成有灵魂的记忆存储和智能回忆
借鉴Agent Zero的精髓，创建有温度的记忆体验
"""

from soulful_memory import process_conversation_with_soul
from memory_recall import recall_memory_agent_zero_style
from typing import Dict, Any, Optional, List

class IntelligentMemorySystem:
    def __init__(self):
        self.name = "IntelligentMemorySystem"
        self.version = "1.0.0"
    
    def process_conversation_turn(self, user_input: str, ai_response: str = None) -> Dict[str, Any]:
        """
        处理一次完整的对话回合
        1. 智能提取并存储有价值的记忆
        2. 为下一次对话做准备
        """
        
        # 使用有灵魂的记忆系统处理对话
        memory_result = process_conversation_with_soul(user_input, ai_response)
        
        return {
            "conversation_processed": True,
            "memory_result": memory_result,
            "message": f"对话处理完成，{memory_result['message']}"
        }
    
    def generate_memory_enhanced_response(self, question: str, planned_response: str = None, context_history: List[str] = None) -> Dict[str, Any]:
        """
        生成记忆增强的回答 - 使用Agent Zero风格
        1. 检查是否需要回忆记忆
        2. 如果需要，生成基于记忆的回答
        3. 如果不需要，返回正常回答
        """
        
        # 使用Agent Zero风格的记忆检索
        recall_result = recall_memory_agent_zero_style(question, context_history)
        
        if recall_result['use_memory']:
            # 有记忆的情况，优先使用记忆回答
            return {
                "use_memory": True,
                "response": recall_result['memory_response'],
                "memory_enhanced": True,
                "planned_response": None,  # 记忆回答优先
                "recall_reason": recall_result['reason'],
                "search_query": recall_result.get('search_query'),
                "search_stats": {
                    "searched": recall_result.get('searched_count', 0),
                    "relevant": recall_result.get('relevant_count', 0)
                }
            }
        else:
            # 无记忆的情况，使用计划回答或添加称呼
            if planned_response:
                # 可以在这里添加用户的偏好称呼
                enhanced_response = self._add_personal_touch(planned_response)
                return {
                    "use_memory": False,
                    "response": enhanced_response,
                    "memory_enhanced": False,
                    "planned_response": planned_response,
                    "recall_reason": recall_result['reason'],
                    "search_performed": recall_result.get('search_performed', False)
                }
            else:
                return {
                    "use_memory": False,
                    "response": None,
                    "memory_enhanced": False,
                    "planned_response": None,
                    "recall_reason": recall_result['reason'],
                    "search_performed": recall_result.get('search_performed', False)
                }
    
    def _add_personal_touch(self, response: str) -> str:
        """为回答添加个人色彩，比如称呼"""
        
        # 这里可以添加用户的偏好称呼
        # 暂时简单处理，可以后续扩展
        return response
    
    def get_memory_status(self) -> Dict[str, Any]:
        """获取记忆系统状态"""
        
        from memory_manager import MemoryManager
        manager = MemoryManager()
        
        all_memories = manager.list_all_memories()
        
        return {
            "system_name": self.name,
            "version": self.version,
            "total_memories": all_memories.get('total_count', 0),
            "memory_types": self._analyze_memory_types(all_memories),
            "last_updated": "2025-12-24"  # 可以从实际记忆中获取
        }
    
    def _analyze_memory_types(self, all_memories: Dict[str, Any]) -> Dict[str, int]:
        """分析记忆类型分布"""
        
        if 'memories' not in all_memories:
            return {}
        
        types = {}
        
        for key, memory in all_memories['memories'].items():
            category = memory.get('category', 'unknown')
            types[category] = types.get(category, 0) + 1
        
        return types

# 全局智能记忆系统实例
intelligent_memory_system = IntelligentMemorySystem()

def process_conversation_intelligently(user_input: str, ai_response: str = None) -> Dict[str, Any]:
    """智能处理对话 - 主要接口"""
    return intelligent_memory_system.process_conversation_turn(user_input, ai_response)

def generate_intelligent_response(question: str, planned_response: str = None, context_history: List[str] = None) -> Dict[str, Any]:
        """生成智能回答 - 主要接口"""
        return intelligent_memory_system.generate_memory_enhanced_response(question, planned_response, context_history)
def get_memory_system_status() -> Dict[str, Any]:
    """获取记忆系统状态 - 主要接口"""
    return intelligent_memory_system.get_memory_status()

if __name__ == "__main__":
    print("=== 完整智能记忆系统测试 ===\n")
    
    # 模拟完整的对话流程
    conversations = [
        ("我叫林浩，请叫我浩哥", "很高兴认识您，浩哥！"),
        ("我在浙江尚纬电商工作", "了解了！"),
        ("我喜欢编程和机器学习", "这些都是很有前景的技术领域"),
        ("我是什么公司的？", None),  # 应该回忆记忆
        ("我应该怎么称呼自己？", None),  # 应该回忆记忆
        ("今天天气怎么样？", "抱歉，我无法获取实时天气信息"),  # 正常回答
        ("我会Python和深度学习", "这些技能很实用"),
        ("我有什么技能？", None)  # 应该回忆记忆
    ]
    
    print("🎭 开始模拟对话...")
    
    for i, (user_input, planned_response) in enumerate(conversations, 1):
        print(f"\n--- 对话回合 {i} ---")
        print(f"用户: {user_input}")
        
        # 1. 处理对话，提取记忆
        memory_process = process_conversation_intelligently(user_input, planned_response)
        
        # 2. 生成智能回答（带上下文历史）
        context_history = []  # 这里可以传入之前的对话历史
        response_result = generate_intelligent_response(user_input, planned_response, context_history)
        
        # 3. 显示回答
        if response_result['response']:
            if response_result['memory_enhanced']:
                print(f"AI (记忆增强): {response_result['response']} 🧠")
            else:
                print(f"AI: {response_result['response']}")
        else:
            print("AI: [继续对话]")
        
        # 4. 显示记忆处理结果
        if memory_process['memory_result']['memories_found'] > 0:
            print(f"📝 记忆: {memory_process['memory_result']['message']}")
            for memory in memory_process['memory_result']['extracted_memories']:
                print(f"    - {memory}")
        
        # 5. 显示回忆状态
        if response_result['use_memory']:
            print(f"🎯 Agent Zero风格回忆: {response_result['recall_reason']}")
            if response_result.get('search_query'):
                print(f"🔍 搜索查询: {response_result['search_query']}")
            if response_result.get('search_stats'):
                stats = response_result['search_stats']
                print(f"📊 搜索统计: 搜索了{stats['searched']}条，相关{stats['relevant']}条")
    
    # 显示记忆系统状态
    print(f"\n{'='*50}")
    status = get_memory_system_status()
    print("📊 记忆系统状态:")
    print(f"  系统名称: {status['system_name']}")
    print(f"  版本: {status['version']}")
    print(f"  总记忆数: {status['total_memories']}")
    print(f"  记忆类型分布: {status['memory_types']}")