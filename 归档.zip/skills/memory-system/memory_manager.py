#!/usr/bin/env python3
"""
iFlow 记忆管理器
模拟 memento MCP 服务器功能，用于存储和检索用户记忆信息
"""

import json
import os
from datetime import datetime
from typing import Dict, Any, Optional

class MemoryManager:
    def __init__(self, memory_file: str = None):
        if memory_file is None:
            memory_file = os.path.join(os.path.dirname(__file__), "user_memories.json")
        
        self.memory_file = memory_file
        self.memories = self._load_memories()
    
    def _load_memories(self) -> Dict[str, Any]:
        """加载现有记忆"""
        if os.path.exists(self.memory_file):
            try:
                with open(self.memory_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except (json.JSONDecodeError, FileNotFoundError):
                return {}
        return {}
    
    def _save_memories(self):
        """保存记忆到文件"""
        with open(self.memory_file, 'w', encoding='utf-8') as f:
            json.dump(self.memories, f, ensure_ascii=False, indent=2)
    
    def store_memory(self, key: str, value: str, category: str = "general", metadata: Dict = None) -> Dict[str, Any]:
        """存储记忆信息"""
        if metadata is None:
            metadata = {}
        
        memory_entry = {
            "value": value,
            "category": category,
            "created_at": datetime.now().isoformat(),
            "metadata": metadata
        }
        
        self.memories[key] = memory_entry
        self._save_memories()
        
        return {
            "status": "success",
            "key": key,
            "message": f"记忆 '{key}' 已成功存储",
            "timestamp": memory_entry["created_at"]
        }
    
    def retrieve_memory(self, key: str) -> Optional[Dict[str, Any]]:
        """检索记忆信息"""
        if key in self.memories:
            return {
                "status": "success",
                "key": key,
                "data": self.memories[key]
            }
        return None
    
    def search_memories(self, query: str, category: str = None) -> list:
        """搜索记忆"""
        results = []
        query_lower = query.lower()
        
        for key, memory in self.memories.items():
            # 检查类别过滤
            if category and memory.get("category") != category:
                continue
            
            # 检查内容匹配
            if (query_lower in key.lower() or 
                query_lower in memory["value"].lower() or
                any(query_lower in str(v).lower() for v in memory.get("metadata", {}).values())):
                results.append({
                    "key": key,
                    "data": memory
                })
        
        return results
    
    def list_all_memories(self) -> Dict[str, Any]:
        """列出所有记忆"""
        return {
            "status": "success",
            "total_count": len(self.memories),
            "memories": self.memories
        }
    
    def delete_memory(self, key: str) -> Dict[str, Any]:
        """删除记忆"""
        if key in self.memories:
            del self.memories[key]
            self._save_memories()
            return {
                "status": "success",
                "message": f"记忆 '{key}' 已删除"
            }
        return {
            "status": "error",
            "message": f"记忆 '{key}' 不存在"
        }

def main():
    """命令行接口"""
    import sys
    
    if len(sys.argv) < 2:
        print("用法: python memory_manager.py <command> [args...]")
        print("命令:")
        print("  store <key> <value> [category]  - 存储记忆")
        print("  get <key>                       - 获取记忆")
        print("  search <query> [category]       - 搜索记忆")
        print("  list                            - 列出所有记忆")
        print("  delete <key>                    - 删除记忆")
        return
    
    manager = MemoryManager()
    command = sys.argv[1].lower()
    
    if command == "store":
        if len(sys.argv) < 4:
            print("错误: store 命令需要 key 和 value 参数")
            return
        key = sys.argv[2]
        value = sys.argv[3]
        category = sys.argv[4] if len(sys.argv) > 4 else "general"
        result = manager.store_memory(key, value, category)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    
    elif command == "get":
        if len(sys.argv) < 3:
            print("错误: get 命令需要 key 参数")
            return
        key = sys.argv[2]
        result = manager.retrieve_memory(key)
        if result:
            print(json.dumps(result, ensure_ascii=False, indent=2))
        else:
            print(json.dumps({"status": "error", "message": "记忆不存在"}, ensure_ascii=False))
    
    elif command == "search":
        if len(sys.argv) < 3:
            print("错误: search 命令需要 query 参数")
            return
        query = sys.argv[2]
        category = sys.argv[3] if len(sys.argv) > 3 else None
        results = manager.search_memories(query, category)
        print(json.dumps({"status": "success", "results": results}, ensure_ascii=False, indent=2))
    
    elif command == "list":
        result = manager.list_all_memories()
        print(json.dumps(result, ensure_ascii=False, indent=2))
    
    elif command == "delete":
        if len(sys.argv) < 3:
            print("错误: delete 命令需要 key 参数")
            return
        key = sys.argv[2]
        result = manager.delete_memory(key)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    
    else:
        print(f"错误: 未知命令 '{command}'")

if __name__ == "__main__":
    main()