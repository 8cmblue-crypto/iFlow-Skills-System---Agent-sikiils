#!/usr/bin/env python3
"""
记忆触发器 - 在对话开始时自动触发记忆检索
"""

import json
import os
from integrated_memory_system import get_memory_answer, auto_save_conversation_context

class MemoryTrigger:
    def __init__(self):
        self.memory_file = "/vol1/1000/iflow/user_memories.json"
        self.user_profile = self._load_user_profile()
    
    def _load_user_profile(self):
        """加载用户基本档案"""
        try:
            with open(self.memory_file, 'r', encoding='utf-8') as f:
                memories = json.load(f)
            
            profile = {
                "name": None,
                "preferred_name": None, 
                "company": None,
                "total_memories": len(memories)
            }
            
            # 提取关键信息
            for key, memory in memories.items():
                value = memory.get("value", "")
                
                if "林浩" in value and not profile["name"]:
                    profile["name"] = "林浩"
                
                if "浩哥" in value and "希望" in value:
                    profile["preferred_name"] = "浩哥"
                
                if "浙江尚纬电商" in value or "尚纬" in value:
                    profile["company"] = "浙江尚纬电商"
            
            return profile
            
        except Exception:
            return {"name": None, "preferred_name": None, "company": None, "total_memories": 0}
    
    def get_greeting_with_memory(self):
        """获取带有记忆信息的问候"""
        profile = self.user_profile
        
        if profile["preferred_name"]:
            greeting = f"浩哥，您好！"
        elif profile["name"]:
            greeting = f"{profile['name']}，您好！"
        else:
            greeting = "您好！"
        
        # 添加记忆状态
        if profile["total_memories"] > 0:
            greeting += f" (已加载 {profile['total_memories']} 条记忆)"
        
        return greeting
    
    def should_check_memory(self, question):
        """判断是否需要检查记忆 - 更精确的个人信息检测"""
        question_lower = question.lower()
        
        # 个人信息直接问题模式
        personal_questions = [
            r'我.*?是.*?谁', r'我.*?叫.*?什么', r'我.*?姓名',
            r'我.*?公司', r'我.*?工作', r'我.*?单位',
            r'怎么称呼.*?我', r'应该.*?叫.*?我', r'我的.*?名字',
            r'我的.*?公司', r'我的.*?工作'
        ]
        
        # 个人偏好询问
        preference_questions = [
            r'我.*?喜欢', r'我.*?讨厌', r'我.*?偏好',
            r'我.*?习惯', r'我.*?爱好'
        ]
        
        import re
        
        # 检查是否为个人信息问题
        for pattern in personal_questions + preference_questions:
            if re.search(pattern, question_lower):
                return True
        
        # 严格关键词检测 - 必须与个人信息相关
        strict_keywords = {
            '名字': ['叫什么', '姓名', '名字'],
            '公司': ['公司', '工作', '单位'],
            '称呼': ['称呼', '怎么叫', '叫'],
            '我是谁': ['我是谁', '我谁']
        }
        
        for category, keywords in strict_keywords.items():
            if any(kw in question_lower for kw in keywords):
                # 进一步确认这是关于"我"的问题
                if '我' in question_lower or '自己' in question_lower:
                    return True
        
        return False
    
    def process_with_memory(self, question):
        """处理问题并返回记忆增强的结果"""
        if self.should_check_memory(question):
            memory_answer = get_memory_answer(question)
            if memory_answer:
                return {
                    "has_memory": True,
                    "memory_answer": memory_answer,
                    "suggestion": f"建议回答: {memory_answer}"
                }
        
        return {"has_memory": False, "memory_answer": None}

# 全局实例
memory_trigger = MemoryTrigger()

def initialize_conversation():
    """初始化对话 - 在每次对话开始时调用"""
    greeting = memory_trigger.get_greeting_with_memory()
    profile = memory_trigger.user_profile
    
    return {
        "greeting": greeting,
        "user_profile": profile,
        "memory_active": True
    }

def check_question_memory(question):
    """检查问题是否需要记忆回答"""
    return memory_trigger.process_with_memory(question)

def save_conversation_insight(user_input, ai_response):
    """保存对话洞察"""
    auto_save_conversation_context(user_input, ai_response)

if __name__ == "__main__":
    # 测试初始化
    init_result = initialize_conversation()
    print("=== 对话初始化测试 ===")
    print(f"问候: {init_result['greeting']}")
    print(f"用户档案: {init_result['user_profile']}")
    print()
    
    # 测试问题处理
    test_questions = [
        "我是什么公司的？",
        "今天天气怎么样？",
        "你怎么称呼我？",
        "帮我写个代码"
    ]
    
    print("=== 问题处理测试 ===")
    for q in test_questions:
        result = check_question_memory(q)
        print(f"问题: {q}")
        if result['has_memory']:
            print(f"✅ {result['suggestion']}")
        else:
            print("❌ 无需记忆检索")
        print()