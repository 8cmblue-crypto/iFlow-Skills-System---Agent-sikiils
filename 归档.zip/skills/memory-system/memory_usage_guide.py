#!/usr/bin/env python3
"""
iFlow记忆系统使用指南
在新会话中快速启动和使用记忆系统
"""

def quick_start_memory():
    """快速启动记忆系统"""
    print("📋 iFlow记忆系统快速启动指南")
    print("=" * 40)
    
    print("\n1️⃣ 启动记忆系统:")
    print("   from memory_system_launcher import load_memory_system")
    print("   load_memory_system()")
    
    print("\n2️⃣ 处理对话并记忆:")
    print("   from intelligent_memory_system import process_conversation_intelligently")
    print("   result = process_conversation_intelligently(用户输入, AI回答)")
    
    print("\n3️⃣ 生成记忆增强回答:")
    print("   from intelligent_memory_system import generate_intelligent_response")
    print("   result = generate_intelligent_response(问题, 计划回答)")
    
    print("\n4️⃣ 检查记忆状态:")
    print("   from memory_system_launcher import check_memory_status")
    print("   status = check_memory_status()")
    
    print("\n🎯 核心功能:")
    print("   ✅ 自动提取有价值信息")
    print("   ✅ 智能记忆检索")
    print("   ✅ Agent Zero风格回忆")
    print("   ✅ 有温度的记忆存储")

def show_current_memories():
    """显示当前关键记忆"""
    print("\n🧠 当前关键记忆:")
    print("-" * 30)
    
    try:
        from memory_manager import MemoryManager
        manager = MemoryManager()
        
        # 显示最重要的记忆
        key_memories = [
            "preferred_name_final",
            "name_preference_note_2025", 
            "iflow_history_cleanup_script"
        ]
        
        for key in key_memories:
            memory = manager.retrieve_memory(key)
            if memory:
                value = memory['data']['value']
                print(f"📝 {key}: {value[:60]}...")
        
    except Exception as e:
        print(f"❌ 无法读取记忆: {e}")

def demo_memory_usage():
    """演示记忆使用"""
    print("\n🎪 记忆使用演示:")
    print("-" * 30)
    
    try:
        from memory_recall import recall_memory_agent_zero_style
        
        demo_questions = [
            "我应该怎么称呼自己？",
            "iFlow历史清理脚本怎么用？"
        ]
        
        for question in demo_questions:
            print(f"\n❓ {question}")
            result = recall_memory_agent_zero_style(question)
            
            if result['use_memory']:
                print(f"🎯 记忆回答: {result['memory_response']}")
            else:
                print(f"❌ 无记忆: {result['reason']}")
                
    except Exception as e:
        print(f"❌ 演示失败: {e}")

if __name__ == "__main__":
    quick_start_memory()
    show_current_memories()
    demo_memory_usage()
    
    print("\n✅ 记忆系统使用指南完成！")
    print("\n💡 提示: 在每个新会话开始时，先运行 load_memory_system()")