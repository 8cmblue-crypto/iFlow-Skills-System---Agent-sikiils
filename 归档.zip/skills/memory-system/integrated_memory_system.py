#!/usr/bin/env python3
"""
集成记忆系统 - 自动在对话中检索和应用记忆
"""

import json
import re
import os
from smart_memory_search import SmartMemorySearch
from memory_manager import MemoryManager

class IntegratedMemorySystem:
    def __init__(self):
        self.memory_manager = MemoryManager()
        self.smart_search = SmartMemorySearch()
        self.conversation_history = []
        
        # 问题类型与记忆关键词的映射
        self.question_patterns = {
            'company': ['公司', '工作', '单位', '企业', '老板', '在哪工作'],
            'name': ['名字', '叫什么', '姓名', '称呼', '怎么叫', '我是谁'],
            'preference': ['喜欢', '讨厌', '偏好', '习惯', '爱好', '想要'],
            'personal': ['我', '自己', '我的', '个人', '关于我']
        }
    
    def process_question(self, question):
        """处理问题并自动检索相关记忆"""
        question_lower = question.lower()
        
        # 检测问题类型
        question_type = self._detect_question_type(question)
        
        # 检索相关记忆
        relevant_memories = self.smart_search.search_relevant_memories(question)
        
        # 生成智能回复
        if relevant_memories:
            return self._generate_memory_response(question, relevant_memories, question_type)
        else:
            return None
    
    def _detect_question_type(self, question):
        """检测问题类型"""
        question_lower = question.lower()
        
        for q_type, patterns in self.question_patterns.items():
            if any(pattern in question_lower for pattern in patterns):
                return q_type
        
        return 'general'
    
    def _generate_memory_response(self, question, memories, question_type):
        """基于记忆生成回复"""
        if question_type == 'company':
            for memory in memories:
                if '公司' in memory['content'] or '尚纬' in memory['content']:
                    return f"根据记忆，{memory['content']}"
        
        elif question_type == 'name':
            for memory in memories:
                if '林浩' in memory['content'] or '浩哥' in memory['content']:
                    if '希望' in memory['content'] and '浩哥' in memory['content']:
                        return "根据记忆，您是林浩，希望被称为浩哥。"
                    return f"根据记忆，{memory['content']}"
        
        elif question_type == 'preference':
            preferences = [m['content'] for m in memories if '喜欢' in m['content'] or '偏好' in m['content']]
            if preferences:
                return f"根据记忆，{preferences[0]}"
        
        # 通用回复
        if memories:
            return f"根据记忆，{memories[0]['content']}"
        
        return None
    
    def auto_save_context(self, user_input, ai_response):
        """自动保存对话上下文中的重要信息"""
        # 检测用户分享的新信息
        new_info = self._extract_new_info(user_input)
        
        for info in new_info:
            # 检查是否已存在
            existing = self.memory_manager.search_memories(info['value'])
            if not existing:
                self.memory_manager.store_memory(
                    key=f"auto_memory_{len(self.memory_manager.memories)}",
                    value=info['value'],
                    category=info['category'],
                    metadata={"auto_extracted": True, "timestamp": info.get('timestamp')}
                )
    
    def _extract_new_info(self, user_input):
        """从用户输入中提取新信息"""
        new_info = []
        
        # 公司信息提取
        if any(word in user_input for word in ['我的公司是', '我在', '我们公司']):
            company_match = re.search(r'(?:我的公司是|我在|我们公司)[：:]\s*([^\n，。！？]+)', user_input)
            if company_match:
                new_info.append({
                    'value': f"公司信息：{company_match.group(1)}",
                    'category': 'user_info',
                    'timestamp': user_input
                })
        
        # 偏好信息提取
        if any(word in user_input for word in ['我喜欢', '我讨厌', '我希望']):
            preference_match = re.search(r'(我喜欢|我讨厌|我希望)[：:]?\s*([^\n，。！？]+)', user_input)
            if preference_match:
                new_info.append({
                    'value': f"{preference_match.group(1)}：{preference_match.group(2)}",
                    'category': 'preference',
                    'timestamp': user_input
                })
        
        return new_info
    
    def get_memory_enhanced_response(self, question):
        """获取记忆增强的回复"""
        # 首先检查记忆中是否有直接答案
        memory_response = self.process_question(question)
        
        if memory_response:
            return memory_response
        
        # 如果没有直接答案，返回相关记忆作为上下文
        relevant_memories = self.smart_search.search_relevant_memories(question)
        if relevant_memories:
            context = "🧠 相关记忆上下文:\n"
            for i, mem in enumerate(relevant_memories[:2], 1):
                context += f"{i}. {mem['content']}\n"
            return context
        
        return None

# 全局实例
integrated_memory = IntegratedMemorySystem()

def get_memory_answer(question):
    """获取记忆答案 - 供AI调用"""
    return integrated_memory.get_memory_enhanced_response(question)

def auto_save_conversation_context(user_input, ai_response):
    """自动保存对话上下文"""
    integrated_memory.auto_save_context(user_input, ai_response)

if __name__ == "__main__":
    # 测试
    test_questions = [
        "我是什么公司的？",
        "我应该叫什么名字？", 
        "你怎么称呼我？",
        "浙江尚纬电商"
    ]
    
    for q in test_questions:
        print(f"问题: {q}")
        answer = get_memory_answer(q)
        if answer:
            print(f"记忆回答: {answer}")
        else:
            print("无相关记忆")
        print("-" * 40)