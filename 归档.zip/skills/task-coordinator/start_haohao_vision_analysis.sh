#!/bin/bash

# 好好视力竞争对手调研启动脚本
# 老大，这是启动好好视力竞争对手调研任务的脚本

echo "=========================================="
echo "好好视力竞争对手调研 - 任务启动"
echo "=========================================="

# 设置工作目录
cd /vol1/1000/iflow/skills/task-coordinator

# 检查Python环境
echo "🔍 检查Python环境..."
if ! command -v python3 &> /dev/null; then
    echo "❌ Python3 未找到，请先安装Python3"
    exit 1
fi

# 检查必要的目录
echo "📁 检查目录结构..."
mkdir -p logs
mkdir -p ../sync_workspace
mkdir -p results

# 检查任务配置文件
echo "📋 检查任务配置..."
if [ ! -f "tasks/haohao_vision_competitor_analysis.json" ]; then
    echo "❌ 任务配置文件不存在"
    exit 1
fi

if [ ! -f "tasks/haohao_vision_agent_instructions.md" ]; then
    echo "❌ Agent指令文件不存在"
    exit 1
fi

# 检查执行脚本
echo "🔧 检查执行脚本..."
if [ ! -f "scripts/haohao_vision_analysis_executor.py" ]; then
    echo "❌ 执行脚本不存在"
    exit 1
fi

# 设置执行权限
chmod +x scripts/haohao_vision_analysis_executor.py

echo "✅ 环境检查完成"
echo ""

# 启动调研任务
echo "🚀 启动好好视力竞争对手调研任务..."
echo ""

python3 scripts/haohao_vision_analysis_executor.py

# 检查执行结果
if [ $? -eq 0 ]; then
    echo ""
    echo "✅ 好好视力竞争对手调研任务完成!"
    echo ""
    echo "📊 查看结果文件："
    echo "   - 任务配置: tasks/haohao_vision_competitor_analysis.json"
    echo "   - Agent指令: tasks/haohao_vision_agent_instructions.md"
    echo "   - 执行日志: logs/haohao_vision_analysis.log"
    echo "   - 调研结果: ../sync_workspace/task_*/aggregated_results/"
    echo ""
    echo "📈 主要交付物："
    echo "   - 各Agent专项分析报告"
    echo "   - 竞争对手综合分析报告"
    echo "   - 战略建议和行动计划"
    echo "   - 市场洞察和风险评估"
else
    echo ""
    echo "❌ 调研任务执行失败"
    echo "请查看日志文件获取详细错误信息: logs/haohao_vision_analysis.log"
    exit 1
fi

echo ""
echo "=========================================="
echo "任务执行完成"
echo "=========================================="