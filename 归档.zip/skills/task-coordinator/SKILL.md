---
name: task-coordinator
version: 1.0.0
description: >
  任务分配协同技能 - 规范化任务拆解、Agent分配、结果汇总和成果管理。
  通过标准化流程实现任务发布、执行、监控和结果管理，确保任务执行的规范性和可追溯性。
  支持多Agent协作、任务分解、结果聚合、文件同步等功能。

author: 林浩 <老大@iflow.com>
license: MIT
tags: [task-coordination, agent-management, task-decomposition, result-aggregation]
allowed_tools: [bash, python3]
required_context: []
---

# 任务分配协同技能

## 🎯 **技能概述**

通过规范化的任务拆解和Agent分配机制，实现任务的发布、执行、监控和结果管理。支持多Agent协作、任务分解、结果聚合、文件同步等功能，确保任务执行的规范性和可追溯性。

## 📋 **核心功能**

### ✅ **任务管理**
- **任务拆解**: 将复杂任务拆解为可执行的子任务
- **任务分配**: 根据Agent能力智能分配子任务
- **任务监控**: 实时监控任务执行状态和进度
- **任务调度**: 智能调度和优化任务执行顺序

### 🤖 **Agent管理**
- **Agent发现**: 自动发现和注册可用Agent
- **Agent分配**: 根据任务类型和能力匹配Agent
- **Agent协调**: 协调多个Agent的协作关系
- **Agent监控**: 监控Agent执行状态和性能

### 🔄 **结果管理**
- **结果收集**: 收集所有Agent执行结果
- **结果聚合**: 智能聚合和整合多个结果
- **结果验证**: 验证结果质量和完整性
- **文件同步**: 同步Agent生成的文件到技能目录

### 📊 **监控分析**
- **任务状态**: 实时监控任务执行状态
- **进度跟踪**: 跟踪任务完成进度和里程碑
- **性能分析**: 分析任务执行性能和效率
- **质量评估**: 评估任务完成质量和准确性

## 🔧 **技术实现**

### 📁 **文件结构**
```
skills/task-coordinator/
├── SKILL.md                    # 技能说明文档
├── assets/
│   └── config.json             # 配置文件
├── scripts/
│   ├── task_coordinator.py      # 任务协调器核心
│   ├── task_decomposer.py       # 任务拆解器
│   ├── agent_matcher.py          # Agent匹配器
│   ├── result_aggregator.py      # 结果聚合器
│   ├── file_sync_system.py      # 文件同步系统
│   ├── task_decomposer.py       # 任务分解器
│   ├── demo_collaboration.py    # 协同功能演示
│   └── task_decomposer.py       # 任务分解器
├── templates/
│   ├── agent_profiles.json       # Agent配置文件
│   └── task_templates.json       # 任务模板定义
├── logs/                         # 执行日志
├── results/                      # 任务执行结果存储
└── sessions/                     # 会话数据
```

### 🔄 **协同分配工作流程**
```
任务输入 → 任务拆解 → Agent匹配 → 协同分配 → 文件同步 → 并行执行 → 结果收集 → 冲突解决 → 结果聚合 → 成果输出
    ↓
实时监控 ← 进度跟踪 ← 性能分析 ← 质量检查 ← 协调控制 ← 状态同步
```

### 🔄 **工作流程**
```
任务输入 → 任务拆解 → Agent匹配 → 任务分配 → 并行执行 → 结果收集 → 结果聚合 → 文件同步 → 状态更新
    ↓
监控分析 ← 进度跟踪 ← 性能评估 ← 质量检查 ← 协调控制 ← 结果验证
```

## ⚙️ **配置参数**

### 🎯 **任务配置**
```json
{
  "task_management": {
    "max_concurrent_tasks": 50,
    "task_timeout": 600,
    "retry_attempts": 3,
    "auto_decomposition": true,
    "task_prioritization": true
  },
  "agent_management": {
    "auto_discovery": true,
    "max_agents": 20,
    "agent_timeout": 300,
    "load_balancing": true,
    "capability_matching": true
  },
  "result_management": {
    "auto_aggregation": true,
    "result_validation": true,
    "file_sync_enabled": true,
    "result_retention": 30
  },
  "monitoring": {
    "real_time_monitoring": true,
    "update_interval": 10,
    "alert_threshold": 0.8,
    "performance_tracking": true
  }
}
```

## 🚀 **使用方法**

### 📦 **快速开始**
```bash
# 初始化任务协调系统
python3 scripts/task_coordinator.py init

# 创建协同任务
python3 scripts/task_coordinator.py create-task \
  --name "项目代码审查" \
  --description "对整个项目进行全面的代码审查" \
  --priority "high"

# 执行协同任务分配
python3 scripts/task_coordinator.py execute-task \
  --task-id "task-001" \
  --auto-assign

# 查看任务状态
python3 scripts/task_coordinator.py status
```

### 🤝 **协同分配功能**
```bash
# 演示协同任务执行
python3 scripts/demo_collaboration.py

# 协调协同任务
coordinator.coordinate_collaborative_task(task_id)

# 收集聚合结果
aggregated_results = coordinator.collect_and_aggregate_results(task_id, agent_outputs)

# 同步文件
coordinator.sync_files_for_task(task_id, file_paths, source_agent)

# 查看协同状态
collaboration_status = coordinator.get_collaboration_status(task_id)
```

### 🎯 **核心组件使用**

#### **1. 任务分解器**
```python
from task_decomposer import TaskDecomposer

decomposer = TaskDecomposer()
subtasks = decomposer.decompose(task)
print(f"任务分解为 {len(subtasks)} 个子任务")
```

#### **2. Agent匹配器**
```python
from agent_matcher import AgentMatcher

matcher = AgentMatcher(agents)
assignments = matcher.match_and_assign(subtasks, available_agents)
print(f"成功分配 {len(assignments)} 个子任务")
```

#### **3. 结果聚合器**
```python
from result_aggregator import ResultAggregator

aggregator = ResultAggregator()
aggregated_results = aggregator.collect_results(assignments, agent_outputs)
report = aggregator.generate_final_report(aggregated_results)
```

#### **4. 文件同步系统**
```python
from file_sync_system import FileSyncSystem

sync_system = FileSyncSystem()
sync_system.register_file(file_path, agent_id)
sync_system.sync_file_to_agents(file_path, source_agent, target_agents)
```

### 🔧 **任务模板**
```bash
# 使用预定义模板
python3 scripts/task_coordinator.py create-from-template \
  --template "code_review" \
  --params "project=/path/to/project"

# 自定义任务模板
python3 scripts/task_coordinator.py create-template \
  --name "custom_template" \
  --description "自定义任务模板"
```

### 🤖 **Agent管理**
```bash
# 列出可用Agent
python3 scripts/task_coordinator.py list-agents

# 注册新Agent
python3 scripts/task_coordinator.py register-agent \
  --name "代码审查Agent" \
  --capabilities ["code_review", "security_check", "performance_analysis"]

# 查看Agent状态
python3 scripts/task_coordinator.py agent-status
```

## 📊 **任务拆解规范**

### 🎯 **标准化拆解流程**
老大，任务拆解遵循以下规范：

#### **1. 任务分析阶段**
```python
def analyze_task(task_description):
    return {
        "task_type": identify_task_type(task_description),
        "complexity": assess_complexity(task_description),
        "estimated_time": estimate_execution_time(task_description),
        "required_capabilities": identify_required_capabilities(task_description),
        "dependencies": identify_dependencies(task_description)
    }
```

#### **2. 任务拆解阶段**
```python
def decompose_task(task_analysis):
    subtasks = []
    
    # 主任务拆解
    main_task = create_main_task(task_analysis)
    subtasks.append(main_task)
    
    # 辅助任务拆解
    if task_analysis["complexity"] > 0.7:
        supporting_tasks = create_supporting_tasks(task_analysis)
        subtasks.extend(supporting_tasks)
    
    # 质量控制拆解
    if task_analysis["estimated_time"] > 300:
        time_based_tasks = time_based_decomposition(task_analysis)
        subtasks.extend(time_based_tasks)
    
    return subtasks
```

#### **3. 任务优先级管理**
```python
def prioritize_tasks(subtasks):
    prioritized_tasks = []
    
    for task in subtasks:
        task["priority"] = calculate_priority(task)
        prioritized_tasks.append(task)
    
    return sorted(prioritized_tasks, key=lambda x: x["priority"], reverse=True)
```

## 🤖 **Agent匹配和分配**

### ✅ **Agent能力矩阵**
```json
{
  "agent_capabilities": {
    "code_review_agent": {
      "capabilities": ["code_analysis", "security_check", "performance_analysis"],
      "max_concurrent_tasks": 3,
      "specialties": ["Python", "JavaScript", "TypeScript", "Go"]
    },
    "test_agent": {
      "capabilities": ["unit_testing", "integration_testing", "ui_testing"],
      "max_concentrate_tasks": 5,
      "specialties": ["pytest", "selenium", "cypress", "jest"]
    },
    "documentation_agent": {
      "capabilities": ["markdown_generation", "api_docs", "user_guides"],
      "max_concentrate_tasks": 4,
      "specialties": ["Markdown", "OpenAPI", "Sphinx"]
    }
  }
}
```

### 🎯 **智能分配算法**
```python
def assign_tasks_to_agents(subtasks, available_agents):
    assignments = []
    
    for task in prioritized_tasks:
        best_agent = find_best_agent(task, available_agents)
        assignment = {
            "task_id": task["id"],
            "agent_id": best_agent["id"],
            "assigned_at": datetime.now().isoformat(),
            "estimated_completion": task["estimated_time"],
            "priority": task["priority"]
        }
        assignments.append(assignment)
        
        # 更新Agent负载
        update_agent_load(best_agent["id"], task)
    
    return assignments
```

## 🔄 **结果聚合和验证**

### ✅ **结果收集流程**
```python
def collect_results(assignments):
    results = []
    
    for assignment in assignments:
        result = {
            "task_id": assignment["task_id"],
            "agent_id": assignment["agent_id"],
            "status": "in_progress",
            "start_time": assignment["assigned_at"],
            "updates": []
        }
        results.append(result)
    
    return results
```

### 🎯 **智能聚合算法**
```python
def aggregate_results(completed_tasks):
    aggregated = {
        "task_summary": generate_task_summary(completed_tasks),
        "agent_performance": analyze_agent_performance(completed_tasks),
        "quality_metrics": calculate_quality_metrics(completed_tasks),
        "execution_timeline": create_execution_timeline(completed_tasks),
        "resource_utilization": analyze_resource_utilization(completed_tasks)
    }
    
    return aggregated
```

## 📁 **文件同步和成果管理**

### ✅ **文件同步机制**
```python
def sync_agent_results(agent_id, result_data):
    # 创建Agent结果目录
    agent_results_dir = f"results/agent_{agent_id}"
    Path(agent_results_dir).mkdir(parents=True, exist_ok=True)
    
    # 保存结果文件
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    
    # 保存回复内容
    if result_data.get("reply"):
        reply_file = f"{agent_results_dir}/reply_{timestamp}.md"
        with open(reply_file, 'w', encoding='utf-8') as f:
            f.write(result_data["reply"])
    
    # 保存生成的文件
    for file_info in result_data.get("generated_files", []):
        file_path = f"{agent_results_dir}/files/{timestamp}_{file_info['name']}"
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(file_info["content"])
    
    # 保存执行日志
    log_file = f"{agent_results_dir}/execution_log_{timestamp}.json"
    with open(log_file, 'w', encoding='��-8') as f:
        json.dump(result_data["execution_log"], f, ensure_ascii=False, indent=2)
```

### 🎯 **成果管理**
```python
def manage_artifacts(task_results):
    artifacts = []
    
    for result in task_results:
        task_artifacts = collect_artifacts(result)
        
        for artifact in task_artifacts:
            artifact_info = {
                "task_id": result["task_id"],
                "agent_id": result["agent_id"],
                "artifact_type": artifact["type"],
                "file_path": artifact["path"],
                "created_at": artifact["created_at"],
                "size": artifact["size"],
                "checksum": calculate_checksum(artifact["path"])
            }
            artifacts.append(artifact_info)
    
    return artifacts
```

## 📊 **监控和分析**

### ✅ **实时监控面板**
```python
def generate_monitoring_dashboard():
    return {
        "active_tasks": count_active_tasks(),
        "agent_status": get_agent_status_summary(),
        "task_progress": get_task_progress_overview(),
        "performance_metrics": get_performance_metrics(),
        "alert_status": check_alert_conditions()
    }
```

### 📈 **质量评估指标**
```python
def calculate_quality_metrics(results):
    metrics = {
        "completion_rate": calculate_completion_rate(results),
        "average_quality": calculate_average_quality(results),
        "on_time_completion_rate": calculate_on_time_completion(results),
        "agent_satisfaction": calculate_agent_satisfaction(results),
        "result_consistency": evaluate_result_consistency(results)
    }
    
    return metrics
```

## 🚀 **高级功能**

### 🎯 **任务模板系统**
```json
{
  "task_templates": {
    "code_review": {
      "name": "代码审查任务",
      "description": "对指定代码库进行全面审查",
      "default_priority": "high",
      "required_capabilities": ["code_review"],
      "estimated_time": 1800,
      "subtasks": [
        {
          "name": "代码质量检查",
          "description": "检查代码质量和规范",
          "required_capabilities": ["code_analysis"],
          "estimated_time": 600
        },
        {
          "name": "安全漏洞扫描",
          "description": "扫描安全漏洞和风险点",
          "required_capabilities": ["security_check"],
          "estimated_time": 900
        }
      ]
    },
    "documentation": {
      "name": "文档生成任务",
      "description": "生成项目文档和API文档",
      "default_priority": "medium",
      "required_capabilities": ["markdown_generation"],
      "estimated_time": 1200,
      "subtasks": [
        {
          "name": "API文档生成",
          "description": "生成API接口文档",
          "required_capabilities": ["api_docs"],
          "estimated_time": 600
        },
        {
          "name": "用户指南编写",
          "description": "编写用户使用指南",
          "required_capabilities": ["user_guides"],
          "estimated_time": 400
        }
      ]
    }
  }
}
```

### 🔄 **工作流自动化**
```bash
# 自动化任务工作流
python3 scripts/task_coordinator.py create-workflow \
  --name "CI/CD流水线" \
  --tasks "代码构建,单元测试,集成测试,部署" \
  --agents "build_agent,test_agent,deploy_agent"

# 批量任务管理
python3 scripts/task_coordinator.py batch-operation \
  --operation "create_tasks" \
  --tasks "task1,task2,task3" \
  --auto-assign
```

## ⚠️ **注意事项**

### 🚨 **重要限制**
1. **任务依赖**: 确保任务依赖关系正确处理
2. **Agent容量**: 避免单个Agent过载
3. **结果质量**: 重视结果验证和质量检查
4. **文件同步**: 确保文件同步的可靠性

### 🛡️ **安全措施**
- **任务验证**: 验证任务内容和参数
- **Agent验证**: 验证Agent身份和能力
- **结果验证**: 集成验证结果质量
- **备份机制**: 重要数据和文件的备份

## 📞 **技术支持**

### 🐛 **常见问题**
1. **Q: 如何自定义任务拆解规则？**
   A: 修改 `task_decomposer.py` 中的拆解算法

2. **Q: 如何添加新的Agent类型？**
   A: 在 `agent_profiles.json` 中定义新的Agent配置

3. **Q: 如何处理任务失败的情况？**
   A: 系统自动重试和故障转移

4. **Q: 如何查看任务执行历史？**
   A: 使用 `task_coordinator.py history` 命令

### 📈 **最佳实践**
1. **任务定义**: 使用清晰、具体的任务描述
2. **Agent配置**: 合理配置Agent能力和负载
3. **结果验证**: 重视结果质量和完整性检查
4. **文件管理**: 定期清理和归档结果文件
5. **性能优化**: 监控系统性能，及时优化

---

*技能版本: v1.0.0*  
*创建时间: 2025-12-25*  
*状态: 可用，支持任务分配和Agent协调*
