#!/bin/bash

# 备得福榨菜竞品分析 - 快速启动脚本
# 老大，这个脚本可以直接启动整个多Agent协作分析流程

echo "=== 备得福榨菜竞品分析多Agent协作系统 ==="
echo "启动时间: $(date)"
echo ""

# 检查Python环境
if ! command -v python3 &> /dev/null; then
    echo "❌ 错误: 未找到Python3环境"
    exit 1
fi

# 检查必要目录
REQUIRED_DIRS=(
    "/vol1/1000/iflow/skills/task-coordinator/scripts"
    "/vol1/1000/iflow/skills/task-coordinator/tasks"
    "/vol1/1000/iflow/skills/task-coordinator/logs"
    "/vol1/1000/iflow/sync_workspace"
)

for dir in "${REQUIRED_DIRS[@]}"; do
    if [ ! -d "$dir" ]; then
        echo "📁 创建目录: $dir"
        mkdir -p "$dir"
    fi
done

echo "✅ 环境检查完成"
echo ""

# 显示任务概览
echo "📊 任务概览:"
echo "  - 分析竞品数量: 10个"
echo "  - 参与Agent数量: 8个"
echo "  - 预计执行时间: 60分钟"
echo "  - 分析维度: 6个核心维度"
echo ""

echo "👥 Agent分工:"
echo "  - 小明: 乌江榨菜市场策略分析"
echo "  - 小白: 鱼泉榨菜国际市场分析"
echo "  - 小陈: 铜钱桥榨菜区域竞争分析"
echo "  - 小李: 乡下妹榨菜产品差异化分析"
echo "  - 小张: 六必居&吉香居品牌定位对比"
echo "  - 小王: 川南&聚味特价格策略分析"
echo "  - 小刘: 钱江榨菜渠道策略分析"
echo "  - 小赵: 红山方便榨菜地域特色分析"
echo ""

# 询问是否继续
read -p "是否开始执行分析? (y/N): " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "❌ 用户取消执行"
    exit 0
fi

echo ""
echo "🚀 启动多Agent协作分析..."
echo ""

# 切换到脚本目录
cd /vol1/1000/iflow/skills/task-coordinator/scripts

# 执行分析脚本
python3 beidefu_analysis_executor.py

# 检查执行结果
if [ $? -eq 0 ]; then
    echo ""
    echo "🎉 分析执行成功!"
    echo ""
    echo "📁 查看结果文件:"
    echo "  - 工作空间: /vol1/1000/iflow/sync_workspace/"
    echo "  - 项目总结: /vol1/1000/iflow/skills/task-coordinator/results/beidefu_project_summary.md"
    echo "  - 任务配置: /vol1/1000/iflow/skills/task-coordinator/tasks/beidefu_competitor_analysis.json"
    echo "  - Agent指令: /vol1/1000/iflow/skills/task-coordinator/tasks/agent_instructions.md"
    echo ""
    echo "📊 主要输出:"
    echo "  - 8份Agent独立分析报告"
    echo "  - 1份综合对比分析报告"
    echo "  - 1套备得福战略建议"
    echo "  - 1个可执行的行动计划"
    echo ""
    echo "📋 查看日志:"
    echo "  tail -f /vol1/1000/iflow/skills/task-coordinator/logs/beidefu_analysis.log"
else
    echo ""
    echo "❌ 分析执行失败!"
    echo ""
    echo "🔍 排查建议:"
    echo "  1. 检查Python环境: python3 --version"
    echo "  2. 查看错误日志: tail -50 /vol1/1000/iflow/skills/task-coordinator/logs/beidefu_analysis.log"
    echo "  3. 检查依赖模块: python3 -c 'import task_coordinator'"
    echo ""
    exit 1
fi

echo ""
echo "=== 任务完成 ==="
echo "结束时间: $(date)"
echo ""