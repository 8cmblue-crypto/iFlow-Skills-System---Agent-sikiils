#!/usr/bin/env python3
"""
好好视力竞争对手调研任务验证脚本
老大，这是验证好好视力调研任务配置是否正确的脚本
"""

import json
import os
import sys
from pathlib import Path

def validate_task_config():
    """验证任务配置文件"""
    print("🔍 验证任务配置文件...")
    
    config_path = "/vol1/1000/iflow/skills/task-coordinator/tasks/haohao_vision_competitor_analysis.json"
    
    if not os.path.exists(config_path):
        print(f"❌ 任务配置文件不存在: {config_path}")
        return False
    
    try:
        with open(config_path, 'r', encoding='utf-8') as f:
            config = json.load(f)
        
        # 验证必要字段
        required_fields = [
            'task_name', 'task_description', 'task_priority', 
            'estimated_time', 'agents', 'deliverables'
        ]
        
        for field in required_fields:
            if field not in config:
                print(f"❌ 缺少必要字段: {field}")
                return False
        
        # 验证Agent配置
        if not isinstance(config['agents'], list) or len(config['agents']) == 0:
            print("❌ Agent配置不正确")
            return False
        
        agent_names = [agent['agent_name'] for agent in config['agents']]
        expected_agents = ['小张', '小李', '小王', '小刘']
        
        for expected_agent in expected_agents:
            if expected_agent not in agent_names:
                print(f"❌ 缺少Agent: {expected_agent}")
                return False
        
        print("✅ 任务配置文件验证通过")
        return True
        
    except json.JSONDecodeError as e:
        print(f"❌ JSON格式错误: {e}")
        return False
    except Exception as e:
        print(f"❌ 验证任务配置失败: {e}")
        return False

def validate_agent_instructions():
    """验证Agent指令文件"""
    print("🔍 验证Agent指令文件...")
    
    instructions_path = "/vol1/1000/iflow/skills/task-coordinator/tasks/haohao_vision_agent_instructions.md"
    
    if not os.path.exists(instructions_path):
        print(f"❌ Agent指令文件不存在: {instructions_path}")
        return False
    
    try:
        with open(instructions_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # 检查关键内容
        required_sections = [
            "Agent1 - 小张（博士眼镜市场领导地位分析）",
            "Agent2 - 小李（好视力产品创新与营销分析）", 
            "Agent3 - 小王（康耐特供应链与技术优势分析）",
            "Agent4 - 小刘（区域品牌竞争分析）"
        ]
        
        for section in required_sections:
            if section not in content:
                print(f"❌ 缺少Agent指令部分: {section}")
                return False
        
        print("✅ Agent指令文件验证通过")
        return True
        
    except Exception as e:
        print(f"❌ 验证Agent指令文件失败: {e}")
        return False

def validate_executor_script():
    """验证执行脚本"""
    print("🔍 验证执行脚本...")
    
    script_path = "/vol1/1000/iflow/skills/task-coordinator/scripts/haohao_vision_analysis_executor.py"
    
    if not os.path.exists(script_path):
        print(f"❌ 执行脚本不存在: {script_path}")
        return False
    
    try:
        with open(script_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # 检查关键类和函数
        required_elements = [
            "class HaoHaoVisionCompetitorAnalysis",
            "def run_complete_analysis",
            "def load_task_config",
            "def setup_agent_profiles",
            "def assign_tasks_to_agents"
        ]
        
        for element in required_elements:
            if element not in content:
                print(f"❌ 执行脚本缺少必要元素: {element}")
                return False
        
        print("✅ 执行脚本验证通过")
        return True
        
    except Exception as e:
        print(f"❌ 验证执行脚本失败: {e}")
        return False

def validate_directories():
    """验证必要目录"""
    print("🔍 验证目录结构...")
    
    required_dirs = [
        "/vol1/1000/iflow/skills/task-coordinator/logs",
        "/vol1/1000/iflow/skills/task-coordinator/results",
        "/vol1/1000/iflow/sync_workspace"
    ]
    
    for dir_path in required_dirs:
        if not os.path.exists(dir_path):
            print(f"📁 创建目录: {dir_path}")
            os.makedirs(dir_path, exist_ok=True)
    
    print("✅ 目录结构验证通过")
    return True

def validate_dependencies():
    """验证依赖项"""
    print("🔍 验证依赖项...")
    
    # 检查task_coordinator模块
    coordinator_path = "/vol1/1000/iflow/skills/task-coordinator/scripts/task_coordinator.py"
    if not os.path.exists(coordinator_path):
        print(f"❌ 缺少task_coordinator模块: {coordinator_path}")
        return False
    
    print("✅ 依赖项验证通过")
    return True

def main():
    """主验证函数"""
    print("=" * 60)
    print("好好视力竞争对手调研 - 任务配置验证")
    print("=" * 60)
    print()
    
    validations = [
        ("任务配置文件", validate_task_config),
        ("Agent指令文件", validate_agent_instructions), 
        ("执行脚本", validate_executor_script),
        ("目录结构", validate_directories),
        ("依赖项", validate_dependencies)
    ]
    
    all_passed = True
    
    for name, validator in validations:
        try:
            if not validator():
                all_passed = False
        except Exception as e:
            print(f"❌ {name}验证出现异常: {e}")
            all_passed = False
        print()
    
    print("=" * 60)
    if all_passed:
        print("✅ 所有验证通过，任务配置正确！")
        print("🚀 可以运行启动脚本开始调研任务:")
        print("   ./start_haohao_vision_analysis.sh")
    else:
        print("❌ 验证失败，请修复上述问题后重试")
    print("=" * 60)
    
    return 0 if all_passed else 1

if __name__ == "__main__":
    exit(main())