#!/usr/bin/env python3
"""
任务拆解器
老大，这个模块负责将复杂任务拆解为可执行的子任务
"""

import json
import re
from typing import Dict, List, Any
from dataclasses import dataclass
import logging

logger = logging.getLogger(__name__)

@dataclass
class SubTask:
    """子任务数据结构"""
    id: str
    name: str
    description: str
    estimated_time: int
    required_capabilities: List[str]
    dependencies: List[str]
    priority: int

class TaskDecomposer:
    """任务拆解器"""
    
    def __init__(self):
        # 预定义的拆解规则
        self.decomposition_rules = {
            "code_review": {
                "keywords": ["代码审查", "code review", "代码检查", "代码分析"],
                "subtasks": [
                    {
                        "name": "代码质量检查",
                        "description": "检查代码质量、规范性和最佳实践",
                        "capabilities": ["code_analysis"],
                        "time_ratio": 0.3
                    },
                    {
                        "name": "安全漏洞扫描",
                        "description": "扫描安全漏洞和潜在风险点",
                        "capabilities": ["security_check"],
                        "time_ratio": 0.4
                    },
                    {
                        "name": "性能分析",
                        "description": "分析代码性能和优化建议",
                        "capabilities": ["performance_analysis"],
                        "time_ratio": 0.3
                    }
                ]
            },
            "documentation": {
                "keywords": ["文档", "documentation", "文档生成", "说明"],
                "subtasks": [
                    {
                        "name": "API文档生成",
                        "description": "生成API接口文档",
                        "capabilities": ["api_docs"],
                        "time_ratio": 0.5
                    },
                    {
                        "name": "用户指南编写",
                        "description": "编写用户使用指南",
                        "capabilities": ["user_guides"],
                        "time_ratio": 0.3
                    },
                    {
                        "name": "示例代码整理",
                        "description": "整理和编写示例代码",
                        "capabilities": ["markdown_generation"],
                        "time_ratio": 0.2
                    }
                ]
            },
            "testing": {
                "keywords": ["测试", "test", "单元测试", "集成测试"],
                "subtasks": [
                    {
                        "name": "单元测试编写",
                        "description": "编写单元测试用例",
                        "capabilities": ["unit_testing"],
                        "time_ratio": 0.4
                    },
                    {
                        "name": "集成测试",
                        "description": "执行集成测试",
                        "capabilities": ["integration_testing"],
                        "time_ratio": 0.3
                    },
                    {
                        "name": "测试报告生成",
                        "description": "生成测试报告和覆盖率分析",
                        "capabilities": ["test_analysis"],
                        "time_ratio": 0.3
                    }
                ]
            }
        }
    
    def decompose(self, task) -> List[Dict]:
        """拆解任务"""
        logger.info(f"开始拆解任务: {task.name}")
        
        # 分析任务类型
        task_type = self._identify_task_type(task.description)
        
        # 根据任务类型选择拆解策略
        if task_type in self.decomposition_rules:
            subtasks = self._apply_decomposition_rule(task, task_type)
        else:
            # 通用拆解策略
            subtasks = self._generic_decomposition(task)
        
        # 验证和优化子任务
        subtasks = self._validate_and_optimize_subtasks(subtasks)
        
        logger.info(f"任务 {task.name} 拆解完成，生成 {len(subtasks)} 个子任务")
        return subtasks
    
    def _identify_task_type(self, description: str) -> str:
        """识别任务类型"""
        description_lower = description.lower()
        
        for task_type, rule in self.decomposition_rules.items():
            for keyword in rule["keywords"]:
                if keyword in description_lower:
                    return task_type
        
        return "general"
    
    def _apply_decomposition_rule(self, task, task_type: str) -> List[Dict]:
        """应用特定的拆解规则"""
        rule = self.decomposition_rules[task_type]
        subtasks = []
        
        for i, subtask_rule in enumerate(rule["subtasks"]):
            subtask_id = f"{task.id}-sub-{i+1:03d}"
            
            # 计算子任务时间
            estimated_time = int(task.estimated_time * subtask_rule["time_ratio"])
            
            subtask = SubTask(
                id=subtask_id,
                name=subtask_rule["name"],
                description=subtask_rule["description"],
                estimated_time=estimated_time,
                required_capabilities=subtask_rule["capabilities"],
                dependencies=[],
                priority=self._calculate_priority(task.priority, subtask_rule["time_ratio"])
            )
            
            subtasks.append(subtask.__dict__)
        
        return subtasks
    
    def _generic_decomposition(self, task) -> List[Dict]:
        """通用任务拆解策略"""
        subtasks = []
        
        # 分析任务复杂度
        complexity = self._assess_complexity(task.description)
        
        if complexity > 0.8:
            # 高复杂度任务，拆解为多个阶段
            subtasks = self._complex_task_decomposition(task)
        elif complexity > 0.5:
            # 中等复杂度任务，拆解为2-3个子任务
            subtasks = self._medium_task_decomposition(task)
        else:
            # 低复杂度任务，可能不需要拆解或简单拆解
            subtasks = self._simple_task_decomposition(task)
        
        return subtasks
    
    def _assess_complexity(self, description: str) -> float:
        """评估任务复杂度"""
        complexity_indicators = {
            "高": ["分析", "设计", "架构", "系统", "复杂", "全面", "完整"],
            "中": ["实现", "开发", "测试", "优化", "改进"],
            "低": ["检查", "修复", "更新", "简单", "基础"]
        }
        
        description_lower = description.lower()
        word_count = len(description.split())
        
        # 基础复杂度（基于字数）
        if word_count > 100:
            base_complexity = 0.8
        elif word_count > 50:
            base_complexity = 0.6
        elif word_count > 20:
            base_complexity = 0.4
        else:
            base_complexity = 0.2
        
        # 基于关键词调整复杂度
        for level, keywords in complexity_indicators.items():
            for keyword in keywords:
                if keyword in description_lower:
                    if level == "高":
                        base_complexity = min(1.0, base_complexity + 0.2)
                    elif level == "中":
                        base_complexity = min(0.8, base_complexity + 0.1)
                    else:
                        base_complexity = max(0.2, base_complexity - 0.1)
        
        return base_complexity
    
    def _complex_task_decomposition(self, task) -> List[Dict]:
        """复杂任务拆解"""
        subtasks = []
        
        # 阶段1：分析和规划
        subtask1 = SubTask(
            id=f"{task.id}-sub-001",
            name="需求分析和规划",
            description="分析任务需求，制定执行计划",
            estimated_time=int(task.estimated_time * 0.2),
            required_capabilities=["analysis", "planning"],
            dependencies=[],
            priority=10
        )
        
        # 阶段2：核心实现
        subtask2 = SubTask(
            id=f"{task.id}-sub-002",
            name="核心功能实现",
            description="实现任务的核心功能",
            estimated_time=int(task.estimated_time * 0.5),
            required_capabilities=task.required_capabilities,
            dependencies=[subtask1.id],
            priority=8
        )
        
        # 阶段3：测试和验证
        subtask3 = SubTask(
            id=f"{task.id}-sub-003",
            name="测试和验证",
            description="测试功能，验证结果",
            estimated_time=int(task.estimated_time * 0.2),
            required_capabilities=["testing", "validation"],
            dependencies=[subtask2.id],
            priority=6
        )
        
        # 阶段4：文档和总结
        subtask4 = SubTask(
            id=f"{task.id}-sub-004",
            name="文档编写和总结",
            description="编写相关文档，总结执行结果",
            estimated_time=int(task.estimated_time * 0.1),
            required_capabilities=["documentation"],
            dependencies=[subtask3.id],
            priority=4
        )
        
        subtasks = [subtask1.__dict__, subtask2.__dict__, subtask3.__dict__, subtask4.__dict__]
        return subtasks
    
    def _medium_task_decomposition(self, task) -> List[Dict]:
        """中等复杂度任务拆解"""
        subtasks = []
        
        # 子任务1：准备和分析
        subtask1 = SubTask(
            id=f"{task.id}-sub-001",
            name="准备和分析",
            description="准备所需资源，分析任务要求",
            estimated_time=int(task.estimated_time * 0.3),
            required_capabilities=["analysis"],
            dependencies=[],
            priority=8
        )
        
        # 子任务2：执行和实现
        subtask2 = SubTask(
            id=f"{task.id}-sub-002",
            name="执行和实现",
            description="执行主要任务内容",
            estimated_time=int(task.estimated_time * 0.6),
            required_capabilities=task.required_capabilities,
            dependencies=[subtask1.id],
            priority=10
        )
        
        # 子任务3：验证和整理
        subtask3 = SubTask(
            id=f"{task.id}-sub-003",
            name="验证和整理",
            description="验证结果，整理输出",
            estimated_time=int(task.estimated_time * 0.1),
            required_capabilities=["validation"],
            dependencies=[subtask2.id],
            priority=6
        )
        
        subtasks = [subtask1.__dict__, subtask2.__dict__, subtask3.__dict__]
        return subtasks
    
    def _simple_task_decomposition(self, task) -> List[Dict]:
        """简单任务拆解"""
        # 对于简单任务，可能不需要拆解，或者只拆解为2个子任务
        if task.estimated_time < 300:  # 小于5分钟
            # 不拆解，直接返回原任务
            return [{
                "id": f"{task.id}-sub-001",
                "name": task.name,
                "description": task.description,
                "estimated_time": task.estimated_time,
                "required_capabilities": task.required_capabilities,
                "dependencies": [],
                "priority": 10
            }]
        else:
            # 拆解为准备和执行两个阶段
            subtask1 = SubTask(
                id=f"{task.id}-sub-001",
                name="准备工作",
                description="准备执行任务所需的资源和环境",
                estimated_time=int(task.estimated_time * 0.2),
                required_capabilities=["preparation"],
                dependencies=[],
                priority=8
            )
            
            subtask2 = SubTask(
                id=f"{task.id}-sub-002",
                name="主要执行",
                description="执行任务的主要内容",
                estimated_time=int(task.estimated_time * 0.8),
                required_capabilities=task.required_capabilities,
                dependencies=[subtask1.id],
                priority=10
            )
            
            return [subtask1.__dict__, subtask2.__dict__]
    
    def _calculate_priority(self, task_priority: str, time_ratio: float) -> int:
        """计算子任务优先级"""
        base_priority = {
            "high": 10,
            "medium": 6,
            "low": 3
        }.get(task_priority, 6)
        
        # 根据时间比例调整优先级
        adjusted_priority = int(base_priority * (0.5 + time_ratio))
        return max(1, min(10, adjusted_priority))
    
    def _validate_and_optimize_subtasks(self, subtasks: List[Dict]) -> List[Dict]:
        """验证和优化子任务"""
        validated_subtasks = []
        
        for subtask in subtasks:
            # 验证必要字段
            required_fields = ["id", "name", "description", "estimated_time", "required_capabilities"]
            if all(field in subtask for field in required_fields):
                # 确保estimated_time是正整数
                subtask["estimated_time"] = max(60, subtask["estimated_time"])
                
                # 确保required_capabilities不为空
                if not subtask["required_capabilities"]:
                    subtask["required_capabilities"] = ["general"]
                
                validated_subtasks.append(subtask)
            else:
                logger.warning(f"子任务验证失败: {subtask.get('name', 'Unknown')}")
        
        return validated_subtasks