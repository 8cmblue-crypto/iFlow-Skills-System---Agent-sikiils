#!/usr/bin/env python3
"""
任务记忆系统 - 记录和学习历史任务经验
老大，这个系统能记住每次任务的配置、执行过程和结果，让下次类似任务更快更全面
"""

import json
import os
import time
import hashlib
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional, Any
import logging

logger = logging.getLogger(__name__)

class TaskMemorySystem:
    """任务记忆系统 - 记录、学习和复用历史任务经验"""
    
    def __init__(self, memory_dir: str = "/vol1/1000/iflow/skills/task-coordinator/memory"):
        self.memory_dir = Path(memory_dir)
        self.memory_dir.mkdir(exist_ok=True)
        
        # 记忆文件路径
        self.task_history_file = self.memory_dir / "task_history.json"
        self.task_patterns_file = self.memory_dir / "task_patterns.json"
        self.agent_performance_file = self.memory_dir / "agent_performance.json"
        self.task_templates_file = self.memory_dir / "learned_templates.json"
        
        # 初始化记忆存储
        self._initialize_memory_storage()
    
    def _initialize_memory_storage(self):
        """初始化记忆存储文件"""
        storage_files = {
            "task_history": {},
            "task_patterns": {},
            "agent_performance": {},
            "learned_templates": {}
        }
        
        for file_name, default_data in storage_files.items():
            file_path = getattr(self, f"{file_name}_file")
            if not file_path.exists():
                with open(file_path, 'w', encoding='utf-8') as f:
                    json.dump(default_data, f, ensure_ascii=False, indent=2)
                logger.info(f"初始化记忆存储: {file_name}")
    
    def _generate_task_signature(self, task_config: Dict) -> str:
        """生成任务特征签名，用于识别相似任务"""
        # 提取任务关键特征
        key_features = {
            "task_type": task_config.get("task_name", ""),
            "agent_count": len(task_config.get("agents", [])),
            "coordination_type": task_config.get("coordination_type", ""),
            "focus_areas": [agent.get("focus_area", "") for agent in task_config.get("agents", [])],
            "competitor_count": sum(len(agent.get("assigned_competitors", [])) 
                                 for agent in task_config.get("agents", []))
        }
        
        # 生成签名
        feature_str = json.dumps(key_features, sort_keys=True)
        signature = hashlib.md5(feature_str.encode()).hexdigest()[:12]
        
        return signature
    
    def record_task_execution(self, task_config: Dict, execution_results: Dict, 
                            performance_metrics: Dict):
        """记录任务执行过程和结果"""
        try:
            task_id = execution_results.get("task_id", f"task_{int(time.time())}")
            task_signature = self._generate_task_signature(task_config)
            
            # 记录任务历史
            task_record = {
                "task_id": task_id,
                "task_signature": task_signature,
                "task_name": task_config.get("task_name", ""),
                "execution_time": execution_results.get("execution_time", 0),
                "completed_at": datetime.now().isoformat(),
                "task_config": task_config,
                "execution_results": execution_results,
                "performance_metrics": performance_metrics,
                "success_rate": performance_metrics.get("success_rate", 0),
                "agent_count": len(task_config.get("agents", [])),
                "total_competitors": sum(len(agent.get("assigned_competitors", [])) 
                                      for agent in task_config.get("agents", []))
            }
            
            # 读取现有历史
            with open(self.task_history_file, 'r', encoding='utf-8') as f:
                task_history = json.load(f)
            
            # 添加新记录
            task_history[task_id] = task_record
            
            # 保持历史记录在合理范围内（保留最近50个）
            if len(task_history) > 50:
                # 按时间排序，删除最旧的
                sorted_tasks = sorted(task_history.items(), 
                                    key=lambda x: x[1]["completed_at"])
                for old_task_id, _ in sorted_tasks[:-50]:
                    del task_history[old_task_id]
            
            # 保存更新后的历史
            with open(self.task_history_file, 'w', encoding='utf-8') as f:
                json.dump(task_history, f, ensure_ascii=False, indent=2)
            
            # 更新模式识别
            self._update_task_patterns(task_signature, task_record)
            
            # 更新Agent性能记录
            self._update_agent_performance(task_config, performance_metrics)
            
            logger.info(f"任务执行已记录: {task_id} (签名: {task_signature})")
            return True
            
        except Exception as e:
            logger.error(f"记录任务执行失败: {e}")
            return False
    
    def _update_task_patterns(self, task_signature: str, task_record: Dict):
        """更新任务模式识别"""
        try:
            with open(self.task_patterns_file, 'r', encoding='utf-8') as f:
                patterns = json.load(f)
            
            if task_signature not in patterns:
                patterns[task_signature] = {
                    "pattern_name": task_record.get("task_name", ""),
                    "execution_count": 0,
                    "total_execution_time": 0,
                    "success_count": 0,
                    "avg_success_rate": 0,
                    "best_practices": [],
                    "common_issues": [],
                    "optimized_config": None,
                    "first_seen": task_record["completed_at"],
                    "last_seen": task_record["completed_at"]
                }
            
            pattern = patterns[task_signature]
            pattern["execution_count"] += 1
            pattern["total_execution_time"] += task_record.get("execution_time", 0)
            pattern["last_seen"] = task_record["completed_at"]
            
            # 更新成功率
            if task_record.get("success_rate", 0) > 80:
                pattern["success_count"] += 1
            
            pattern["avg_success_rate"] = (pattern["success_count"] / 
                                         pattern["execution_count"]) * 100
            
            # 如果是成功的任务，记录最佳实践
            if task_record.get("success_rate", 0) > 90:
                self._extract_best_practices(pattern, task_record)
            
            # 保存更新的模式
            with open(self.task_patterns_file, 'w', encoding='utf-8') as f:
                json.dump(patterns, f, ensure_ascii=False, indent=2)
                
        except Exception as e:
            logger.error(f"更新任务模式失败: {e}")
    
    def _extract_best_practices(self, pattern: Dict, task_record: Dict):
        """提取最佳实践"""
        try:
            best_practices = pattern.get("best_practices", [])
            
            # 提取成功的配置要素
            task_config = task_record.get("task_config", {})
            
            practice = {
                "agent_allocation": task_config.get("agents", []),
                "coordination_type": task_config.get("coordination_type", ""),
                "estimated_time": task_config.get("estimated_time", 0),
                "actual_time": task_record.get("execution_time", 0),
                "efficiency_score": task_config.get("estimated_time", 1) / max(task_record.get("execution_time", 1), 1),
                "recorded_at": task_record["completed_at"]
            }
            
            # 避免重复实践
            practice_str = json.dumps(practice, sort_keys=True)
            if not any(json.dumps(bp, sort_keys=True) == practice_str for bp in best_practices):
                best_practices.append(practice)
                
                # 保持最佳实践在合理数量
                if len(best_practices) > 10:
                    best_practices = best_practices[-10:]
                
                pattern["best_practices"] = best_practices
                
        except Exception as e:
            logger.error(f"提取最佳实践失败: {e}")
    
    def _update_agent_performance(self, task_config: Dict, performance_metrics: Dict):
        """更新Agent性能记录"""
        try:
            with open(self.agent_performance_file, 'r', encoding='utf-8') as f:
                agent_perf = json.load(f)
            
            agents = task_config.get("agents", [])
            
            for agent in agents:
                agent_name = agent.get("agent_name", "")
                agent_type = agent.get("agent_type", "")
                
                if agent_name not in agent_perf:
                    agent_perf[agent_name] = {
                        "agent_type": agent_type,
                        "total_tasks": 0,
                        "successful_tasks": 0,
                        "avg_execution_time": 0,
                        "total_execution_time": 0,
                        "specialties": [],
                        "performance_history": [],
                        "last_updated": None
                    }
                
                perf = agent_perf[agent_name]
                perf["total_tasks"] += 1
                perf["total_execution_time"] += performance_metrics.get("execution_time", 0)
                perf["avg_execution_time"] = perf["total_execution_time"] / perf["total_tasks"]
                perf["last_updated"] = datetime.now().isoformat()
                
                # 记录专长领域
                focus_area = agent.get("focus_area", "")
                if focus_area and focus_area not in perf["specialties"]:
                    perf["specialties"].append(focus_area)
                
                # 记录性能历史
                perf["performance_history"].append({
                    "task_id": performance_metrics.get("task_id", ""),
                    "execution_time": performance_metrics.get("execution_time", 0),
                    "success_rate": performance_metrics.get("success_rate", 0),
                    "recorded_at": datetime.now().isoformat()
                })
                
                # 保持历史记录在合理范围
                if len(perf["performance_history"]) > 20:
                    perf["performance_history"] = perf["performance_history"][-20:]
            
            # 保存更新的Agent性能
            with open(self.agent_performance_file, 'w', encoding='utf-8') as f:
                json.dump(agent_perf, f, ensure_ascii=False, indent=2)
                
        except Exception as e:
            logger.error(f"更新Agent性能失败: {e}")
    
    def query_similar_tasks(self, task_config: Dict, limit: int = 5) -> List[Dict]:
        """查询相似的历史任务"""
        try:
            task_signature = self._generate_task_signature(task_config)
            
            with open(self.task_history_file, 'r', encoding='utf-8') as f:
                task_history = json.load(f)
            
            # 查找相同签名的任务
            similar_tasks = []
            for task_id, record in task_history.items():
                if record.get("task_signature") == task_signature:
                    similar_tasks.append(record)
            
            # 按成功率和时间排序
            similar_tasks.sort(key=lambda x: (
                x.get("success_rate", 0), 
                x.get("completed_at", "")
            ), reverse=True)
            
            return similar_tasks[:limit]
            
        except Exception as e:
            logger.error(f"查询相似任务失败: {e}")
            return []
    
    def get_task_pattern_insights(self, task_config: Dict) -> Dict:
        """获取任务模式洞察"""
        try:
            task_signature = self._generate_task_signature(task_config)
            
            with open(self.task_patterns_file, 'r', encoding='utf-8') as f:
                patterns = json.load(f)
            
            if task_signature not in patterns:
                return {"status": "no_pattern_found", "message": "未找到相似任务模式"}
            
            pattern = patterns[task_signature]
            
            # 生成洞察建议
            insights = {
                "status": "pattern_found",
                "pattern_name": pattern.get("pattern_name", ""),
                "execution_count": pattern.get("execution_count", 0),
                "avg_success_rate": pattern.get("avg_success_rate", 0),
                "avg_execution_time": (pattern.get("total_execution_time", 0) / 
                                    max(pattern.get("execution_count", 1), 1)),
                "recommendations": []
            }
            
            # 基于历史数据生成建议
            if pattern.get("avg_success_rate", 0) > 85:
                insights["recommendations"].append("此类型任务历史成功率较高，可参考过往配置")
            
            if pattern.get("best_practices"):
                insights["recommendations"].append(f"发现{len(pattern['best_practices'])}个最佳实践可供参考")
            
            # 推荐最优配置
            best_practices = pattern.get("best_practices", [])
            if best_practices:
                best_practice = max(best_practices, key=lambda x: x.get("efficiency_score", 0))
                insights["recommended_config"] = {
                    "estimated_time": best_practice.get("actual_time", 0),
                    "coordination_type": best_practice.get("coordination_type", ""),
                    "agent_allocation": best_practice.get("agent_allocation", [])
                }
            
            return insights
            
        except Exception as e:
            logger.error(f"获取任务模式洞察失败: {e}")
            return {"status": "error", "message": str(e)}
    
    def get_agent_recommendations(self, task_config: Dict) -> Dict:
        """获取Agent推荐"""
        try:
            with open(self.agent_performance_file, 'r', encoding='utf-8') as f:
                agent_perf = json.load(f)
            
            required_focus_areas = [agent.get("focus_area", "") 
                                  for agent in task_config.get("agents", [])]
            
            recommendations = {
                "recommended_agents": {},
                "alternative_agents": {},
                "performance_ranking": []
            }
            
            # 为每个任务推荐最适合的Agent
            for i, focus_area in enumerate(required_focus_areas):
                if not focus_area:
                    continue
                
                suitable_agents = []
                for agent_name, perf in agent_perf.items():
                    if focus_area in perf.get("specialties", []):
                        suitable_agents.append({
                            "agent_name": agent_name,
                            "agent_type": perf.get("agent_type", ""),
                            "success_rate": (perf.get("successful_tasks", 0) / 
                                          max(perf.get("total_tasks", 1), 1)) * 100,
                            "avg_execution_time": perf.get("avg_execution_time", 0),
                            "total_tasks": perf.get("total_tasks", 0)
                        })
                
                # 按成功率和经验排序
                suitable_agents.sort(key=lambda x: (x.get("success_rate", 0), 
                                                 x.get("total_tasks", 0)), reverse=True)
                
                if suitable_agents:
                    recommendations["recommended_agents"][focus_area] = suitable_agents[:3]
                    recommendations["performance_ranking"].extend(suitable_agents[:1])
            
            return recommendations
            
        except Exception as e:
            logger.error(f"获取Agent推荐失败: {e}")
            return {"error": str(e)}
    
    def generate_optimized_config(self, task_config: Dict) -> Dict:
        """基于历史经验生成优化配置"""
        try:
            # 获取模式洞察
            pattern_insights = self.get_task_pattern_insights(task_config)
            
            # 获取Agent推荐
            agent_recommendations = self.get_agent_recommendations(task_config)
            
            optimized_config = task_config.copy()
            
            # 应用时间估算优化
            if pattern_insights.get("status") == "pattern_found":
                avg_time = pattern_insights.get("avg_execution_time", 0)
                if avg_time > 0:
                    optimized_config["estimated_time"] = int(avg_time * 0.9)  # 预留10%优化空间
                
                # 应用推荐配置
                if "recommended_config" in pattern_insights:
                    rec_config = pattern_insights["recommended_config"]
                    if rec_config.get("coordination_type"):
                        optimized_config["coordination_type"] = rec_config["coordination_type"]
            
            # 应用Agent优化
            if "recommended_agents" in agent_recommendations:
                current_agents = optimized_config.get("agents", [])
                for i, agent in enumerate(current_agents):
                    focus_area = agent.get("focus_area", "")
                    if focus_area in agent_recommendations["recommended_agents"]:
                        best_agents = agent_recommendations["recommended_agents"][focus_area]
                        if best_agents:
                            # 推荐表现最好的Agent
                            best_agent = best_agents[0]
                            optimized_config["agents"][i]["recommended_agent"] = best_agent["agent_name"]
                            optimized_config["agents"][i]["expected_success_rate"] = best_agent["success_rate"]
            
            # 添加优化说明
            optimized_config["optimization_info"] = {
                "generated_at": datetime.now().isoformat(),
                "based_on_patterns": pattern_insights.get("execution_count", 0),
                "optimizations_applied": len(pattern_insights.get("recommendations", [])),
                "confidence_level": min(pattern_insights.get("avg_success_rate", 50) + 10, 95)
            }
            
            return optimized_config
            
        except Exception as e:
            logger.error(f"生成优化配置失败: {e}")
            return task_config
    
    def get_memory_summary(self) -> Dict:
        """获取记忆系统概览"""
        try:
            summary = {
                "total_tasks_recorded": 0,
                "unique_patterns": 0,
                "agents_tracked": 0,
                "memory_size_mb": 0,
                "last_updated": None
            }
            
            # 统计任务历史
            with open(self.task_history_file, 'r', encoding='utf-8') as f:
                task_history = json.load(f)
            summary["total_tasks_recorded"] = len(task_history)
            
            # 统计模式数量
            with open(self.task_patterns_file, 'r', encoding='utf-8') as f:
                patterns = json.load(f)
            summary["unique_patterns"] = len(patterns)
            
            # 统计Agent数量
            with open(self.agent_performance_file, 'r', encoding='utf-8') as f:
                agent_perf = json.load(f)
            summary["agents_tracked"] = len(agent_perf)
            
            # 计算存储大小
            total_size = 0
            for file_path in [self.task_history_file, self.task_patterns_file, 
                            self.agent_performance_file, self.task_templates_file]:
                if file_path.exists():
                    total_size += file_path.stat().st_size
            summary["memory_size_mb"] = round(total_size / (1024 * 1024), 2)
            
            # 获取最后更新时间
            if task_history:
                latest_task = max(task_history.values(), 
                                key=lambda x: x.get("completed_at", ""))
                summary["last_updated"] = latest_task.get("completed_at")
            
            return summary
            
        except Exception as e:
            logger.error(f"获取记忆概览失败: {e}")
            return {"error": str(e)}