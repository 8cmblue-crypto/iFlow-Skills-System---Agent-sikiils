#!/usr/bin/env python3
"""
简化的任务记忆系统 - 老大，这个版本简洁好用
"""

import json
import os
import time
from datetime import datetime
from pathlib import Path
import logging

logger = logging.getLogger(__name__)

class SimpleTaskMemory:
    """简化的任务记忆系统"""
    
    def __init__(self, memory_file: str = "/vol1/1000/iflow/skills/task-coordinator/memory/task_memory.json"):
        self.memory_file = Path(memory_file)
        self.memory_file.parent.mkdir(exist_ok=True)
        
        # 初始化记忆文件
        if not self.memory_file.exists():
            self._init_memory()
    
    def _init_memory(self):
        """初始化记忆存储"""
        memory_data = {
            "tasks": {},
            "patterns": {},
            "last_updated": datetime.now().isoformat()
        }
        with open(self.memory_file, 'w', encoding='utf-8') as f:
            json.dump(memory_data, f, ensure_ascii=False, indent=2)
    
    def _get_task_key(self, task_config):
        """生成任务特征键"""
        key_parts = [
            task_config.get("task_name", ""),
            str(len(task_config.get("agents", []))),
            task_config.get("coordination_type", "")
        ]
        return "_".join(key_parts)
    
    def save_task(self, task_config, execution_result):
        """保存任务记录"""
        try:
            task_key = self._get_task_key(task_config)
            
            # 读取现有记忆
            with open(self.memory_file, 'r', encoding='utf-8') as f:
                memory = json.load(f)
            
            # 保存任务记录
            task_record = {
                "task_id": execution_result.get("task_id", ""),
                "task_name": task_config.get("task_name", ""),
                "completed_at": datetime.now().isoformat(),
                "execution_time": execution_result.get("execution_time", 0),
                "agent_count": len(task_config.get("agents", [])),
                "success": execution_result.get("success", True),
                "task_config": task_config
            }
            
            memory["tasks"][task_key] = task_record
            
            # 更新模式统计
            if task_key not in memory["patterns"]:
                memory["patterns"][task_key] = {
                    "count": 0,
                    "total_time": 0,
                    "success_count": 0,
                    "avg_time": 0,
                    "success_rate": 0
                }
            
            pattern = memory["patterns"][task_key]
            pattern["count"] += 1
            pattern["total_time"] += task_record["execution_time"]
            pattern["avg_time"] = pattern["total_time"] / pattern["count"]
            
            if task_record["success"]:
                pattern["success_count"] += 1
            
            pattern["success_rate"] = (pattern["success_count"] / pattern["count"]) * 100
            memory["last_updated"] = datetime.now().isoformat()
            
            # 保存更新
            with open(self.memory_file, 'w', encoding='utf-8') as f:
                json.dump(memory, f, ensure_ascii=False, indent=2)
            
            logger.info(f"任务已记录: {task_key}")
            return True
            
        except Exception as e:
            logger.error(f"保存任务失败: {e}")
            return False
    
    def get_similar_task(self, task_config):
        """获取相似任务经验"""
        try:
            task_key = self._get_task_key(task_config)
            
            with open(self.memory_file, 'r', encoding='utf-8') as f:
                memory = json.load(f)
            
            # 查找相同任务模式
            if task_key in memory["patterns"]:
                pattern = memory["patterns"][task_key]
                
                suggestion = {
                    "found": True,
                    "task_count": pattern["count"],
                    "avg_time": pattern["avg_time"],
                    "success_rate": pattern["success_rate"],
                    "suggestion": ""
                }
                
                # 生成建议
                if pattern["success_rate"] > 80:
                    suggestion["suggestion"] = f"此类任务成功率{pattern['success_rate']:.1f}%，预计用时{pattern['avg_time']:.1f}秒"
                else:
                    suggestion["suggestion"] = "此类任务成功率较低，建议优化配置"
                
                return suggestion
            
            return {"found": False, "suggestion": "新任务类型，按默认配置执行"}
            
        except Exception as e:
            logger.error(f"查询相似任务失败: {e}")
            return {"found": False, "suggestion": "查询失败，按默认配置执行"}
    
    def get_memory_summary(self):
        """获取记忆概览"""
        try:
            with open(self.memory_file, 'r', encoding='utf-8') as f:
                memory = json.load(f)
            
            return {
                "total_tasks": len(memory["tasks"]),
                "pattern_types": len(memory["patterns"]),
                "last_updated": memory.get("last_updated", "未知")
            }
            
        except Exception as e:
            logger.error(f"获取记忆概览失败: {e}")
            return {"error": str(e)}