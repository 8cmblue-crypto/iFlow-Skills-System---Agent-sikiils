#!/usr/bin/env python3
"""
文件同步系统
老大，这个模块负责在多个Agent之间同步文件和共享数据
"""

import os
import json
import hashlib
import shutil
from typing import Dict, List, Any, Optional, Set
from dataclasses import dataclass
from datetime import datetime
import threading
import logging

logger = logging.getLogger(__name__)

@dataclass
class FileMetadata:
    """文件元数据"""
    file_path: str
    checksum: str
    last_modified: float
    size: int
    agent_id: str
    version: int
    sync_status: str

@dataclass
class SyncOperation:
    """同步操作记录"""
    operation_id: str
    operation_type: str  # upload, download, delete, merge
    file_path: str
    source_agent: str
    target_agents: List[str]
    timestamp: datetime
    status: str
    error_message: Optional[str]

class FileSyncSystem:
    """文件同步系统"""
    
    def __init__(self, workspace_root: str = "/vol1/1000/iflow"):
        self.workspace_root = workspace_root
        self.sync_dir = os.path.join(workspace_root, "sync_workspace")
        self.metadata_file = os.path.join(self.sync_dir, "file_metadata.json")
        self.sync_log = os.path.join(self.sync_dir, "sync_operations.json")
        
        # 确保同步目录存在
        os.makedirs(self.sync_dir, exist_ok=True)
        
        # 文件元数据存储
        self.file_metadata: Dict[str, FileMetadata] = {}
        self.sync_operations: List[SyncOperation] = []
        
        # 锁机制，防止并发冲突
        self.sync_lock = threading.RLock()
        
        # 加载现有元数据
        self._load_metadata()
        self._load_sync_operations()
        
        # 冲突解决策略
        self.conflict_strategies = {
            "timestamp": self._resolve_by_timestamp,
            "size": self._resolve_by_size,
            "content": self._resolve_by_content_similarity,
            "manual": self._manual_conflict_resolution
        }
    
    def _load_metadata(self):
        """加载文件元数据"""
        if os.path.exists(self.metadata_file):
            try:
                with open(self.metadata_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    for file_path, metadata in data.items():
                        self.file_metadata[file_path] = FileMetadata(**metadata)
                logger.info(f"加载了 {len(self.file_metadata)} 个文件的元数据")
            except Exception as e:
                logger.error(f"加载元数据失败: {e}")
    
    def _load_sync_operations(self):
        """加载同步操作记录"""
        if os.path.exists(self.sync_log):
            try:
                with open(self.sync_log, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    for operation in data:
                        # 转换时间戳
                        operation['timestamp'] = datetime.fromisoformat(operation['timestamp'])
                        self.sync_operations.append(SyncOperation(**operation))
                logger.info(f"加载了 {len(self.sync_operations)} 个同步操作记录")
            except Exception as e:
                logger.error(f"加载同步操作记录失败: {e}")
    
    def _save_metadata(self):
        """保存文件元数据"""
        try:
            # 转换为可序列化的格式
            serializable_data = {}
            for file_path, metadata in self.file_metadata.items():
                serializable_data[file_path] = {
                    "file_path": metadata.file_path,
                    "checksum": metadata.checksum,
                    "last_modified": metadata.last_modified,
                    "size": metadata.size,
                    "agent_id": metadata.agent_id,
                    "version": metadata.version,
                    "sync_status": metadata.sync_status
                }
            
            with open(self.metadata_file, 'w', encoding='utf-8') as f:
                json.dump(serializable_data, f, indent=2, ensure_ascii=False)
        except Exception as e:
            logger.error(f"保存元数据失败: {e}")
    
    def _save_sync_operations(self):
        """保存同步操作记录"""
        try:
            # 转换为可序列化的格式
            serializable_data = []
            for operation in self.sync_operations:
                serializable_data.append({
                    "operation_id": operation.operation_id,
                    "operation_type": operation.operation_type,
                    "file_path": operation.file_path,
                    "source_agent": operation.source_agent,
                    "target_agents": operation.target_agents,
                    "timestamp": operation.timestamp.isoformat(),
                    "status": operation.status,
                    "error_message": operation.error_message
                })
            
            with open(self.sync_log, 'w', encoding='utf-8') as f:
                json.dump(serializable_data, f, indent=2, ensure_ascii=False)
        except Exception as e:
            logger.error(f"保存同步操作记录失败: {e}")
    
    def register_file(self, file_path: str, agent_id: str) -> bool:
        """注册文件到同步系统"""
        with self.sync_lock:
            try:
                # 获取绝对路径
                abs_path = os.path.abspath(file_path)
                
                # 检查文件是否存在
                if not os.path.exists(abs_path):
                    logger.error(f"文件不存在: {abs_path}")
                    return False
                
                # 计算文件元数据
                checksum = self._calculate_checksum(abs_path)
                stat = os.stat(abs_path)
                
                # 检查是否已存在
                if abs_path in self.file_metadata:
                    existing = self.file_metadata[abs_path]
                    
                    # 检查是否有冲突
                    if existing.checksum != checksum and existing.agent_id != agent_id:
                        # 发现冲突
                        conflict_result = self._handle_file_conflict(abs_path, existing, checksum, agent_id)
                        if not conflict_result:
                            logger.warning(f"文件冲突未解决: {abs_path}")
                            return False
                
                # 更新元数据
                version = self.file_metadata.get(abs_path, FileMetadata("", "", 0, 0, "", 0, "")).version + 1
                
                metadata = FileMetadata(
                    file_path=abs_path,
                    checksum=checksum,
                    last_modified=stat.st_mtime,
                    size=stat.st_size,
                    agent_id=agent_id,
                    version=version,
                    sync_status="registered"
                )
                
                self.file_metadata[abs_path] = metadata
                self._save_metadata()
                
                logger.info(f"文件注册成功: {abs_path} (Agent: {agent_id})")
                return True
                
            except Exception as e:
                logger.error(f"注册文件失败: {e}")
                return False
    
    def sync_file_to_agents(self, file_path: str, source_agent: str, target_agents: List[str]) -> bool:
        """将文件同步到目标Agent"""
        with self.sync_lock:
            try:
                abs_path = os.path.abspath(file_path)
                
                # 检查文件是否已注册
                if abs_path not in self.file_metadata:
                    logger.error(f"文件未注册: {abs_path}")
                    return False
                
                # 创建同步操作记录
                operation_id = f"sync_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{len(self.sync_operations)}"
                
                operation = SyncOperation(
                    operation_id=operation_id,
                    operation_type="upload",
                    file_path=abs_path,
                    source_agent=source_agent,
                    target_agents=target_agents,
                    timestamp=datetime.now(),
                    status="in_progress",
                    error_message=None
                )
                
                self.sync_operations.append(operation)
                
                # 执行同步
                success = self._perform_file_sync(abs_path, source_agent, target_agents)
                
                # 更新操作状态
                operation.status = "completed" if success else "failed"
                if not success:
                    operation.error_message = "同步执行失败"
                
                self._save_sync_operations()
                
                return success
                
            except Exception as e:
                logger.error(f"文件同步失败: {e}")
                return False
    
    def _perform_file_sync(self, file_path: str, source_agent: str, target_agents: List[str]) -> bool:
        """执行实际的文件同步"""
        try:
            # 在同步目录中创建Agent专用目录
            for agent_id in target_agents:
                agent_sync_dir = os.path.join(self.sync_dir, agent_id)
                os.makedirs(agent_sync_dir, exist_ok=True)
                
                # 目标文件路径
                target_path = os.path.join(agent_sync_dir, os.path.basename(file_path))
                
                # 复制文件
                shutil.copy2(file_path, target_path)
                
                logger.info(f"文件已同步到Agent {agent_id}: {target_path}")
            
            # 更新文件同步状态
            if file_path in self.file_metadata:
                self.file_metadata[file_path].sync_status = "synced"
                self._save_metadata()
            
            return True
            
        except Exception as e:
            logger.error(f"执行文件同步失败: {e}")
            return False
    
    def get_file_for_agent(self, file_path: str, agent_id: str) -> Optional[str]:
        """为Agent获取文件"""
        try:
            abs_path = os.path.abspath(file_path)
            
            # 检查文件是否在同步目录中
            agent_sync_dir = os.path.join(self.sync_dir, agent_id)
            agent_file_path = os.path.join(agent_sync_dir, os.path.basename(abs_path))
            
            if os.path.exists(agent_file_path):
                return agent_file_path
            
            # 如果不在同步目录，尝试从源位置复制
            if os.path.exists(abs_path):
                os.makedirs(agent_sync_dir, exist_ok=True)
                shutil.copy2(abs_path, agent_file_path)
                return agent_file_path
            
            return None
            
        except Exception as e:
            logger.error(f"获取文件失败: {e}")
            return None
    
    def _calculate_checksum(self, file_path: str) -> str:
        """计算文件校验和"""
        hash_md5 = hashlib.md5()
        try:
            with open(file_path, "rb") as f:
                for chunk in iter(lambda: f.read(4096), b""):
                    hash_md5.update(chunk)
            return hash_md5.hexdigest()
        except Exception as e:
            logger.error(f"计算校验和失败: {e}")
            return ""
    
    def _handle_file_conflict(self, file_path: str, existing: FileMetadata, new_checksum: str, new_agent: str) -> bool:
        """处理文件冲突"""
        logger.warning(f"检测到文件冲突: {file_path}")
        
        # 使用时间戳策略解决冲突
        return self.conflict_strategies["timestamp"](file_path, existing, new_checksum, new_agent)
    
    def _resolve_by_timestamp(self, file_path: str, existing: FileMetadata, new_checksum: str, new_agent: str) -> bool:
        """按时间戳解决冲突"""
        try:
            current_stat = os.stat(file_path)
            current_mtime = current_stat.st_mtime
            
            if current_mtime > existing.last_modified:
                # 新文件更新，接受新文件
                logger.info(f"按时间戳解决冲突: 接受新文件 {file_path}")
                return True
            else:
                # 现有文件更新，拒绝新文件
                logger.info(f"按时间戳解决冲突: 拒绝新文件 {file_path}")
                return False
                
        except Exception as e:
            logger.error(f"时间戳冲突解决失败: {e}")
            return False
    
    def _resolve_by_size(self, file_path: str, existing: FileMetadata, new_checksum: str, new_agent: str) -> bool:
        """按文件大小解决冲突"""
        try:
            current_stat = os.stat(file_path)
            current_size = current_stat.st_size
            
            if current_size != existing.size:
                # 大小不同，选择较大的文件
                if current_size > existing.size:
                    logger.info(f"按大小解决冲突: 接受较大的文件 {file_path}")
                    return True
                else:
                    logger.info(f"按大小解决冲突: 保留现有的较大文件 {file_path}")
                    return False
            else:
                # 大小相同，按时间戳解决
                return self._resolve_by_timestamp(file_path, existing, new_checksum, new_agent)
                
        except Exception as e:
            logger.error(f"大小冲突解决失败: {e}")
            return False
    
    def _resolve_by_content_similarity(self, file_path: str, existing: FileMetadata, new_checksum: str, new_agent: str) -> bool:
        """按内容相似度解决冲突"""
        # 如果校验和相同，没有冲突
        if existing.checksum == new_checksum:
            return True
        
        # 对于文本文件，可以计算相似度
        try:
            if file_path.endswith(('.txt', '.py', '.js', '.json', '.md')):
                with open(file_path, 'r', encoding='utf-8') as f:
                    current_content = f.read()
                
                # 这里可以实现更复杂的相似度算法
                # 简单起见，如果内容差异不大，接受新文件
                if len(current_content) > 0:
                    logger.info(f"按内容相似度解决冲突: 接受新文件 {file_path}")
                    return True
            
            # 对于非文本文件或无法确定相似度，按时间戳解决
            return self._resolve_by_timestamp(file_path, existing, new_checksum, new_agent)
            
        except Exception as e:
            logger.error(f"内容相似度冲突解决失败: {e}")
            return False
    
    def _manual_conflict_resolution(self, file_path: str, existing: FileMetadata, new_checksum: str, new_agent: str) -> bool:
        """手动冲突解决（暂不实现）"""
        logger.info(f"需要手动解决冲突: {file_path}")
        # 暂时按时间戳解决
        return self._resolve_by_timestamp(file_path, existing, new_checksum, new_agent)
    
    def get_sync_status(self) -> Dict[str, Any]:
        """获取同步状态"""
        with self.sync_lock:
            status = {
                "total_files": len(self.file_metadata),
                "synced_files": sum(1 for f in self.file_metadata.values() if f.sync_status == "synced"),
                "pending_files": sum(1 for f in self.file_metadata.values() if f.sync_status == "registered"),
                "total_operations": len(self.sync_operations),
                "completed_operations": sum(1 for op in self.sync_operations if op.status == "completed"),
                "failed_operations": sum(1 for op in self.sync_operations if op.status == "failed"),
                "recent_operations": []
            }
            
            # 最近的操作
            recent_ops = sorted(self.sync_operations, key=lambda x: x.timestamp, reverse=True)[:10]
            status["recent_operations"] = [
                {
                    "operation_id": op.operation_id,
                    "operation_type": op.operation_type,
                    "file_path": os.path.basename(op.file_path),
                    "source_agent": op.source_agent,
                    "target_agents": op.target_agents,
                    "timestamp": op.timestamp.isoformat(),
                    "status": op.status
                }
                for op in recent_ops
            ]
            
            return status
    
    def cleanup_old_files(self, days: int = 7) -> int:
        """清理旧文件"""
        with self.sync_lock:
            try:
                cutoff_time = datetime.now().timestamp() - (days * 24 * 3600)
                removed_count = 0
                
                # 清理元数据中的旧文件
                files_to_remove = []
                for file_path, metadata in self.file_metadata.items():
                    if metadata.last_modified < cutoff_time and not os.path.exists(file_path):
                        files_to_remove.append(file_path)
                
                for file_path in files_to_remove:
                    del self.file_metadata[file_path]
                    removed_count += 1
                
                # 清理同步目录中的旧文件
                for agent_dir in os.listdir(self.sync_dir):
                    agent_path = os.path.join(self.sync_dir, agent_dir)
                    if os.path.isdir(agent_path):
                        for file_name in os.listdir(agent_path):
                            file_path = os.path.join(agent_path, file_name)
                            if os.path.getmtime(file_path) < cutoff_time:
                                os.remove(file_path)
                                removed_count += 1
                
                # 清理旧的同步操作记录
                cutoff_ops_time = datetime.now().timestamp() - (30 * 24 * 3600)  # 30天
                self.sync_operations = [
                    op for op in self.sync_operations 
                    if op.timestamp.timestamp() > cutoff_ops_time
                ]
                
                self._save_metadata()
                self._save_sync_operations()
                
                logger.info(f"清理完成，删除了 {removed_count} 个旧文件/记录")
                return removed_count
                
            except Exception as e:
                logger.error(f"清理旧文件失败: {e}")
                return 0
    
    def create_shared_workspace(self, task_id: str, participating_agents: List[str]) -> str:
        """为任务创建共享工作空间"""
        try:
            workspace_path = os.path.join(self.sync_dir, f"task_{task_id}")
            os.makedirs(workspace_path, exist_ok=True)
            
            # 为每个Agent创建符号链接
            for agent_id in participating_agents:
                agent_link = os.path.join(workspace_path, f"agent_{agent_id}")
                agent_dir = os.path.join(self.sync_dir, agent_id)
                
                if not os.path.exists(agent_link) and os.path.exists(agent_dir):
                    os.symlink(agent_dir, agent_link)
            
            logger.info(f"创建共享工作空间: {workspace_path}")
            return workspace_path
            
        except Exception as e:
            logger.error(f"创建共享工作空间失败: {e}")
            return ""
    
    def get_file_changes_since(self, timestamp: float) -> List[Dict[str, Any]]:
        """获取指定时间以来的文件变更"""
        changes = []
        
        for file_path, metadata in self.file_metadata.items():
            if metadata.last_modified > timestamp:
                changes.append({
                    "file_path": file_path,
                    "last_modified": metadata.last_modified,
                    "agent_id": metadata.agent_id,
                    "version": metadata.version,
                    "checksum": metadata.checksum
                })
        
        return sorted(changes, key=lambda x: x["last_modified"], reverse=True)