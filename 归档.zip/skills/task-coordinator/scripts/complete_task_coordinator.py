#!/usr/bin/env python3
"""
完整任务协调器
整合所有组件，提供完整的任务分配、执行、监控和结果聚合功能
"""

import json
import time
import uuid
from datetime import datetime
from typing import Dict, List, Any, Optional
from pathlib import Path
import logging

# 导入各个组件
from session_manager import SessionManager
from result_aggregator import ResultAggregator
from task_coordinator import TaskCoordinator

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class CompleteTaskCoordinator:
    """完整任务协调器"""
    
    def __init__(self):
        self.session_manager = SessionManager()
        self.result_aggregator = ResultAggregator()
        self.task_coordinator = TaskCoordinator()
        self.workspace_path = Path("/vol1/1000/iflow/sync_workspace")
        self.active_tasks = {}
        
    def coordinate_task(self, task_config: Dict[str, Any]) -> Dict[str, Any]:
        """协调完整的任务执行流程"""
        try:
            # 生成任务ID
            task_id = f"task_{uuid.uuid4().hex[:8]}"
            
            logger.info(f"🚀 开始协调任务: {task_id}")
            
            # 创建任务记录
            task_record = {
                "task_id": task_id,
                "config": task_config,
                "status": "initializing",
                "created_at": datetime.now().isoformat(),
                "agents": {},
                "sessions": {},
                "results": {}
            }
            
            self.active_tasks[task_id] = task_record
            
            # 1. 任务初始化
            logger.info(f"📝 第一步: 任务初始化")
            init_result = self._initialize_task(task_id, task_config)
            if init_result["status"] != "success":
                return self._task_failed(task_id, "initialization", init_result["error"])
            
            task_record["status"] = "initialized"
            
            # 2. 创建Agent会话
            logger.info(f"🔧 第二步: 创建Agent会话")
            session_result = self._create_agent_sessions(task_id, task_config)
            if session_result["status"] != "success":
                return self._task_failed(task_id, "session_creation", session_result["error"])
            
            task_record["status"] = "sessions_created"
            task_record["sessions"] = session_result["sessions"]
            
            # 3. 分配任务给Agent
            logger.info(f"📤 第三步: 分配任务给Agent")
            assignment_result = self._assign_tasks_to_agents(task_id, task_config)
            if assignment_result["status"] != "success":
                return self._task_failed(task_id, "task_assignment", assignment_result["error"])
            
            task_record["status"] = "tasks_assigned"
            
            # 4. 监控任务执行
            logger.info(f"📊 第四步: 监控任务执行")
            monitoring_result = self._monitor_task_execution(task_id, task_config)
            
            task_record["status"] = "execution_completed"
            task_record["monitoring"] = monitoring_result
            
            # 5. 收集和聚合结果
            logger.info(f"📋 第五步: 收集和聚合结果")
            aggregation_result = self._aggregate_results(task_id)
            
            task_record["status"] = "completed"
            task_record["aggregation"] = aggregation_result
            
            # 6. 生成最终报告
            logger.info(f"📄 第六步: 生成最终报告")
            final_report = self._generate_final_report(task_id)
            
            task_record["status"] = "finalized"
            task_record["final_report"] = final_report
            task_record["completed_at"] = datetime.now().isoformat()
            
            logger.info(f"✅ 任务 {task_id} 协调完成")
            
            return {
                "status": "success",
                "task_id": task_id,
                "final_report": final_report,
                "execution_summary": self._create_execution_summary(task_record)
            }
            
        except Exception as e:
            logger.error(f"❌ 任务协调失败: {e}")
            return {
                "status": "error",
                "error": str(e),
                "timestamp": datetime.now().isoformat()
            }
    
    def _initialize_task(self, task_id: str, task_config: Dict[str, Any]) -> Dict[str, Any]:
        """初始化任务"""
        try:
            # 创建任务工作空间
            task_workspace = self.workspace_path / f"task_{task_id}"
            task_workspace.mkdir(parents=True, exist_ok=True)
            
            # 保存任务配置
            config_file = task_workspace / "task_config.json"
            with open(config_file, 'w', encoding='utf-8') as f:
                json.dump(task_config, f, ensure_ascii=False, indent=2)
            
            # 创建Agent指令文件
            instructions_file = task_workspace / "agent_instructions.md"
            self._create_agent_instructions(instructions_file, task_config)
            
            return {
                "status": "success",
                "task_id": task_id,
                "workspace": str(task_workspace)
            }
            
        except Exception as e:
            return {
                "status": "error",
                "error": str(e)
            }
    
    def _create_agent_instructions(self, instructions_file: Path, task_config: Dict[str, Any]):
        """创建Agent指令文件"""
        instructions = []
        
        if "agents" in task_config:
            for agent_config in task_config["agents"]:
                agent_name = agent_config["name"]
                agent_task = agent_config["task"]
                agent_focus = agent_config.get("focus", "general")
                
                instruction = f"""
## {agent_name} - {agent_task}

**任务编号**: TASK-{len(instructions) + 1}
**聚焦重点**: {agent_focus}
**预计完成时间**: 45分钟

### 核心要求:
{agent_task}

### 输出要求:
- 提交详细的分析报告
- 包含具体数据支撑
- 提供可执行的建议

### 注意事项:
- 必须使用真实数据，严禁编造
- 分析要有深度，避免表面化
- 建议要具体可执行
"""
                instructions.append(instruction)
        
        with open(instructions_file, 'w', encoding='utf-8') as f:
            f.write("# Agent任务指令集\n\n")
            f.write("\n".join(instructions))
    
    def _create_agent_sessions(self, task_id: str, task_config: Dict[str, Any]) -> Dict[str, Any]:
        """创建Agent会话"""
        try:
            sessions = {}
            task_description = task_config.get("description", "多Agent协作任务")
            
            if "agents" in task_config:
                for agent_config in task_config["agents"]:
                    agent_name = agent_config["name"]
                    
                    # 创建会话
                    session_result = self.session_manager.create_session(
                        agent_name, 
                        task_description
                    )
                    
                    if session_result["status"] == "success":
                        sessions[agent_name] = {
                            "session_id": session_result["session_id"],
                            "pid": session_result["pid"],
                            "created_at": session_result["created_at"],
                            "status": "active"
                        }
                        logger.info(f"✅ 创建会话成功: {agent_name} -> {session_result['session_id']}")
                    else:
                        logger.error(f"❌ 创建会话失败: {agent_name} -> {session_result.get('error')}")
                        sessions[agent_name] = {
                            "status": "failed",
                            "error": session_result.get("error")
                        }
            
            return {
                "status": "success",
                "sessions": sessions,
                "total_sessions": len(sessions),
                "successful_sessions": len([s for s in sessions.values() if s.get("status") == "active"])
            }
            
        except Exception as e:
            return {
                "status": "error",
                "error": str(e)
            }
    
    def _assign_tasks_to_agents(self, task_id: str, task_config: Dict[str, Any]) -> Dict[str, Any]:
        """分配任务给Agent"""
        try:
            assignments = {}
            
            if "agents" in task_config:
                for agent_config in task_config["agents"]:
                    agent_name = agent_config["name"]
                    task_command = agent_config.get("command", agent_config["task"])
                    
                    # 获取会话ID
                    session_id = self.active_tasks[task_id]["sessions"][agent_name]["session_id"]
                    
                    # 分配任务
                    assignment_result = self.session_manager.assign_task_to_session(
                        session_id,
                        task_command
                    )
                    
                    assignments[agent_name] = assignment_result
                    
                    if assignment_result["status"] == "success":
                        logger.info(f"✅ 任务分配成功: {agent_name}")
                    else:
                        logger.warning(f"⚠️ 任务分配有问题: {agent_name} -> {assignment_result.get('error')}")
            
            return {
                "status": "success",
                "assignments": assignments,
                "total_assignments": len(assignments),
                "successful_assignments": len([a for a in assignments.values() if a.get("status") == "success"])
            }
            
        except Exception as e:
            return {
                "status": "error",
                "error": str(e)
            }
    
    def _monitor_task_execution(self, task_id: str, task_config: Dict[str, Any]) -> Dict[str, Any]:
        """监控任务执行"""
        try:
            monitoring_duration = task_config.get("monitoring_duration", 60)  # 默认60秒
            check_interval = task_config.get("check_interval", 10)  # 默认10秒
            
            start_time = time.time()
            monitoring_results = []
            
            logger.info(f"⏳ 开始监控任务执行，持续时间: {monitoring_duration}秒")
            
            while time.time() - start_time < monitoring_duration:
                current_time = time.time() - start_time
                
                # 检查所有Agent状态
                agent_statuses = {}
                
                for agent_name, session_info in self.active_tasks[task_id]["sessions"].items():
                    if session_info.get("status") == "active":
                        session_id = session_info["session_id"]
                        status_result = self.session_manager.get_session_status(session_id)
                        agent_statuses[agent_name] = status_result
                
                monitoring_results.append({
                    "timestamp": datetime.now().isoformat(),
                    "elapsed_time": current_time,
                    "agent_statuses": agent_statuses
                })
                
                logger.info(f"📊 监控进度: {current_time:.1f}/{monitoring_duration}秒")
                
                time.sleep(check_interval)
            
            return {
                "status": "success",
                "monitoring_duration": monitoring_duration,
                "check_count": len(monitoring_results),
                "results": monitoring_results
            }
            
        except Exception as e:
            return {
                "status": "error",
                "error": str(e)
            }
    
    def _aggregate_results(self, task_id: str) -> Dict[str, Any]:
        """聚合结果"""
        try:
            # 使用结果聚合器
            aggregation_result = self.result_aggregator.collect_results_from_task(task_id)
            
            if aggregation_result["status"] == "success":
                # 创建综合报告
                report_result = self.result_aggregator.create_comprehensive_report(task_id)
                
                return {
                    "status": "success",
                    "aggregation": aggregation_result,
                    "comprehensive_report": report_result
                }
            else:
                return aggregation_result
                
        except Exception as e:
            return {
                "status": "error",
                "error": str(e)
            }
    
    def _generate_final_report(self, task_id: str) -> Dict[str, Any]:
        """生成最终报告"""
        try:
            task_record = self.active_tasks[task_id]
            
            final_report = {
                "task_id": task_id,
                "generated_at": datetime.now().isoformat(),
                "task_config": task_record["config"],
                "execution_timeline": self._create_execution_timeline(task_record),
                "agent_performance": self._analyze_agent_performance(task_record),
                "success_metrics": self._calculate_success_metrics(task_record),
                "recommendations": self._generate_recommendations(task_record)
            }
            
            # 保存最终报告
            report_file = self.workspace_path / f"final_report_{task_id}.json"
            with open(report_file, 'w', encoding='utf-8') as f:
                json.dump(final_report, f, ensure_ascii=False, indent=2)
            
            return {
                "status": "success",
                "report_file": str(report_file),
                "summary": final_report.get("success_metrics", {})
            }
            
        except Exception as e:
            return {
                "status": "error",
                "error": str(e)
            }
    
    def _task_failed(self, task_id: str, stage: str, error: str) -> Dict[str, Any]:
        """处理任务失败"""
        self.active_tasks[task_id]["status"] = "failed"
        self.active_tasks[task_id]["failed_stage"] = stage
        self.active_tasks[task_id]["error"] = error
        self.active_tasks[task_id]["failed_at"] = datetime.now().isoformat()
        
        logger.error(f"❌ 任务 {task_id} 在 {stage} 阶段失败: {error}")
        
        return {
            "status": "failed",
            "task_id": task_id,
            "failed_stage": stage,
            "error": error,
            "timestamp": datetime.now().isoformat()
        }
    
    def _create_execution_summary(self, task_record: Dict[str, Any]) -> Dict[str, Any]:
        """创建执行摘要"""
        return {
            "task_id": task_record["task_id"],
            "status": task_record["status"],
            "duration": self._calculate_duration(task_record),
            "agents_count": len(task_record.get("sessions", {})),
            "successful_sessions": len([s for s in task_record.get("sessions", {}).values() if s.get("status") == "active"]),
            "has_results": "aggregation" in task_record and task_record["aggregation"].get("status") == "success"
        }
    
    def _create_execution_timeline(self, task_record: Dict[str, Any]) -> List[Dict[str, Any]]:
        """创建执行时间线"""
        timeline = []
        
        # 添加各个阶段的时间点
        stages = [
            ("created_at", "任务创建"),
            ("initialized", "任务初始化完成"),
            ("sessions_created", "会话创建完成"),
            ("tasks_assigned", "任务分配完成"),
            ("execution_completed", "任务执行完成"),
            ("aggregation", "结果聚合完成"),
            ("finalized", "任务完成")
        ]
        
        for field, description in stages:
            if field in task_record:
                timeline.append({
                    "stage": description,
                    "timestamp": task_record[field]
                })
        
        return timeline
    
    def _analyze_agent_performance(self, task_record: Dict[str, Any]) -> Dict[str, Any]:
        """分析Agent性能"""
        performance = {}
        
        if "monitoring" in task_record:
            monitoring_results = task_record["monitoring"]["results"]
            
            for agent_name in task_record.get("sessions", {}):
                agent_performance = []
                
                for result in monitoring_results:
                    if agent_name in result["agent_statuses"]:
                        status = result["agent_statuses"][agent_name]
                        agent_performance.append({
                            "timestamp": result["timestamp"],
                            "status": status.get("session", {}).get("process_status", "unknown")
                        })
                
                performance[agent_name] = {
                    "status_checks": len(agent_performance),
                    "final_status": agent_performance[-1]["status"] if agent_performance else "unknown",
                    "status_history": agent_performance
                }
        
        return performance
    
    def _calculate_success_metrics(self, task_record: Dict[str, Any]) -> Dict[str, Any]:
        """计算成功指标"""
        metrics = {
            "overall_success": task_record["status"] == "finalized",
            "session_creation_rate": 0,
            "task_assignment_rate": 0,
            "result_collection_rate": 0
        }
        
        # 会话创建成功率
        sessions = task_record.get("sessions", {})
        if sessions:
            successful_sessions = len([s for s in sessions.values() if s.get("status") == "active"])
            metrics["session_creation_rate"] = successful_sessions / len(sessions)
        
        # 任务分配成功率
        if "assignments" in task_record.get("monitoring", {}).get("results", [{}])[-1]["agent_statuses"]:
            assignments = task_record["monitoring"]["results"][-1]["agent_statuses"]
            if assignments:
                successful_assignments = len([a for a in assignments.values() if a.get("status") == "success"])
                metrics["task_assignment_rate"] = successful_assignments / len(assignments)
        
        # 结果收集成功率
        if "aggregation" in task_record and task_record["aggregation"].get("status") == "success":
            aggregation_summary = task_record["aggregation"].get("summary", {})
            total_agents = aggregation_summary.get("total_agents", 0)
            if total_agents > 0:
                completed_agents = aggregation_summary.get("completed_agents", 0)
                metrics["result_collection_rate"] = completed_agents / total_agents
            else:
                metrics["result_collection_rate"] = 0.0
        
        return metrics
    
    def _generate_recommendations(self, task_record: Dict[str, Any]) -> List[str]:
        """生成建议"""
        recommendations = []
        metrics = self._calculate_success_metrics(task_record)
        
        if not metrics["overall_success"]:
            recommendations.append("🔧 任务执行失败，建议检查配置和依赖")
        
        if metrics["session_creation_rate"] < 1.0:
            recommendations.append(f"⚠️ 会话创建成功率 {metrics['session_creation_rate']:.1%}，建议检查系统资源")
        
        if metrics["task_assignment_rate"] < 1.0:
            recommendations.append(f"📋 任务分配成功率 {metrics['task_assignment_rate']:.1%}，建议检查任务配置")
        
        if metrics["result_collection_rate"] < 1.0:
            recommendations.append(f"📊 结果收集成功率 {metrics['result_collection_rate']:.1%}，建议检查Agent执行状态")
        
        if all(rate == 1.0 for rate in metrics.values() if isinstance(rate, float)):
            recommendations.append("🎯 所有步骤都成功完成，任务执行良好")
        
        return recommendations
    
    def _calculate_duration(self, task_record: Dict[str, Any]) -> str:
        """计算任务执行时长"""
        try:
            if "created_at" in task_record and "completed_at" in task_record:
                start = datetime.fromisoformat(task_record["created_at"])
                end = datetime.fromisoformat(task_record["completed_at"])
                duration = end - start
                return str(duration)
            else:
                return "N/A"
        except Exception:
            return "N/A"

def main():
    """主函数 - 测试完整任务协调器"""
    coordinator = CompleteTaskCoordinator()
    
    print("🚀 完整任务协调器测试")
    print("=" * 50)
    
    # 定义测试任务配置
    test_task_config = {
        "description": "备得福竞品分析测试任务",
        "monitoring_duration": 30,  # 30秒监控时间
        "check_interval": 10,  # 10秒检查间隔
        "agents": [
            {
                "name": "小明",
                "task": "分析乌江榨菜的市场策略",
                "focus": "市场策略分析",
                "command": "请分析乌江榨菜的市场竞争策略，重点关注其品牌定位、价格策略和渠道布局"
            },
            {
                "name": "小白",
                "task": "分析鱼泉榨菜的国际市场",
                "focus": "国际市场分析",
                "command": "请分析鱼泉榨菜的国际市场表现，重点关注其出口策略和海外渠道建设"
            }
        ]
    }
    
    print("📝 测试任务配置:")
    print(f"  描述: {test_task_config['description']}")
    print(f"  Agent数量: {len(test_task_config['agents'])}")
    print(f"  监控时长: {test_task_config['monitoring_duration']}秒")
    
    # 执行任务协调
    print(f"\n🔧 开始执行任务协调...")
    result = coordinator.coordinate_task(test_task_config)
    
    print(f"\n📊 任务协调结果:")
    print(f"  状态: {result['status']}")
    
    if result["status"] == "success":
        summary = result["execution_summary"]
        print(f"  任务ID: {summary['task_id']}")
        print(f"  最终状态: {summary['status']}")
        print(f"  执行时长: {summary['duration']}")
        print(f"  Agent数量: {summary['agents_count']}")
        print(f"  成功会话: {summary['successful_sessions']}")
        print(f"  有结果文件: {summary['has_results']}")
        
        if "final_report" in result:
            report_file = result["final_report"]["report_file"]
            print(f"  最终报告: {report_file}")
    else:
        print(f"  错误: {result.get('error', 'Unknown error')}")

if __name__ == "__main__":
    main()