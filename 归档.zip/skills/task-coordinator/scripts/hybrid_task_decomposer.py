#!/usr/bin/env python3
"""
混合任务拆解器
老大，结合死板规则和智能思考的优势，提供最优的任务拆解方案
"""

import sys
import os
from typing import Dict, List, Any

# 添加当前目录到Python路径
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from intelligent_task_decomposer import IntelligentTaskDecomposer, SubTask
from task_decomposer import TaskDecomposer
import logging

logger = logging.getLogger(__name__)

class HybridTaskDecomposer:
    """混合任务拆解器 - 智能优先，规则兜底"""
    
    def __init__(self):
        self.intelligent_decomposer = IntelligentTaskDecomposer()
        self.rule_decomposer = TaskDecomposer()
        
        # 策略选择规则
        self.strategy_rules = {
            "use_intelligent": [
                "complexity_high",
                "special_requirements", 
                "large_scope",
                "context_keywords_present",
                "mixed_capabilities"
            ],
            "use_rule_based": [
                "simple_template",
                "clear_type_match",
                "repetitive_task",
                "time_critical"
            ]
        }
    
    def decompose(self, task) -> List[Dict]:
        """混合拆解策略"""
        logger.info(f"开始混合策略拆解任务: {task.name}")
        
        # 1. 快速分析任务特征
        task_analysis = self._quick_analyze_task(task)
        
        # 2. 选择拆解策略
        strategy = self._choose_decomposition_strategy(task_analysis)
        
        # 3. 执行拆解
        if strategy == "intelligent":
            logger.info("使用智能思考拆解策略")
            subtasks = self.intelligent_decomposer.decompose(task)
        else:
            logger.info("使用死板规则拆解策略")
            subtasks = self.rule_decomposer.decompose(task)
        
        # 4. 策略交叉验证
        validated_subtasks = self._cross_validate_subtasks(subtasks, task_analysis, strategy)
        
        logger.info(f"混合策略拆解完成，使用{strategy}策略，生成{len(validated_subtasks)}个子任务")
        return validated_subtasks
    
    def _quick_analyze_task(self, task) -> Dict[str, Any]:
        """快速分析任务特征"""
        description_lower = task.description.lower()
        
        # 复杂度快速评估
        complexity_indicators = ["复杂", "系统", "架构", "全面", "多个", "集成"]
        complexity_score = sum(1 for indicator in complexity_indicators if indicator in description_lower)
        
        # 特殊要求检测
        special_requirements = []
        requirement_patterns = {
            "performance": ["性能", "优化", "速度", "延迟"],
            "security": ["安全", "加密", "防护", "漏洞"],
            "scalability": ["扩展", "大规模", "并发", "高可用"],
            "compatibility": ["兼容", "适配", "跨平台"]
        }
        
        for req_type, patterns in requirement_patterns.items():
            if any(pattern in description_lower for pattern in patterns):
                special_requirements.append(req_type)
        
        # 上下文关键词检测
        context_keywords = ["电商", "金融", "医疗", "教育", "企业", "系统", "模块"]
        has_context = any(keyword in description_lower for keyword in context_keywords)
        
        # 任务类型匹配度
        type_match_score = 0
        for task_type, rule in self.rule_decomposer.decomposition_rules.items():
            keyword_matches = sum(1 for keyword in rule["keywords"] if keyword in description_lower)
            if keyword_matches > 0:
                type_match_score = max(type_match_score, keyword_matches / len(rule["keywords"]))
        
        return {
            "complexity_score": complexity_score,
            "special_requirements": special_requirements,
            "has_context_keywords": has_context,
            "type_match_score": type_match_score,
            "description_length": len(task.description.split()),
            "mixed_capabilities": len(set(task.required_capabilities)) > 2 if task.required_capabilities else False
        }
    
    def _choose_decomposition_strategy(self, analysis: Dict[str, Any]) -> str:
        """选择拆解策略"""
        intelligent_score = 0
        rule_based_score = 0
        
        # 智能策略评分因子
        if analysis["complexity_score"] >= 2:
            intelligent_score += 3
        if analysis["special_requirements"]:
            intelligent_score += 2 * len(analysis["special_requirements"])
        if analysis["has_context_keywords"]:
            intelligent_score += 1
        if analysis["mixed_capabilities"]:
            intelligent_score += 1
        if analysis["description_length"] > 50:
            intelligent_score += 1
        
        # 规则策略评分因子
        if analysis["type_match_score"] > 0.7:
            rule_based_score += 3
        if analysis["complexity_score"] == 0:
            rule_based_score += 2
        if analysis["description_length"] < 30:
            rule_based_score += 1
        if not analysis["special_requirements"]:
            rule_based_score += 1
        
        # 选择策略
        if intelligent_score > rule_based_score:
            return "intelligent"
        elif rule_based_score > intelligent_score:
            return "rule_based"
        else:
            # 平衡时，倾向于智能策略
            return "intelligent"
    
    def _cross_validate_subtasks(self, subtasks: List[Dict], analysis: Dict, strategy: str) -> List[Dict]:
        """交叉验证子任务合理性"""
        validated_subtasks = []
        
        for subtask in subtasks:
            # 基础验证
            if not self._basic_validate_subtask(subtask):
                continue
            
            # 策略特定验证
            if strategy == "intelligent":
                subtask = self._enhance_intelligent_subtask(subtask, analysis)
            else:
                subtask = self._enhance_rule_based_subtask(subtask, analysis)
            
            validated_subtasks.append(subtask)
        
        return validated_subtasks
    
    def _basic_validate_subtask(self, subtask: Dict) -> bool:
        """基础子任务验证"""
        required_fields = ["id", "name", "description", "estimated_time", "required_capabilities"]
        return all(field in subtask for field in required_fields)
    
    def _enhance_intelligent_subtask(self, subtask: Dict, analysis: Dict) -> Dict:
        """增强智能拆解的子任务"""
        # 确保特殊要求被覆盖
        if analysis["special_requirements"]:
            current_caps = set(subtask["required_capabilities"])
            
            requirement_caps = {
                "performance": ["performance_analysis"],
                "security": ["security_check"],
                "scalability": ["scalability_analysis"],
                "compatibility": ["compatibility_testing"]
            }
            
            for req in analysis["special_requirements"]:
                if req in requirement_caps:
                    current_caps.update(requirement_caps[req])
            
            subtask["required_capabilities"] = list(current_caps)
        
        return subtask
    
    def _enhance_rule_based_subtask(self, subtask: Dict, analysis: Dict) -> Dict:
        """增强规则拆解的子任务"""
        # 添加上下文信息到描述
        if analysis["has_context_keywords"]:
            subtask["description"] += " (基于上下文优化)"
        
        # 添加特殊要求说明
        if analysis["special_requirements"]:
            subtask["description"] += f"，特别关注{', '.join(analysis['special_requirements'])}"
        
        return subtask

def test_hybrid_decomposition():
    """测试混合拆解策略"""
    print("=== 混合拆解策略测试 ===\n")
    
    from task_coordinator import Task
    from datetime import datetime
    
    # 测试任务
    test_tasks = [
        {
            "name": "简单API文档编写",
            "description": "编写用户API文档",
            "expected_strategy": "rule_based"
        },
        {
            "name": "复杂支付系统安全审查",
            "description": "对电商平台支付模块进行全面安全审查，包括SQL注入防护、XSS防护、数据加密，同时考虑高并发性能优化",
            "expected_strategy": "intelligent"
        },
        {
            "name": "代码质量检查",
            "description": "代码审查和代码质量检查",
            "expected_strategy": "rule_based"
        },
        {
            "name": "企业级系统架构重构",
            "description": "对整个企业级系统进行微服务架构重构，需要保证数据一致性、系统可用性和扩展性",
            "expected_strategy": "intelligent"
        }
    ]
    
    decomposer = HybridTaskDecomposer()
    
    for i, test_case in enumerate(test_tasks, 1):
        print(f"测试案例 {i}: {test_case['name']}")
        print(f"描述: {test_case['description']}")
        print(f"预期策略: {test_case['expected_strategy']}")
        
        task = Task(
            id=f"hybrid-test-{i:03d}",
            name=test_case['name'],
            description=test_case['description'],
            priority="medium",
            status="pending",
            created_at=datetime.now().isoformat(),
            estimated_time=300,
            required_capabilities=["analysis"],
            dependencies=[],
            subtasks=[]
        )
        
        # 快速分析
        analysis = decomposer._quick_analyze_task(task)
        strategy = decomposer._choose_decomposition_strategy(analysis)
        
        print(f"实际策略: {strategy}")
        print(f"分析结果: 复杂度{analysis['complexity_score']}, 特殊要求{analysis['special_requirements']}")
        
        # 执行拆解
        subtasks = decomposer.decompose(task)
        print(f"生成子任务: {len(subtasks)}个")
        
        for j, subtask in enumerate(subtasks, 1):
            print(f"  {j}. {subtask['name']} - {subtask['reasoning'] if 'reasoning' in subtask else '规则生成'}")
        
        print("\n" + "-" * 80 + "\n")

if __name__ == "__main__":
    test_hybrid_decomposition()