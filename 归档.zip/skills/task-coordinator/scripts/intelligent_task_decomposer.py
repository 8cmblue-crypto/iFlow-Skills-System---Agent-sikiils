#!/usr/bin/env python3
"""
智能任务拆解器
老大，这个模块负责将复杂任务拆解为可执行的子任务
基于规则进行智能思考，而非死板的规则匹配
"""

import json
import re
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
import logging

logger = logging.getLogger(__name__)

@dataclass
class SubTask:
    """子任务数据结构"""
    id: str
    name: str
    description: str
    estimated_time: int
    required_capabilities: List[str]
    dependencies: List[str]
    priority: int
    reasoning: str  # 添加思考过程记录

class IntelligentTaskDecomposer:
    """智能任务拆解器"""
    
    def __init__(self):
        # 拆解知识库（而非死规则）
        self.decomposition_knowledge = {
            "code_review": {
                "keywords": ["代码审查", "code review", "代码检查", "代码分析"],
                "typical_phases": [
                    {"phase": "质量检查", "capabilities": ["code_analysis"], "typical_ratio": 0.3},
                    {"phase": "安全扫描", "capabilities": ["security_check"], "typical_ratio": 0.4},
                    {"phase": "性能分析", "capabilities": ["performance_analysis"], "typical_ratio": 0.3}
                ],
                "considerations": [
                    "代码规模和复杂度",
                    "安全敏感度",
                    "性能要求",
                    "团队编码规范"
                ]
            },
            "documentation": {
                "keywords": ["文档", "documentation", "文档生成", "说明"],
                "typical_phases": [
                    {"phase": "API文档", "capabilities": ["api_docs"], "typical_ratio": 0.5},
                    {"phase": "用户指南", "capabilities": ["user_guides"], "typical_ratio": 0.3},
                    {"phase": "示例整理", "capabilities": ["markdown_generation"], "typical_ratio": 0.2}
                ],
                "considerations": [
                    "目标用户群体",
                    "技术深度要求",
                    "文档类型",
                    "维护复杂度"
                ]
            },
            "testing": {
                "keywords": ["测试", "test", "单元测试", "集成测试"],
                "typical_phases": [
                    {"phase": "单元测试", "capabilities": ["unit_testing"], "typical_ratio": 0.4},
                    {"phase": "集成测试", "capabilities": ["integration_testing"], "typical_ratio": 0.3},
                    {"phase": "测试报告", "capabilities": ["test_analysis"], "typical_ratio": 0.3}
                ],
                "considerations": [
                    "测试覆盖率要求",
                    "系统复杂度",
                    "性能测试需求",
                    "自动化程度"
                ]
            }
        }
    
    def decompose(self, task) -> List[Dict]:
        """智能拆解任务"""
        logger.info(f"开始智能拆解任务: {task.name}")
        
        # 1. 深度分析任务特征
        task_analysis = self._deep_analyze_task(task)
        
        # 2. 基于分析结果思考拆解策略
        decomposition_strategy = self._think_decomposition_strategy(task_analysis)
        
        # 3. 动态生成子任务
        subtasks = self._generate_adaptive_subtasks(task, task_analysis, decomposition_strategy)
        
        # 4. 验证和优化
        subtasks = self._validate_and_optimize_subtasks(subtasks, task_analysis)
        
        logger.info(f"任务 {task.name} 智能拆解完成，生成 {len(subtasks)} 个子任务")
        return subtasks
    
    def _deep_analyze_task(self, task) -> Dict[str, Any]:
        """深度分析任务特征"""
        analysis = {
            "raw_description": task.description,
            "task_type": self._identify_task_type_intelligently(task.description),
            "complexity_indicators": self._analyze_complexity_indicators(task.description),
            "context_keywords": self._extract_context_keywords(task.description),
            "scope_assessment": self._assess_task_scope(task.description),
            "special_requirements": self._identify_special_requirements(task.description),
            "estimated_effort": self._estimate_effort(task.description)
        }
        
        logger.info(f"任务分析结果: {analysis['task_type']}, 复杂度: {analysis['complexity_indicators']['overall']}")
        return analysis
    
    def _identify_task_type_intelligently(self, description: str) -> str:
        """智能识别任务类型"""
        description_lower = description.lower()
        
        # 计算每种类型的匹配度
        type_scores = {}
        for task_type, knowledge in self.decomposition_knowledge.items():
            score = 0
            keyword_matches = 0
            
            for keyword in knowledge["keywords"]:
                if keyword in description_lower:
                    keyword_matches += 1
                    # 根据关键词出现频率和位置计算权重
                    occurrences = description_lower.count(keyword)
                    score += occurrences * (1.0 + occurrences * 0.1)
            
            if keyword_matches > 0:
                type_scores[task_type] = score / len(knowledge["keywords"])
        
        # 返回得分最高的类型，或"general"
        if type_scores:
            best_type = max(type_scores, key=type_scores.get)
            if type_scores[best_type] > 0.3:  # 设置置信度阈值
                return best_type
        
        return "general"
    
    def _analyze_complexity_indicators(self, description: str) -> Dict[str, Any]:
        """分析复杂度指标"""
        complexity_markers = {
            "scope": ["系统", "模块", "整体", "全面", "完整", "架构"],
            "technical_depth": ["算法", "优化", "性能", "安全", "并发"],
            "integration": ["集成", "接口", "协作", "通信", "数据流"],
            "quality": ["测试", "验证", "审查", "文档", "规范"],
            "maintenance": ["维护", "扩展", "重构", "清理", "优化"]
        }
        
        description_lower = description.lower()
        complexity_scores = {}
        
        for dimension, markers in complexity_markers.items():
            score = sum(1 for marker in markers if marker in description_lower)
            complexity_scores[dimension] = score / len(markers)
        
        # 计算整体复杂度
        overall_complexity = sum(complexity_scores.values()) / len(complexity_scores)
        
        return {
            "dimensions": complexity_scores,
            "overall": overall_complexity,
            "word_count": len(description.split()),
            "sentence_count": len(re.split(r'[。！？]', description))
        }
    
    def _extract_context_keywords(self, description: str) -> List[str]:
        """提取上下文关键词"""
        # 技术栈关键词
        tech_keywords = ["python", "javascript", "java", "go", "rust", "react", "vue", "docker", "kubernetes"]
        
        # 业务领域关键词
        business_keywords = ["电商", "金融", "医疗", "教育", "社交", "游戏", "企业"]
        
        # 功能模块关键词
        module_keywords = ["用户", "订单", "支付", "库存", "物流", "客服", "报表"]
        
        description_lower = description.lower()
        extracted = []
        
        for keyword_list in [tech_keywords, business_keywords, module_keywords]:
            for keyword in keyword_list:
                if keyword in description_lower:
                    extracted.append(keyword)
        
        return extracted
    
    def _assess_task_scope(self, description: str) -> str:
        """评估任务范围"""
        scope_indicators = {
            "large": ["整个系统", "全面", "架构", "所有模块", "端到端"],
            "medium": ["模块", "组件", "功能", "部分", "特定"],
            "small": ["函数", "方法", "简单", "单个", "局部"]
        }
        
        description_lower = description.lower()
        scope_scores = {}
        
        for scope, indicators in scope_indicators.items():
            score = sum(1 for indicator in indicators if indicator in description_lower)
            scope_scores[scope] = score
        
        if scope_scores.get("large", 0) > 0:
            return "large"
        elif scope_scores.get("medium", 0) > 0:
            return "medium"
        else:
            return "small"
    
    def _identify_special_requirements(self, description: str) -> List[str]:
        """识别特殊要求"""
        special_patterns = {
            "performance": ["性能", "速度", "延迟", "吞吐量", "优化"],
            "security": ["安全", "加密", "权限", "漏洞", "防护"],
            "compatibility": ["兼容", "适配", "跨平台", "版本"],
            "scalability": ["扩展", "伸缩", "大规模", "高并发"],
            "usability": ["易用", "用户体验", "界面", "交互"]
        }
        
        description_lower = description.lower()
        requirements = []
        
        for requirement, patterns in special_patterns.items():
            if any(pattern in description_lower for pattern in patterns):
                requirements.append(requirement)
        
        return requirements
    
    def _estimate_effort(self, description: str) -> int:
        """估算工作量（分钟）"""
        base_effort = 60  # 基础60分钟
        
        # 根据字数调整
        word_count = len(description.split())
        if word_count > 100:
            base_effort *= 2.5
        elif word_count > 50:
            base_effort *= 1.8
        elif word_count > 20:
            base_effort *= 1.2
        
        # 根据复杂度调整
        complexity = self._analyze_complexity_indicators(description)
        complexity_multiplier = 1.0 + complexity["overall"]
        base_effort *= complexity_multiplier
        
        return int(base_effort)
    
    def _think_decomposition_strategy(self, analysis: Dict[str, Any]) -> Dict[str, Any]:
        """基于分析结果思考拆解策略"""
        strategy = {
            "approach": "adaptive",
            "reasoning": [],
            "adjustments": {},
            "custom_phases": []
        }
        
        task_type = analysis["task_type"]
        complexity = analysis["complexity_indicators"]["overall"]
        scope = analysis["scope_assessment"]
        
        # 基础策略思考
        if task_type != "general":
            knowledge = self.decomposition_knowledge[task_type]
            strategy["reasoning"].append(f"识别为{task_type}类型任务，参考典型阶段")
            strategy["base_phases"] = knowledge["typical_phases"]
        else:
            strategy["reasoning"].append("通用任务，基于复杂度和范围制定策略")
            strategy["base_phases"] = self._get_general_phases(complexity)
        
        # 复杂度调整思考
        if complexity > 0.7:
            strategy["reasoning"].append("高复杂度任务，增加详细分析和验证阶段")
            strategy["adjustments"]["add_validation"] = True
            strategy["adjustments"]["increase_review"] = True
        elif complexity < 0.3:
            strategy["reasoning"].append("低复杂度任务，简化流程")
            strategy["adjustments"]["simplify_process"] = True
        
        # 范围调整思考
        if scope == "large":
            strategy["reasoning"].append("大范围任务，增加协调和集成阶段")
            strategy["adjustments"]["add_coordination"] = True
        elif scope == "small":
            strategy["reasoning"].append("小范围任务，聚焦核心功能")
            strategy["adjustments"]["focus_core"] = True
        
        # 特殊要求调整
        special_reqs = analysis["special_requirements"]
        if "performance" in special_reqs:
            strategy["reasoning"].append("有性能要求，增加性能优化和测试阶段")
            strategy["adjustments"]["emphasize_performance"] = True
        
        if "security" in special_reqs:
            strategy["reasoning"].append("有安全要求，增加安全审查和加固阶段")
            strategy["adjustments"]["emphasize_security"] = True
        
        return strategy
    
    def _get_general_phases(self, complexity: float) -> List[Dict]:
        """获取通用任务的阶段"""
        if complexity > 0.7:
            return [
                {"phase": "需求分析", "capabilities": ["analysis"], "typical_ratio": 0.2},
                {"phase": "方案设计", "capabilities": ["design"], "typical_ratio": 0.3},
                {"phase": "核心实现", "capabilities": ["implementation"], "typical_ratio": 0.3},
                {"phase": "测试验证", "capabilities": ["testing"], "typical_ratio": 0.2}
            ]
        elif complexity > 0.4:
            return [
                {"phase": "准备分析", "capabilities": ["analysis"], "typical_ratio": 0.3},
                {"phase": "执行实现", "capabilities": ["implementation"], "typical_ratio": 0.5},
                {"phase": "验证整理", "capabilities": ["validation"], "typical_ratio": 0.2}
            ]
        else:
            return [
                {"phase": "直接执行", "capabilities": ["implementation"], "typical_ratio": 0.8},
                {"phase": "结果验证", "capabilities": ["validation"], "typical_ratio": 0.2}
            ]
    
    def _generate_adaptive_subtasks(self, task, analysis: Dict, strategy: Dict) -> List[Dict]:
        """动态生成自适应子任务"""
        subtasks = []
        total_time = analysis["estimated_effort"]
        
        base_phases = strategy.get("base_phases", [])
        
        for i, phase in enumerate(base_phases):
            # 基础子任务
            base_time = int(total_time * phase["typical_ratio"])
            
            # 根据策略调整时间分配
            adjusted_time = self._adjust_time_by_strategy(base_time, strategy, phase["phase"])
            
            # 根据特殊要求调整能力需求
            adjusted_capabilities = self._adjust_capabilities_by_requirements(
                phase["capabilities"], 
                analysis["special_requirements"]
            )
            
            # 生成子任务描述
            task_description = self._generate_subtask_description(
                phase["phase"], 
                analysis, 
                strategy
            )
            
            subtask = SubTask(
                id=f"{task.id}-sub-{i+1:03d}",
                name=phase["phase"],
                description=task_description,
                estimated_time=adjusted_time,
                required_capabilities=adjusted_capabilities,
                dependencies=self._calculate_dependencies(i, len(base_phases)),
                priority=self._calculate_priority(task.priority, i, len(base_phases)),
                reasoning=f"基于{strategy['approach']}策略，考虑{', '.join(strategy['reasoning'][-2:])}"
            )
            
            subtasks.append(subtask.__dict__)
        
        return subtasks
    
    def _adjust_time_by_strategy(self, base_time: int, strategy: Dict, phase_name: str) -> int:
        """根据策略调整时间分配"""
        adjusted_time = base_time
        
        # 复杂度调整
        if strategy["adjustments"].get("increase_review") and "审查" in phase_name:
            adjusted_time = int(adjusted_time * 1.3)
        
        if strategy["adjustments"].get("add_validation") and "验证" in phase_name:
            adjusted_time = int(adjusted_time * 1.2)
        
        # 特殊要求调整
        if strategy["adjustments"].get("emphasize_performance") and "性能" in phase_name:
            adjusted_time = int(adjusted_time * 1.4)
        
        if strategy["adjustments"].get("emphasize_security") and "安全" in phase_name:
            adjusted_time = int(adjusted_time * 1.3)
        
        return adjusted_time
    
    def _adjust_capabilities_by_requirements(self, base_capabilities: List[str], special_requirements: List[str]) -> List[str]:
        """根据特殊要求调整能力需求"""
        adjusted_capabilities = base_capabilities.copy()
        
        requirement_capability_map = {
            "performance": ["performance_analysis", "optimization"],
            "security": ["security_check", "security_audit"],
            "compatibility": ["compatibility_testing"],
            "scalability": ["scalability_analysis"],
            "usability": ["usability_testing"]
        }
        
        for req in special_requirements:
            if req in requirement_capability_map:
                adjusted_capabilities.extend(requirement_capability_map[req])
        
        return list(set(adjusted_capabilities))  # 去重
    
    def _generate_subtask_description(self, phase_name: str, analysis: Dict, strategy: Dict) -> str:
        """生成子任务描述"""
        context_keywords = analysis["context_keywords"]
        scope = analysis["scope_assessment"]
        
        description = f"执行{phase_name}阶段"
        
        # 添加上下文信息
        if context_keywords:
            description += f"，涉及{', '.join(context_keywords[:3])}"
        
        # 添加范围信息
        if scope == "large":
            description += "，需要考虑整体架构和模块间协调"
        elif scope == "medium":
            description += "，关注模块内部实现和接口"
        
        # 添加策略考虑
        if strategy["adjustments"].get("emphasize_performance"):
            description += "，重点关注性能优化"
        
        if strategy["adjustments"].get("emphasize_security"):
            description += "，重点关注安全加固"
        
        return description
    
    def _calculate_dependencies(self, current_index: int, total_phases: int) -> List[str]:
        """计算依赖关系"""
        if current_index == 0:
            return []
        else:
            # 简单的线性依赖
            return [f"sub-{current_index:03d}"]
    
    def _calculate_priority(self, task_priority: str, phase_index: int, total_phases: int) -> int:
        """计算优先级"""
        base_priority = {"high": 10, "medium": 6, "low": 3}.get(task_priority, 6)
        
        # 根据阶段位置调整优先级
        if phase_index == 0:  # 第一阶段优先级稍高
            return min(10, base_priority + 1)
        elif phase_index == total_phases - 1:  # 最后阶段优先级稍低
            return max(1, base_priority - 1)
        else:
            return base_priority
    
    def _validate_and_optimize_subtasks(self, subtasks: List[Dict], analysis: Dict) -> List[Dict]:
        """验证和优化子任务"""
        validated_subtasks = []
        
        # 检查必要字段
        for subtask in subtasks:
            required_fields = ["id", "name", "description", "estimated_time", "required_capabilities", "priority"]
            if all(field in subtask for field in required_fields):
                # 确保时间合理
                subtask["estimated_time"] = max(30, subtask["estimated_time"])
                
                # 确保能力不为空
                if not subtask["required_capabilities"]:
                    subtask["required_capabilities"] = ["general"]
                
                validated_subtasks.append(subtask)
            else:
                logger.warning(f"子任务验证失败: {subtask.get('name', 'Unknown')}")
        
        # 检查总时间合理性
        total_time = sum(subtask["estimated_time"] for subtask in validated_subtasks)
        estimated_effort = analysis["estimated_effort"]
        
        if abs(total_time - estimated_effort) > estimated_effort * 0.3:
            logger.info(f"调整子任务时间分配，原估算: {estimated_effort}，实际: {total_time}")
            # 按比例调整
            ratio = estimated_effort / total_time
            for subtask in validated_subtasks:
                subtask["estimated_time"] = int(subtask["estimated_time"] * ratio)
        
        return validated_subtasks