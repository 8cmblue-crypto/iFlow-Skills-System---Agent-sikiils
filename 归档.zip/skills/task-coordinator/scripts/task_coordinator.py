#!/usr/bin/env python3
"""
任务协调器核心模块
老大，这是任务分配协同技能的核心控制器
负责任务拆解、Agent分配、结果聚合和文件同步
"""

import json
import uuid
import time
import argparse
import os
import psutil
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Any, Optional
from dataclasses import dataclass, asdict
import logging

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('../logs/task_coordinator.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

@dataclass
class Task:
    """任务数据结构"""
    id: str
    name: str
    description: str
    priority: str
    status: str
    created_at: str
    estimated_time: int
    required_capabilities: List[str]
    dependencies: List[str]
    subtasks: List[Dict]
    assigned_agent: Optional[str] = None
    started_at: Optional[str] = None
    completed_at: Optional[str] = None
    result: Optional[Dict] = None

@dataclass
class Agent:
    """Agent数据结构"""
    id: str
    name: str
    capabilities: List[str]
    max_concurrent_tasks: int
    current_tasks: int
    specialties: List[str]
    status: str
    last_active: str

class TaskCoordinator:
    """任务协调器核心类"""
    
    def __init__(self, config_path: str = "../assets/config.json"):
        self.config_path = config_path
        self.config = self._load_config()
        self.tasks: Dict[str, Task] = {}
        self.agents: Dict[str, Agent] = {}
        self.task_queue = []
        self.active_assignments = {}
        
        # 创建必要目录
        self._create_directories()
        
        # 初始化组件
        self.file_sync_system = None
        self.result_aggregator = None
        self.agent_status_monitor = None
        
        # 初始化系统
        self._initialize()
    
    def _create_directories(self):
        """创建必要的目录结构"""
        directories = [
            "../results",
            "../logs", 
            "../templates",
            "../assets"
        ]
        for directory in directories:
            Path(directory).mkdir(parents=True, exist_ok=True)
    
    def _load_config(self) -> Dict[str, Any]:
        """加载配置文件"""
        try:
            with open(self.config_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except FileNotFoundError:
            logger.warning(f"配置文件 {self.config_path} 不存在，使用默认配置")
            return self._get_default_config()
    
    def _get_default_config(self) -> Dict[str, Any]:
        """获取默认配置"""
        return {
            "task_management": {
                "max_concurrent_tasks": 50,
                "task_timeout": 600,
                "retry_attempts": 3,
                "auto_decomposition": True,
                "task_prioritization": True
            },
            "agent_management": {
                "auto_discovery": True,
                "max_agents": 20,
                "agent_timeout": 300,
                "load_balancing": True,
                "capability_matching": True
            },
            "result_management": {
                "auto_aggregation": True,
                "result_validation": True,
                "file_sync_enabled": True,
                "result_retention": 30
            },
            "monitoring": {
                "real_time_monitoring": True,
                "update_interval": 10,
                "alert_threshold": 0.8,
                "performance_tracking": True
            }
        }
    
    def _initialize(self):
        """初始化系统"""
        logger.info("初始化任务协调系统...")
        
        # 加载Agent配置
        self._load_agent_profiles()
        
        # 加载任务模板
        self._load_task_templates()
        
        # 初始化文件同步系统
        self._initialize_file_sync()
        
        # 初始化结果聚合器
        self._initialize_result_aggregator()
        
        # 初始化Agent状态监控器
        self._initialize_agent_status_monitor()
        
        # 恢复未完成任务
        self._restore_pending_tasks()
        
        logger.info(f"系统初始化完成，已加载 {len(self.agents)} 个Agent")
    
    def _load_agent_profiles(self):
        """加载Agent配置文件"""
        try:
            with open('../templates/agent_profiles.json', 'r', encoding='utf-8') as f:
                agent_profiles = json.load(f)
                
            for agent_id, profile in agent_profiles.items():
                self.agents[agent_id] = Agent(
                    id=agent_id,
                    name=profile.get('name', agent_id),
                    capabilities=profile.get('capabilities', []),
                    max_concurrent_tasks=profile.get('max_concurrent_tasks', 3),
                    current_tasks=0,
                    specialties=profile.get('specialties', []),
                    status='available',
                    last_active=datetime.now().isoformat()
                )
                
        except FileNotFoundError:
            logger.warning("Agent配置文件不存在，创建默认Agent")
            self._create_default_agents()
    
    def _create_default_agents(self):
        """创建默认Agent"""
        default_agents = {
            "code_review_agent": {
                "name": "代码审查Agent",
                "capabilities": ["code_analysis", "security_check", "performance_analysis"],
                "max_concurrent_tasks": 3,
                "specialties": ["Python", "JavaScript", "TypeScript", "Go"]
            },
            "test_agent": {
                "name": "测试Agent",
                "capabilities": ["unit_testing", "integration_testing", "ui_testing"],
                "max_concurrent_tasks": 5,
                "specialties": ["pytest", "selenium", "cypress", "jest"]
            },
            "documentation_agent": {
                "name": "文档生成Agent",
                "capabilities": ["markdown_generation", "api_docs", "user_guides"],
                "max_concurrent_tasks": 4,
                "specialties": ["Markdown", "OpenAPI", "Sphinx"]
            }
        }
        
        for agent_id, profile in default_agents.items():
            self.agents[agent_id] = Agent(
                id=agent_id,
                name=profile["name"],
                capabilities=profile["capabilities"],
                max_concurrent_tasks=profile["max_concurrent_tasks"],
                current_tasks=0,
                specialties=profile["specialties"],
                status='available',
                last_active=datetime.now().isoformat()
            )
    
    def _load_task_templates(self):
        """加载任务模板"""
        try:
            with open('../templates/task_templates.json', 'r', encoding='utf-8') as f:
                self.task_templates = json.load(f)
        except FileNotFoundError:
            logger.warning("任务模板文件不存在")
            self.task_templates = {}
    
    def _restore_pending_tasks(self):
        """恢复未完成的任务"""
        # 这里可以添加从持久化存储恢复任务的逻辑
        pass
    
    def create_task(self, name: str, description: str, priority: str = "medium") -> str:
        """创建新任务"""
        task_id = f"task-{uuid.uuid4().hex[:8]}"
        
        task = Task(
            id=task_id,
            name=name,
            description=description,
            priority=priority,
            status="pending",
            created_at=datetime.now().isoformat(),
            estimated_time=self._estimate_task_time(description),
            required_capabilities=self._identify_required_capabilities(description),
            dependencies=[],
            subtasks=[]
        )
        
        self.tasks[task_id] = task
        
        logger.info(f"创建任务: {task_id} - {name}")
        return task_id
    
    def _estimate_task_time(self, description: str) -> int:
        """估算任务执行时间（秒）"""
        # 简单的时间估算逻辑
        word_count = len(description.split())
        base_time = 300  # 5分钟基础时间
        
        if word_count > 100:
            return base_time * 3
        elif word_count > 50:
            return base_time * 2
        else:
            return base_time
    
    def _identify_required_capabilities(self, description: str) -> List[str]:
        """识别任务所需的能力"""
        capabilities = []
        description_lower = description.lower()
        
        capability_keywords = {
            "code_review": ["代码审查", "code review", "代码检查", "代码分析"],
            "security_check": ["安全", "security", "漏洞", "风险"],
            "testing": ["测试", "test", "单元测试", "集成测试"],
            "documentation": ["文档", "documentation", "文档生成", "说明"],
            "performance_analysis": ["性能", "performance", "优化", "分析"]
        }
        
        for capability, keywords in capability_keywords.items():
            if any(keyword in description_lower for keyword in keywords):
                capabilities.append(capability)
        
        return capabilities if capabilities else ["general"]
    
    def decompose_task(self, task_id: str) -> bool:
        """拆解任务为子任务"""
        if task_id not in self.tasks:
            logger.error(f"任务 {task_id} 不存在")
            return False
        
        task = self.tasks[task_id]
        
        # 导入混合任务拆解器
        from hybrid_task_decomposer import HybridTaskDecomposer
        decomposer = HybridTaskDecomposer()
        
        subtasks = decomposer.decompose(task)
        task.subtasks = subtasks
        task.status = "decomposed"
        
        logger.info(f"任务 {task_id} 已拆解为 {len(subtasks)} 个子任务")
        return True
    
    def assign_tasks(self, task_id: str, auto_assign: bool = True) -> bool:
        """分配任务给Agent"""
        if task_id not in self.tasks:
            logger.error(f"任务 {task_id} 不存在")
            return False
        
        task = self.tasks[task_id]
        
        if not task.subtasks:
            logger.warning(f"任务 {task_id} 尚未拆解")
            return False
        
        # 导入Agent匹配器
        from agent_matcher import AgentMatcher
        matcher = AgentMatcher(self.agents)
        
        assignments = matcher.match_and_assign(task.subtasks, self.agents)
        
        if assignments:
            task.status = "assigned"
            self.active_assignments[task_id] = assignments
            
            # 更新Agent负载
            for assignment in assignments:
                agent_id = assignment["agent_id"]
                if agent_id in self.agents:
                    self.agents[agent_id].current_tasks += 1
            
            logger.info(f"任务 {task_id} 已分配给 {len(assignments)} 个Agent")
            return True
        else:
            logger.error(f"任务 {task_id} 分配失败")
            return False
    
    def execute_task(self, task_id: str) -> bool:
        """执行任务"""
        if task_id not in self.tasks:
            logger.error(f"任务 {task_id} 不存在")
            return False
        
        task = self.tasks[task_id]
        
        if task.status != "assigned":
            logger.error(f"任务 {task_id} 状态不正确，无法执行")
            return False
        
        task.status = "running"
        task.started_at = datetime.now().isoformat()
        
        # 这里应该调用实际的Agent执行逻辑
        # 目前只是模拟执行
        logger.info(f"开始执行任务 {task_id}")
        
        return True
    
    def get_task_status(self, task_id: str) -> Optional[Dict]:
        """获取任务状态"""
        if task_id not in self.tasks:
            return None
        
        task = self.tasks[task_id]
        return asdict(task)
    
    def get_system_status(self) -> Dict:
        """获取系统状态"""
        return {
            "total_tasks": len(self.tasks),
            "pending_tasks": len([t for t in self.tasks.values() if t.status == "pending"]),
            "running_tasks": len([t for t in self.tasks.values() if t.status == "running"]),
            "completed_tasks": len([t for t in self.tasks.values() if t.status == "completed"]),
            "total_agents": len(self.agents),
            "available_agents": len([a for a in self.agents.values() if a.status == "available"]),
            "active_assignments": len(self.active_assignments)
        }
    
    def list_tasks(self) -> List[Dict]:
        """列出所有任务"""
        return [asdict(task) for task in self.tasks.values()]
    
    def _initialize_agent_status_monitor(self):
        """初始化Agent状态监控器"""
        try:
            from agent_status_monitor import agent_monitor
            self.agent_status_monitor = agent_monitor
            
            # 注册所有Agent到监控系统
            for agent_id, agent in self.agents.items():
                self.agent_status_monitor.register_agent(
                    agent_id=agent_id,
                    name=agent.name,
                    capabilities=agent.capabilities,
                    max_concurrent_tasks=agent.max_concurrent_tasks,
                    specialties=agent.specialties
                )
            
            logger.info("Agent状态监控器初始化成功")
        except Exception as e:
            logger.error(f"Agent状态监控器初始化失败: {e}")
    
    def list_agents(self) -> List[Dict]:
        """列出所有Agent"""
        return [asdict(agent) for agent in self.agents.values()]
    
    def get_agent_status(self) -> Dict[str, Any]:
        """获取Agent状态"""
        try:
            if self.agent_status_monitor:
                return self.agent_status_monitor.get_agent_status_summary()
            else:
                # 降级处理
                return self.get_agent_status_summary()
        except Exception as e:
            logger.error(f"获取Agent状态失败: {e}")
            return {"error": str(e)}
    
    def get_agent_capacity_info(self) -> Dict[str, Any]:
        """获取Agent容量信息"""
        try:
            # 模拟当前运行的Agent数量
            running_agents = 1
            max_agents = 3
            
            # 判断容量状态
            if running_agents > max_agents:
                capacity_status = "🔴 超载"
                capacity_message = f"Agent超载！当前{running_agents}个，最多允许{max_agents}个并发Agent"
            elif running_agents == max_agents:
                capacity_status = "🟢 已满"
                capacity_message = "Agent容量已满，无法启动新Agent"
            elif running_agents == 1:
                capacity_status = "🟡 可扩展"
                capacity_message = "Agent运行中，还可启动7个"
            else:
                capacity_status = "🔴 空闲"
                capacity_message = "无Agent运行，可启动最多3个"
            
            capacity_info = {
                "Agent容量统计": {
                    "当前运行Agent": running_agents,
                    "最大并发Agent": max_agents,
                    "容量状态": capacity_status,
                    "状态说明": capacity_message,
                    "系统进程数": len(list(psutil.process_iter())),
                    "当前会话PID": os.getpid()
                },
                "Agent状态": self.get_agent_status(),
                "时间戳": datetime.now().isoformat()
            }
            
            return capacity_info
            
        except Exception as e:
            logger.error(f"获取Agent容量信息失败: {e}")
            return {"error": str(e)}
    
    def _count_local_iflow_sessions(self) -> int:
        """统计活跃iFlow会话数量（只算独立终端会话）"""
        try:
            terminal_sessions = set()
            
            # 查找所有包含"iflow"的活跃进程
            for proc in psutil.process_iter(['pid', 'name', 'cmdline', 'status', 'terminal']):
                try:
                    # 统计运行中和睡眠中的进程
                    if proc.info['status'] not in [psutil.STATUS_RUNNING, psutil.STATUS_SLEEPING]:
                        continue
                        
                    cmdline = proc.info.get('cmdline', [])
                    if not cmdline:
                        continue
                    
                    # 检查是否是iFlow相关进程
                    cmdline_str = ' '.join(cmdline).lower()
                    
                    # 排除系统命令、npm子进程等
                    if any(keyword in cmdline_str for keyword in ['grep', 'ps', 'awk', 'sed', 'npm exec']):
                        continue
                    
                    # 只匹配主要的iFlow进程
                    if ('iflow' in cmdline_str and 
                        'node' in cmdline_str and 
                        'bundle/iflow.js' not in cmdline_str):
                        
                        # 使用终端作为会话标识
                        terminal = proc.info.get('terminal')
                        if terminal:
                            terminal_sessions.add(terminal)
                        else:
                            # 如果没有终端信息，使用进程组ID
                            try:
                                pgid = os.getpgid(proc.info['pid'])
                                terminal_sessions.add(f"pgid_{pgid}")
                            except:
                                terminal_sessions.add(f"pid_{proc.info['pid']}")
                        
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
            
            return len(terminal_sessions)
        except Exception as e:
            logger.error(f"统计iFlow会话失败: {e}")
            return 1  # 默认返回1，表示当前会话
    
    def _check_agent_capacity(self):
        """检查Agent容量状态 - 每个主机最多2个并发Agent任务"""
        try:
            # 模拟检查当前运行的Agent任务
            running_agents = 1  # 当前运行的Agent数量
            max_agents = 8      # 每个主机最多8个并发Agent
            
            logger.info(f"当前运行Agent: {running_agents}/{max_agents}")
            
            if running_agents > max_agents:
                logger.warning(f"🔴 Agent超载！当前{running_agents}个，最多允许{max_agents}个并发Agent")
                return False
            elif running_agents == max_agents:
                logger.info("🟢 Agent容量已满")
                return True
            elif running_agents == 1:
                logger.info("🟡 Agent运行中，还可启动1个")
                return True
            else:
                logger.info("🔴 无Agent运行")
                return False
                
        except Exception as e:
            logger.error(f"检查Agent容量失败: {e}")
            return False
    
    def get_agent_status_summary(self) -> Dict[str, Any]:
        """获取Agent状态摘要"""
        if self.agent_status_monitor:
            return self.agent_status_monitor.get_agent_status_summary()
        else:
            # 降级处理
            return {
                "总数量": len(self.agents),
                "空闲中": len([a for a in self.agents.values() if a.status == "available"]),
                "忙碌中": len([a for a in self.agents.values() if a.status == "busy"]),
                "失联中": 0,
                "错误中": 0,
                "维护中": 0,
                "详细列表": []
            }
    
    def _initialize_file_sync(self):
        """初始化文件同步系统"""
        try:
            from file_sync_system import FileSyncSystem
            self.file_sync_system = FileSyncSystem()
            logger.info("文件同步系统初始化成功")
        except Exception as e:
            logger.error(f"文件同步系统初始化失败: {e}")
    
    def _initialize_result_aggregator(self):
        """初始化结果聚合器"""
        try:
            from result_aggregator import ResultAggregator
            self.result_aggregator = ResultAggregator()
            logger.info("结果聚合器初始化成功")
        except Exception as e:
            logger.error(f"结果聚合器初始化失败: {e}")
    
    def _initialize_agent_status_monitor(self):
        """初始化Agent状态监控器"""
        try:
            from agent_status_monitor import agent_monitor, initialize_task_coordinator_agents
            self.agent_status_monitor = agent_monitor
            
            # 注册任务协调器的所有Agent到监控系统
            initialize_task_coordinator_agents(self)
            
            # 检查主机会话限制
            self._check_agent_capacity()
            
            logger.info("Agent状态监控器初始化成功")
        except Exception as e:
            logger.error(f"Agent状态监控器初始化失败: {e}")
    
    def _check_session_limit(self):
        """检查主机会话限制"""
        try:
            import socket
            import psutil
            import os
            
            # 获取主机标识
            hostname = socket.gethostname()
            local_ip = socket.gethostbyname(hostname)
            host_id = f"{hostname}_{local_ip}"
            
            # 检查当前主机的iFlow会话数量
            current_sessions = self._count_local_iflow_sessions()
            
            # 最大允许会话数
            max_sessions = 2
            
            logger.info(f"主机 {host_id} 当前iFlow会话数: {current_sessions}/{max_sessions}")
            
            if current_sessions > max_sessions:
                logger.warning(f"主机会话数超限！当前: {current_sessions}, 最大: {max_sessions}")
                # 可以在这里实现会话限制逻辑
                # 例如：拒绝新任务、降低优先级、或提示用户
                
        except Exception as e:
            logger.error(f"检查会话限制失败: {e}")
    
    def _count_local_iflow_sessions(self) -> int:
        """统计本地iFlow会话数量"""
        try:
            import psutil
            
            session_count = 0
            current_pid = os.getpid()
            
            # 查找所有包含"iflow"的进程
            for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
                try:
                    cmdline = proc.info.get('cmdline', [])
                    if cmdline and any('iflow' in str(cmd).lower() for cmd in cmdline):
                        session_count += 1
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
            
            return session_count
            
        except Exception as e:
            logger.error(f"统计iFlow会话失败: {e}")
            return 1  # 默认返回1，表示当前会话
    
    def coordinate_collaborative_task(self, task_id: str) -> bool:
        """协调协同任务执行"""
        if task_id not in self.tasks:
            logger.error(f"任务 {task_id} 不存在")
            return False
        
        task = self.tasks[task_id]
        
        # 1. 拆解任务
        if not self.decompose_task(task_id):
            return False
        
        # 2. 分配任务
        if not self.assign_tasks(task_id):
            return False
        
        # 3. 创建共享工作空间
        if self.file_sync_system:
            participating_agents = [assignment["agent_id"] for assignment in self.active_assignments.get(task_id, [])]
            workspace_path = self.file_sync_system.create_shared_workspace(task_id, participating_agents)
            if workspace_path:
                logger.info(f"创建共享工作空间: {workspace_path}")
        
        # 4. 开始执行
        return self.execute_task(task_id)
    
    def collect_and_aggregate_results(self, task_id: str, agent_outputs: List[Dict]) -> Dict[str, Any]:
        """收集并聚合Agent执行结果"""
        if not self.result_aggregator:
            logger.error("结果聚合器未初始化")
            return {}
        
        if task_id not in self.active_assignments:
            logger.error(f"任务 {task_id} 没有活跃的分配")
            return {}
        
        assignments = self.active_assignments[task_id]
        # 直接聚合agent_outputs，不使用ResultAggregator的collect_results_from_task方法
        aggregated_results = self._aggregate_agent_outputs(task_id, assignments, agent_outputs)
        
        # 更新任务状态
        if task_id in self.tasks:
            task = self.tasks[task_id]
            task.result = aggregated_results
            task.completed_at = datetime.now().isoformat()
            
            # 根据聚合结果更新任务状态
            summary = aggregated_results.get("summary", {})
            if summary.get("failed_tasks", 0) == 0:
                task.status = "completed"
            elif summary.get("completed_tasks", 0) > 0:
                task.status = "partially_completed"
            else:
                task.status = "failed"
        
        return aggregated_results
    
    def _aggregate_agent_outputs(self, task_id: str, assignments: List[Dict], agent_outputs: List[Dict]) -> Dict[str, Any]:
        """聚合Agent输出结果"""
        try:
            total_tasks = len(assignments)
            completed_tasks = len([output for output in agent_outputs if output.get("success", False)])
            failed_tasks = total_tasks - completed_tasks
            
            # 创建摘要
            summary = {
                "total_tasks": total_tasks,
                "completed_tasks": completed_tasks,
                "failed_tasks": failed_tasks,
                "success_rate": completed_tasks / total_tasks if total_tasks > 0 else 0,
                "task_id": task_id,
                "completion_time": datetime.now().isoformat()
            }
            
            # 检查冲突
            conflicts = []
            # 这里可以添加冲突检测逻辑
            
            # 聚合结果
            aggregated_results = {
                "task_id": task_id,
                "summary": summary,
                "individual_results": agent_outputs,
                "conflicts": conflicts,
                "aggregated_at": datetime.now().isoformat()
            }
            
            logger.info(f"结果聚合完成: {completed_tasks}/{total_tasks} 任务成功")
            return aggregated_results
            
        except Exception as e:
            logger.error(f"聚合Agent输出失败: {e}")
            return {
                "task_id": task_id,
                "summary": {
                    "total_tasks": len(assignments) if assignments else 0,
                    "completed_tasks": 0,
                    "failed_tasks": len(assignments) if assignments else 0,
                    "success_rate": 0,
                    "error": str(e)
                },
                "individual_results": agent_outputs,
                "conflicts": [],
                "aggregated_at": datetime.now().isoformat()
            }
    
    def sync_files_for_task(self, task_id: str, file_paths: List[str], source_agent: str) -> bool:
        """为任务同步文件"""
        if not self.file_sync_system:
            logger.warning("文件同步系统未初始化")
            return False
        
        if task_id not in self.active_assignments:
            logger.error(f"任务 {task_id} 没有活跃的分配")
            return False
        
        # 获取目标Agent列表
        target_agents = []
        for assignment in self.active_assignments[task_id]:
            agent_id = assignment["agent_id"]
            if agent_id != source_agent:
                target_agents.append(agent_id)
        
        # 同步每个文件
        success_count = 0
        for file_path in file_paths:
            # 注册文件
            if self.file_sync_system.register_file(file_path, source_agent):
                # 同步到其他Agent
                if self.file_sync_system.sync_file_to_agents(file_path, source_agent, target_agents):
                    success_count += 1
        
        logger.info(f"文件同步完成: {success_count}/{len(file_paths)} 个文件成功同步")
        return success_count == len(file_paths)
    
    def get_collaboration_status(self, task_id: str) -> Dict[str, Any]:
        """获取协同任务状态"""
        status = {
            "task_id": task_id,
            "task_status": "unknown",
            "assignments": [],
            "file_sync_status": {},
            "result_aggregation_status": {}
        }
        
        # 任务基本信息
        if task_id in self.tasks:
            task = self.tasks[task_id]
            status["task_status"] = task.status
            status["task_name"] = task.name
        
        # 分配信息
        if task_id in self.active_assignments:
            status["assignments"] = self.active_assignments[task_id]
        
        # 文件同步状态
        if self.file_sync_system:
            status["file_sync_status"] = self.file_sync_system.get_sync_status()
        
        # 结果聚合状态
        if task_id in self.tasks and self.tasks[task_id].result:
            status["result_aggregation_status"] = {
                "has_results": True,
                "summary": self.tasks[task_id].result.get("summary", {}),
                "conflicts": len(self.tasks[task_id].result.get("conflicts", []))
            }
        else:
            status["result_aggregation_status"] = {"has_results": False}
        
        return status
    
    def generate_task_report(self, task_id: str) -> str:
        """生成任务执行报告"""
        if task_id not in self.tasks:
            return f"任务 {task_id} 不存在"
        
        task = self.tasks[task_id]
        
        report = f"""
=== 任务执行报告 ===

任务ID: {task.id}
任务名称: {task.name}
任务状态: {task.status}
创建时间: {task.created_at}
开始时间: {task.started_at or '未开始'}
完成时间: {task.completed_at or '未完成'}

任务描述: {task.description}
优先级: {task.priority}
预估时间: {task.estimated_time}秒
所需能力: {', '.join(task.required_capabilities)}

=== 子任务信息 ===
子任务数量: {len(task.subtasks)}
"""
        
        if task.subtasks:
            for i, subtask in enumerate(task.subtasks, 1):
                report += f"""
{i}. {subtask.get('name', 'Unknown')}
   描述: {subtask.get('description', 'No description')}
   预估时间: {subtask.get('estimated_time', 0)}秒
   优先级: {subtask.get('priority', 0)}
   所需能力: {', '.join(subtask.get('required_capabilities', []))}
"""
        
        # 分配信息
        if task_id in self.active_assignments:
            report += "\n=== Agent分配信息 ===\n"
            for assignment in self.active_assignments[task_id]:
                report += f"""
- Agent: {assignment.get('agent_name', assignment.get('agent_id', 'Unknown'))}
  任务: {assignment.get('task_name', 'Unknown')}
  分配时间: {assignment.get('assigned_at', 'Unknown')}
  置信度: {assignment.get('confidence_score', 0):.2f}
"""
        
        # 结果聚合报告
        if task.result and self.result_aggregator:
            report += "\n" + self.result_aggregator.generate_final_report(task.result)
        
        return report
    
    def cleanup_completed_tasks(self, days: int = 7) -> int:
        """清理已完成的任务"""
        cutoff_time = datetime.now().timestamp() - (days * 24 * 3600)
        removed_count = 0
        
        tasks_to_remove = []
        for task_id, task in self.tasks.items():
            if (task.status in ["completed", "failed"] and 
                task.completed_at and 
                datetime.fromisoformat(task.completed_at).timestamp() < cutoff_time):
                tasks_to_remove.append(task_id)
        
        for task_id in tasks_to_remove:
            del self.tasks[task_id]
            if task_id in self.active_assignments:
                del self.active_assignments[task_id]
            removed_count += 1
        
        # 清理文件同步系统中的旧文件
        if self.file_sync_system:
            removed_count += self.file_sync_system.cleanup_old_files(days)
        
        logger.info(f"清理完成，删除了 {removed_count} 个过期任务/文件")
        return removed_count

def main():
    """命令行入口"""
    parser = argparse.ArgumentParser(description="任务协调器")
    parser.add_argument("command", choices=[
        "init", "create-task", "execute-task", "status", "list-tasks", "list-agents", 
        "agent-status", "agent-capacity"
    ])
    parser.add_argument("--name", help="任务名称")
    parser.add_argument("--description", help="任务描述")
    parser.add_argument("--priority", choices=["low", "medium", "high"], default="medium")
    parser.add_argument("--task-id", help="任务ID")
    parser.add_argument("--auto-assign", action="store_true", help="自动分配")
    
    args = parser.parse_args()
    
    coordinator = TaskCoordinator()
    
    if args.command == "init":
        logger.info("任务协调系统初始化完成")
    
    elif args.command == "create-task":
        if not args.name or not args.description:
            logger.error("创建任务需要提供 --name 和 --description 参数")
            return
        
        task_id = coordinator.create_task(args.name, args.description, args.priority)
        
        if args.auto_assign:
            coordinator.decompose_task(task_id)
            coordinator.assign_tasks(task_id, auto_assign=True)
        
        logger.info(f"任务创建成功: {task_id}")
    
    elif args.command == "execute-task":
        if not args.task_id:
            logger.error("执行任务需要提供 --task-id 参数")
            return
        
        success = coordinator.execute_task(args.task_id)
        if success:
            logger.info(f"任务 {args.task_id} 开始执行")
        else:
            logger.error(f"任务 {args.task_id} 执行失败")
    
    elif args.command == "status":
        if args.task_id:
            status = coordinator.get_task_status(args.task_id)
            if status:
                print(json.dumps(status, ensure_ascii=False, indent=2))
            else:
                logger.error(f"任务 {args.task_id} 不存在")
        else:
            status = coordinator.get_system_status()
            print(json.dumps(status, ensure_ascii=False, indent=2))
    
    elif args.command == "list-tasks":
        tasks = coordinator.list_tasks()
        print(json.dumps(tasks, ensure_ascii=False, indent=2))
    
    elif args.command == "list-agents":
        agents = coordinator.list_agents()
        print(json.dumps(agents, ensure_ascii=False, indent=2))
    
    elif args.command == "agent-status":
        status = coordinator.get_agent_status()
        print(json.dumps(status, ensure_ascii=False, indent=2))
    
    elif args.command == "agent-capacity":
            capacity = coordinator.get_agent_capacity_info()
            print(json.dumps(capacity, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()