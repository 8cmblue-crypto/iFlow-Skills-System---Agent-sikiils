#!/usr/bin/env python3
"""
任务结果聚合器
负责收集、聚合和整理多个Agent的任务执行结果
"""

import json
import os
from datetime import datetime
from typing import Dict, List, Any, Optional
from pathlib import Path
import logging

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class ResultAggregator:
    """任务结果聚合器"""
    
    def __init__(self, workspace_path: str = "/vol1/1000/iflow/sync_workspace"):
        self.workspace_path = Path(workspace_path)
        self.results_path = self.workspace_path / "aggregated_results"
        self.results_path.mkdir(parents=True, exist_ok=True)
        
    def collect_results_from_task(self, task_id: str) -> Dict[str, Any]:
        """从指定任务ID收集所有Agent的结果"""
        try:
            task_workspace = self.workspace_path / f"task_{task_id}"
            
            if not task_workspace.exists():
                return {
                    "status": "error",
                    "error": f"任务工作空间不存在: {task_id}"
                }
            
            # 收集所有Agent的结果
            agent_results = {}
            
            for agent_dir in task_workspace.iterdir():
                if agent_dir.is_dir():
                    agent_name = agent_dir.name
                    agent_results[agent_name] = self._collect_agent_results(agent_dir)
            
            # 聚合结果
            aggregated_result = {
                "task_id": task_id,
                "collection_time": datetime.now().isoformat(),
                "agents": agent_results,
                "total_agents": len(agent_results),
                "completed_agents": len([r for r in agent_results.values() if r.get("status") == "completed"]),
                "summary": self._generate_task_summary(agent_results)
            }
            
            # 保存聚合结果
            result_file = self.results_path / f"task_{task_id}_aggregated.json"
            with open(result_file, 'w', encoding='utf-8') as f:
                json.dump(aggregated_result, f, ensure_ascii=False, indent=2)
            
            logger.info(f"✅ 任务 {task_id} 结果聚合完成")
            
            return {
                "status": "success",
                "task_id": task_id,
                "result_file": str(result_file),
                "summary": aggregated_result["summary"]
            }
            
        except Exception as e:
            logger.error(f"❌ 聚合任务结果失败: {e}")
            return {
                "status": "error",
                "error": str(e),
                "task_id": task_id
            }
    
    def _collect_agent_results(self, agent_dir: Path) -> Dict[str, Any]:
        """收集单个Agent的结果"""
        try:
            agent_name = agent_dir.name
            results = {
                "agent_name": agent_name,
                "status": "pending",
                "files": [],
                "content": {},
                "metadata": {}
            }
            
            # 查找所有结果文件
            for file_path in agent_dir.iterdir():
                if file_path.is_file():
                    file_info = {
                        "name": file_path.name,
                        "path": str(file_path),
                        "size": file_path.stat().st_size,
                        "modified": datetime.fromtimestamp(file_path.stat().st_mtime).isoformat()
                    }
                    
                    # 读取文件内容（如果文件不太大）
                    if file_path.stat().st_size < 1024 * 1024:  # 小于1MB
                        try:
                            if file_path.suffix.lower() in ['.md', '.txt', '.json']:
                                with open(file_path, 'r', encoding='utf-8') as f:
                                    content = f.read()
                                file_info["content_preview"] = content[:500]  # 前500字符预览
                                results["content"][file_path.name] = content
                        except Exception as e:
                            file_info["read_error"] = str(e)
                    
                    results["files"].append(file_info)
            
            # 判断Agent状态
            if results["files"]:
                # 检查是否有分析报告
                analysis_files = [f for f in results["files"] if any(keyword in f["name"].lower() 
                                for keyword in ['分析', '报告', 'analysis', 'report'])]
                
                if analysis_files:
                    results["status"] = "completed"
                else:
                    results["status"] = "partial"
            else:
                results["status"] = "no_results"
            
            return results
            
        except Exception as e:
            return {
                "agent_name": agent_dir.name,
                "status": "error",
                "error": str(e),
                "files": [],
                "content": {}
            }
    
    def _generate_task_summary(self, agent_results: Dict[str, Any]) -> Dict[str, Any]:
        """生成任务摘要"""
        summary = {
            "total_agents": len(agent_results),
            "completed_agents": 0,
            "partial_agents": 0,
            "failed_agents": 0,
            "no_result_agents": 0,
            "total_files": 0,
            "file_types": {},
            "key_findings": []
        }
        
        for agent_name, result in agent_results.items():
            status = result.get("status", "unknown")
            
            if status == "completed":
                summary["completed_agents"] += 1
            elif status == "partial":
                summary["partial_agents"] += 1
            elif status == "error":
                summary["failed_agents"] += 1
            elif status == "no_results":
                summary["no_result_agents"] += 1
            
            # 统计文件
            files = result.get("files", [])
            summary["total_files"] += len(files)
            
            for file_info in files:
                file_ext = Path(file_info["name"]).suffix.lower()
                summary["file_types"][file_ext] = summary["file_types"].get(file_ext, 0) + 1
        
        return summary
    
    def create_comprehensive_report(self, task_id: str) -> Dict[str, Any]:
        """创建综合报告"""
        try:
            # 收集聚合结果
            aggregated_result = self.collect_results_from_task(task_id)
            
            if aggregated_result["status"] != "success":
                return aggregated_result
            
            # 创建综合报告
            report = {
                "report_id": f"comprehensive_report_{task_id}",
                "task_id": task_id,
                "generated_at": datetime.now().isoformat(),
                "executive_summary": self._create_executive_summary(aggregated_result),
                "agent_details": aggregated_result.get("agents", {}),
                "key_insights": self._extract_key_insights(aggregated_result),
                "recommendations": self._generate_recommendations(aggregated_result),
                "appendix": {
                    "raw_data": aggregated_result,
                    "methodology": "多Agent协作分析框架"
                }
            }
            
            # 保存综合报告
            report_file = self.results_path / f"comprehensive_report_{task_id}.json"
            with open(report_file, 'w', encoding='utf-8') as f:
                json.dump(report, f, ensure_ascii=False, indent=2)
            
            # 同时生成Markdown版本的可读报告
            self._generate_markdown_report(report, task_id)
            
            logger.info(f"✅ 综合报告生成完成: {report_file}")
            
            return {
                "status": "success",
                "task_id": task_id,
                "report_file": str(report_file),
                "executive_summary": report["executive_summary"]
            }
            
        except Exception as e:
            logger.error(f"❌ 创建综合报告失败: {e}")
            return {
                "status": "error",
                "error": str(e),
                "task_id": task_id
            }
    
    def _create_executive_summary(self, aggregated_result: Dict[str, Any]) -> Dict[str, Any]:
        """创建执行摘要"""
        summary = aggregated_result["summary"]
        
        return {
            "overview": {
                "task_id": aggregated_result["task_id"],
                "total_agents": summary["total_agents"],
                "completion_rate": f"{(summary['completed_agents'] / summary['total_agents'] * 100):.1f}%" if summary["total_agents"] > 0 else "0.0%",
                "total_files_generated": summary["total_files"]
            },
            "key_metrics": {
                "successful_agents": summary["completed_agents"],
                "agents_with_partial_results": summary["partial_agents"],
                "agents_with_no_results": summary["no_result_agents"]
            },
            "file_analysis": {
                "most_common_file_types": sorted(summary["file_types"].items(), 
                                              key=lambda x: x[1], reverse=True)[:3],
                "total_content_volume": summary["total_files"]
            }
        }
    
    def _extract_key_insights(self, aggregated_result: Dict[str, Any]) -> List[str]:
        """提取关键洞察"""
        insights = []
        
        agents = aggregated_result.get("agents", {})
        
        for agent_name, result in agents.items():
            if result.get("status") == "completed":
                insights.append(f"✅ {agent_name}: 成功完成分析任务")
                
                # 从内容中提取关键信息
                for file_name, content in result.get("content", {}).items():
                    if "分析" in file_name or "报告" in file_name:
                        # 简单的内容分析
                        if len(content) > 100:
                            insights.append(f"📊 {agent_name}: 提交了详细的分析报告")
                        else:
                            insights.append(f"📝 {agent_name}: 提交了简要分析")
            
            elif result.get("status") == "partial":
                insights.append(f"⚠️ {agent_name}: 部分完成，有文件但可能不完整")
            
            elif result.get("status") == "no_results":
                insights.append(f"❌ {agent_name}: 未提交结果文件")
            
            elif result.get("status") == "error":
                insights.append(f"🚫 {agent_name}: 执行过程中出现错误")
        
        return insights
    
    def _generate_recommendations(self, aggregated_result: Dict[str, Any]) -> List[str]:
        """生成建议"""
        recommendations = []
        summary = aggregated_result.get("summary", {})
        
        if summary["completed_agents"] == summary["total_agents"]:
            recommendations.append("🎯 所有Agent都成功完成任务，可以考虑进入下一阶段")
        elif summary["completed_agents"] >= summary["total_agents"] * 0.7:
            recommendations.append("✅ 大部分Agent完成任务，可以开始结果整合")
        else:
            recommendations.append("⚠️ 完成率较低，建议检查任务分配和Agent配置")
        
        if summary["no_result_agents"] > 0:
            recommendations.append(f"📋 {summary['no_result_agents']}个Agent未提交结果，需要跟进")
        
        if summary["failed_agents"] > 0:
            recommendations.append(f"🔧 {summary['failed_agents']}个Agent执行失败，需要排查问题")
        
        return recommendations
    
    def generate_final_report(self, task_result: Dict[str, Any]) -> str:
        """生成最终报告"""
        try:
            task_id = task_result.get("task_id", "unknown")
            
            # 创建综合报告
            comprehensive_report = self.create_comprehensive_report(task_id)
            
            if comprehensive_report["status"] != "success":
                return f"❌ 报告生成失败: {comprehensive_report.get('error', '未知错误')}"
            
            # 安全获取报告数据
            report_data = comprehensive_report
            generated_at = report_data.get('generated_at', datetime.now().isoformat())
            
            # 获取执行摘要数据，提供默认值
            exec_summary = report_data.get('executive_summary', {})
            overview = exec_summary.get('overview', {})
            
            total_agents = overview.get('total_agents', 0)
            completion_rate = overview.get('completion_rate', '0.0%')
            total_files = overview.get('total_files_generated', 0)
            
            # 获取关键洞察和建议，提供默认值
            key_insights = report_data.get('key_insights', [])
            recommendations = report_data.get('recommendations', [])
            
            # 生成可读的报告文本
            report_text = f"""
📊 任务执行最终报告
=====================

任务ID: {task_id}
生成时间: {generated_at}

执行摘要:
- 参与Agent数: {total_agents}
- 完成率: {completion_rate}
- 生成文件数: {total_files}

关键洞察:
"""
            
            if key_insights:
                for insight in key_insights:
                    report_text += f"- {insight}\n"
            else:
                report_text += "- 暂无关键洞察\n"
            
            report_text += "\n建议:\n"
            if recommendations:
                for recommendation in recommendations:
                    report_text += f"- {recommendation}\n"
            else:
                report_text += "- 暂无具体建议\n"
            
            report_text += f"\n详细报告文件: {comprehensive_report.get('report_file', '未生成')}"
            
            return report_text
            
        except Exception as e:
            logger.error(f"❌ 生成最终报告失败: {e}")
            return f"❌ 最终报告生成失败: {str(e)}"

    def _generate_markdown_report(self, report: Dict[str, Any], task_id: str):
        """生成Markdown格式的可读报告"""
        try:
            md_file = self.results_path / f"comprehensive_report_{task_id}.md"
            
            with open(md_file, 'w', encoding='utf-8') as f:
                f.write(f"# 任务综合报告 - {task_id}\n\n")
                f.write(f"**生成时间**: {report['generated_at']}\n\n")
                
                # 执行摘要
                f.write("## 执行摘要\n\n")
                exec_summary = report["executive_summary"]
                f.write(f"- **任务ID**: {exec_summary['overview']['task_id']}\n")
                f.write(f"- **参与Agent数**: {exec_summary['overview']['total_agents']}\n")
                f.write(f"- **完成率**: {exec_summary['overview']['completion_rate']}\n")
                f.write(f"- **生成文件数**: {exec_summary['overview']['total_files_generated']}\n\n")
                
                # 关键洞察
                f.write("## 关键洞察\n\n")
                for insight in report["key_insights"]:
                    f.write(f"- {insight}\n")
                f.write("\n")
                
                # 建议
                f.write("## 建议\n\n")
                for recommendation in report["recommendations"]:
                    f.write(f"- {recommendation}\n")
                f.write("\n")
                
                # Agent详情
                f.write("## Agent执行详情\n\n")
                for agent_name, details in report["agent_details"].items():
                    f.write(f"### {agent_name}\n\n")
                    f.write(f"- **状态**: {details['status']}\n")
                    f.write(f"- **文件数**: {len(details['files'])}\n")
                    
                    if details["files"]:
                        f.write("- **生成文件**:\n")
                        for file_info in details["files"]:
                            f.write(f"  - {file_info['name']} ({file_info['size']} bytes)\n")
                    f.write("\n")
            
            logger.info(f"✅ Markdown报告生成完成: {md_file}")
            
        except Exception as e:
            logger.error(f"❌ 生成Markdown报告失败: {e}")

def main():
    """主函数 - 测试结果聚合器"""
    aggregator = ResultAggregator()
    
    print("🚀 任务结果聚合器测试")
    print("=" * 40)
    
    # 查找可用的任务
    workspace = Path("/vol1/1000/iflow/sync_workspace")
    task_dirs = [d for d in workspace.iterdir() if d.is_dir() and d.name.startswith("task_")]
    
    if not task_dirs:
        print("❌ 未找到任务目录")
        return
    
    # 使用最新的任务进行测试
    latest_task = max(task_dirs, key=lambda x: x.stat().st_mtime)
    task_id = latest_task.name.replace("task_", "")
    
    print(f"📝 使用任务进行测试: {task_id}")
    
    # 测试结果收集
    print("\n📊 测试结果收集...")
    collection_result = aggregator.collect_results_from_task(task_id)
    print(f"收集结果: {collection_result['status']}")
    
    if collection_result["status"] == "success":
        print(f"✅ 收集到 {collection_result['summary']['total_agents']} 个Agent的结果")
    
    # 测试综合报告
    print("\n📋 测试综合报告生成...")
    report_result = aggregator.create_comprehensive_report(task_id)
    print(f"报告生成结果: {report_result['status']}")
    
    if report_result["status"] == "success":
        print("✅ 综合报告生成成功")

if __name__ == "__main__":
    main()