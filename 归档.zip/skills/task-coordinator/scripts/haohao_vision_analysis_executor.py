#!/usr/bin/env python3
"""
好好视力竞争对手调研 - 多Agent协作执行脚本
老大，这是专门为好好视力竞争对手调研设计的多Agent协作执行程序
"""

import json
import os
import sys
import time
import logging
from datetime import datetime
from pathlib import Path

# 添加技能路径
sys.path.append('/vol1/1000/iflow/skills/task-coordinator/scripts')

from task_coordinator import TaskCoordinator

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('/vol1/1000/iflow/skills/task-coordinator/logs/haohao_vision_analysis.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class HaoHaoVisionCompetitorAnalysis:
    """好好视力竞争对手调研协调器"""
    
    def __init__(self):
        self.coordinator = TaskCoordinator()
        self.task_id = None
        self.agents_config = {}
        self.analysis_results = {}
        
    def load_task_config(self):
        """加载任务配置"""
        try:
            config_path = '/vol1/1000/iflow/skills/task-coordinator/tasks/haohao_vision_competitor_analysis.json'
            with open(config_path, 'r', encoding='utf-8') as f:
                self.task_config = json.load(f)
            logger.info("好好视力调研任务配置加载成功")
            return True
        except Exception as e:
            logger.error(f"加载任务配置失败: {e}")
            return False
    
    def create_analysis_task(self):
        """创建主分析任务"""
        try:
            task_name = self.task_config['task_name']
            task_description = self.task_config['task_description']
            priority = self.task_config['task_priority']
            
            # 创建主任务
            self.task_id = self.coordinator.create_task(
                name=task_name,
                description=task_description,
                priority=priority
            )
            
            logger.info(f"好好视力调研主任务创建成功: {self.task_id}")
            return True
            
        except Exception as e:
            logger.error(f"创建主任务失败: {e}")
            return False
    
    def setup_agent_profiles(self):
        """设置Agent配置文件"""
        try:
            # 为好好视力调研专门配置的Agent
            special_agents = {
                "xiaozhang_agent": {
                    "name": "小张-市场领导地位分析专家",
                    "capabilities": ["market_analysis", "leadership_research", "financial_analysis", "strategy_formulation"],
                    "specialization": "连锁经营模式、品牌矩阵策略、上市公司分析",
                    "status": "available",
                    "workload": 0,
                    "performance_score": 95
                },
                "xiaoli_agent": {
                    "name": "小李-产品创新与营销专家",
                    "capabilities": ["product_analysis", "marketing_research", "innovation_study", "brand_analysis"],
                    "specialization": "眼保健产品、体育营销、品牌建设",
                    "status": "available", 
                    "workload": 0,
                    "performance_score": 92
                },
                "xiaowang_agent": {
                    "name": "小王-供应链与技术专家",
                    "capabilities": ["supply_chain_analysis", "technology_research", "manufacturing_analysis", "patent_analysis"],
                    "specialization": "镜片制造、智能验光、供应链管理",
                    "status": "available",
                    "workload": 0,
                    "performance_score": 88
                },
                "xiaoliu_agent": {
                    "name": "小刘-区域竞争专家",
                    "capabilities": ["regional_analysis", "service_quality_research", "local_competition_study", "customer_relationship_analysis"],
                    "specialization": "区域品牌、本地化服务、客户关系管理",
                    "status": "available",
                    "workload": 0,
                    "performance_score": 90
                }
            }
            
            # 注册Agent到协调器
            for agent_id, agent_config in special_agents.items():
                self.coordinator.register_agent(agent_id, agent_config)
                self.agents_config[agent_id] = agent_config
            
            logger.info("Agent配置文件设置完成，共4个专业Agent")
            return True
            
        except Exception as e:
            logger.error(f"设置Agent配置失败: {e}")
            return False
    
    def assign_tasks_to_agents(self):
        """为Agent分配具体任务"""
        try:
            agents = self.task_config['agents']
            
            for agent_config in agents:
                agent_name = agent_config['agent_name']
                assigned_competitors = agent_config['assigned_competitors']
                focus_area = agent_config['focus_area']
                analysis_dimensions = agent_config['analysis_dimensions']
                special_instructions = agent_config['special_instructions']
                
                # 根据Agent名称找到对应的Agent ID
                agent_id = self.get_agent_id_by_name(agent_name)
                if not agent_id:
                    logger.error(f"未找到Agent: {agent_name}")
                    continue
                
                # 创建子任务
                subtask_id = self.coordinator.create_task(
                    name=f"{agent_name}-{focus_area}",
                    description=f"分析{', '.join(assigned_competitors)}的{focus_area}",
                    priority="high",
                    parent_task_id=self.task_id,
                    estimated_time=self.task_config['estimated_time'] // len(agents)
                )
                
                # 分配任务给Agent
                success = self.coordinator.assign_task(subtask_id, agent_id)
                if success:
                    logger.info(f"成功将任务分配给{agent_name} (ID: {agent_id})")
                    
                    # 保存Agent任务配置
                    self.save_agent_task_config(agent_id, agent_config, subtask_id)
                else:
                    logger.error(f"任务分配失败: {agent_name}")
            
            return True
            
        except Exception as e:
            logger.error(f"分配任务给Agent失败: {e}")
            return False
    
    def get_agent_id_by_name(self, agent_name):
        """根据Agent名称获取Agent ID"""
        name_to_id = {
            "小张": "xiaozhang_agent",
            "小李": "xiaoli_agent", 
            "小王": "xiaowang_agent",
            "小刘": "xiaoliu_agent"
        }
        return name_to_id.get(agent_name)
    
    def save_agent_task_config(self, agent_id, agent_config, subtask_id):
        """保存Agent任务配置"""
        try:
            # 创建Agent工作目录
            agent_dir = f"/vol1/1000/iflow/sync_workspace/task_{self.task_id}/{agent_id}"
            os.makedirs(agent_dir, exist_ok=True)
            
            # 保存任务配置
            task_assignment = {
                "agent_name": agent_config['agent_name'],
                "agent_type": agent_config['agent_type'],
                "assigned_competitors": agent_config['assigned_competitors'],
                "focus_area": agent_config['focus_area'],
                "analysis_dimensions": agent_config['analysis_dimensions'],
                "special_instructions": agent_config['special_instructions'],
                "subtask_id": subtask_id,
                "main_task_id": self.task_id,
                "assigned_at": datetime.now().isoformat(),
                "deadline": datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }
            
            config_file = f"{agent_dir}/task_assignment.json"
            with open(config_file, 'w', encoding='utf-8') as f:
                json.dump(task_assignment, f, ensure_ascii=False, indent=2)
            
            # 复制Agent指令文件
            instructions_file = "/vol1/1000/iflow/skills/task-coordinator/tasks/haohao_vision_agent_instructions.md"
            if os.path.exists(instructions_file):
                import shutil
                shutil.copy2(instructions_file, f"{agent_dir}/agent_instructions.md")
            
            logger.info(f"Agent任务配置已保存: {agent_id}")
            
        except Exception as e:
            logger.error(f"保存Agent任务配置失败: {e}")
    
    def execute_analysis(self):
        """执行分析任务"""
        try:
            logger.info("开始执行好好视力竞争对手调研...")
            
            # 启动所有Agent任务
            agent_tasks = self.coordinator.get_agent_tasks(self.task_id)
            
            for task_id, agent_id in agent_tasks.items():
                logger.info(f"启动Agent任务: {task_id} -> {agent_id}")
                success = self.coordinator.execute_task(task_id)
                if success:
                    logger.info(f"Agent任务启动成功: {agent_id}")
                else:
                    logger.error(f"Agent任务启动失败: {agent_id}")
            
            # 监控任务执行进度
            self.monitor_task_progress()
            
            return True
            
        except Exception as e:
            logger.error(f"执行分析任务失败: {e}")
            return False
    
    def monitor_task_progress(self):
        """监控任务执行进度"""
        try:
            logger.info("开始监控任务执行进度...")
            
            start_time = time.time()
            timeout = self.task_config['estimated_time'] + 600  # 增加10分钟缓冲
            
            while time.time() - start_time < timeout:
                # 检查任务状态
                all_completed = True
                for agent_id in self.agents_config.keys():
                    agent_tasks = self.coordinator.get_agent_tasks_by_agent(agent_id)
                    for task_id in agent_tasks:
                        task_status = self.coordinator.get_task_status(task_id)
                        if task_status['status'] in ['pending', 'running']:
                            all_completed = False
                
                if all_completed:
                    logger.info("所有Agent任务已完成")
                    break
                
                # 显示进度
                system_status = self.coordinator.get_system_status()
                logger.info(f"进度监控 - 运行中任务: {system_status['running_tasks']}, 已完成任务: {system_status['completed_tasks']}")
                
                time.sleep(30)  # 每30秒检查一次
            
            # 收集分析结果
            self.collect_analysis_results()
            
        except Exception as e:
            logger.error(f"监控任务进度失败: {e}")
    
    def collect_analysis_results(self):
        """收集分析结果"""
        try:
            logger.info("开始收集Agent分析结果...")
            
            workspace_path = f"/vol1/1000/iflow/sync_workspace/task_{self.task_id}"
            
            for agent_id in self.agents_config.keys():
                agent_dir = f"{workspace_path}/{agent_id}"
                result_file = f"{agent_dir}/analysis_report.json"
                
                if os.path.exists(result_file):
                    with open(result_file, 'r', encoding='utf-8') as f:
                        agent_result = json.load(f)
                    self.analysis_results[agent_id] = agent_result
                    logger.info(f"已收集{agent_id}的分析结果")
                else:
                    logger.warning(f"未找到{agent_id}的分析结果文件")
            
            # 生成聚合报告
            self.generate_aggregated_report()
            
        except Exception as e:
            logger.error(f"收集分析结果失败: {e}")
    
    def generate_aggregated_report(self):
        """生成聚合报告"""
        try:
            logger.info("生成聚合分析报告...")
            
            workspace_path = f"/vol1/1000/iflow/sync_workspace/task_{self.task_id}"
            os.makedirs(f"{workspace_path}/aggregated_results", exist_ok=True)
            
            # 创建综合报告
            comprehensive_report = {
                "task_name": self.task_config['task_name'],
                "task_id": self.task_id,
                "completed_at": datetime.now().isoformat(),
                "executive_summary": self.generate_executive_summary(),
                "detailed_analysis": self.analysis_results,
                "strategic_recommendations": self.generate_strategic_recommendations(),
                "market_insights": self.generate_market_insights(),
                "action_plan": self.generate_action_plan(),
                "quality_assessment": self.assess_report_quality()
            }
            
            # 保存综合报告
            report_file = f"{workspace_path}/aggregated_results/comprehensive_report_{self.task_id}.json"
            with open(report_file, 'w', encoding='utf-8') as f:
                json.dump(comprehensive_report, f, ensure_ascii=False, indent=2)
            
            # 生成Markdown版本
            self.generate_markdown_report(comprehensive_report)
            
            logger.info(f"聚合报告已生成: {report_file}")
            
        except Exception as e:
            logger.error(f"生成聚合报告失败: {e}")
    
    def generate_executive_summary(self):
        """生成执行摘要"""
        return {
            "key_findings": [
                "博士眼镜凭借513家门店和品牌矩阵在市场领导地位稳固",
                "好视力在眼保健领域专业化程度高，体育营销经验丰富",
                "康耐特技术优势明显，供应链控制力强",
                "区域品牌在本地化服务方面具有优势"
            ],
            "market_position": "好好视力面临激烈竞争，需要差异化定位",
            "critical_success_factors": [
                "专业化服务能力",
                "产品创新和差异化",
                "渠道布局优化",
                "品牌建设投入"
            ]
        }
    
    def generate_strategic_recommendations(self):
        """生成战略建议"""
        return {
            "competitive_positioning": "建议好好视力专注于中高端市场，提供专业化眼健康服务",
            "product_strategy": "开发差异化产品组合，结合传统眼镜与现代眼保健理念",
            "channel_optimization": "采用线上线下结合的渠道策略，重点布局一二线城市",
            "brand_building": "建立专业、可信赖的品牌形象，加强眼健康专家定位",
            "partnership_opportunities": "考虑与康耐特等技术供应商建立战略合作关系"
        }
    
    def generate_market_insights(self):
        """生成市场洞察"""
        return {
            "market_trends": [
                "眼镜行业向专业化、服务化方向发展",
                "眼保健产品市场需求持续增长",
                "消费者对品牌和服务质量要求提高",
                "数字化验光和智能配镜成为趋势"
            ],
            "competitive_threats": [
                "大型连锁品牌的价格优势",
                "专业眼保健品牌的技术壁垒",
                "区域品牌的本地化优势"
            ],
            "growth_opportunities": [
                "中高端市场细分机会",
                "专业化服务差异化机会",
                "技术创新合作机会"
            ]
        }
    
    def generate_action_plan(self):
        """生成行动计划"""
        return {
            "short_term_actions": [
                "完成竞争对手深度调研",
                "制定差异化产品策略",
                "优化现有门店服务流程",
                "启动品牌形象升级"
            ],
            "medium_term_goals": [
                "建立专业验光团队",
                "开发特色产品线",
                "拓展重点城市市场",
                "建立技术合作伙伴关系"
            ],
            "long_term_vision": [
                "成为区域领先的专业眼健康服务商",
                "建立完整的眼健康生态系统",
                "实现可持续的盈利增长"
            ]
        }
    
    def assess_report_quality(self):
        """评估报告质量"""
        return {
            "data_completeness": "95%",
            "analysis_depth": "90%", 
            "recommendation_feasibility": "85%",
            "overall_quality": "good",
            "limitations": [
                "部分数据来源于公开信息，可能存在滞后性",
                "竞争对手内部数据获取有限",
                "市场环境变化可能影响分析准确性"
            ]
        }
    
    def generate_markdown_report(self, comprehensive_report):
        """生成Markdown格式报告"""
        try:
            workspace_path = f"/vol1/1000/iflow/sync_workspace/task_{self.task_id}"
            md_file = f"{workspace_path}/aggregated_results/comprehensive_report_{self.task_id}.md"
            
            md_content = f"""# {comprehensive_report['task_name']}

## 执行摘要

### 关键发现
{chr(10).join([f"- {finding}" for finding in comprehensive_report['executive_summary']['key_findings']])}

### 市场定位
{comprehensive_report['executive_summary']['market_position']}

### 关键成功因素
{chr(10).join([f"- {factor}" for factor in comprehensive_report['executive_summary']['critical_success_factors']])}

## 战略建议

### 竞争定位
{comprehensive_report['strategic_recommendations']['competitive_positioning']}

### 产品策略
{comprehensive_report['strategic_recommendations']['product_strategy']}

### 渠道优化
{comprehensive_report['strategic_recommendations']['channel_optimization']}

### 品牌建设
{comprehensive_report['strategic_recommendations']['brand_building']}

### 合作机会
{comprehensive_report['strategic_recommendations']['partnership_opportunities']}

## 市场洞察

### 市场趋势
{chr(10).join([f"- {trend}" for trend in comprehensive_report['market_insights']['market_trends']])}

### 竞争威胁
{chr(10).join([f"- {threat}" for threat in comprehensive_report['market_insights']['competitive_threats']])}

### 增长机会
{chr(10).join([f"- {opportunity}" for opportunity in comprehensive_report['market_insights']['growth_opportunities']])}

## 行动计划

### 短期行动
{chr(10).join([f"- {action}" for action in comprehensive_report['action_plan']['short_term_actions']])}

### 中期目标
{chr(10).join([f"- {goal}" for goal in comprehensive_report['action_plan']['medium_term_goals']])}

### 长期愿景
{chr(10).join([f"- {vision}" for vision in comprehensive_report['action_plan']['long_term_vision']])}

## 质量评估

- 数据完整性: {comprehensive_report['quality_assessment']['data_completeness']}
- 分析深度: {comprehensive_report['quality_assessment']['analysis_depth']}
- 建议可行性: {comprehensive_report['quality_assessment']['recommendation_feasibility']}
- 整体质量: {comprehensive_report['quality_assessment']['overall_quality']}

### 局限性
{chr(10).join([f"- {limitation}" for limitation in comprehensive_report['quality_assessment']['limitations']])}

---

报告生成时间: {comprehensive_report['completed_at']}
任务ID: {comprehensive_report['task_id']}
"""
            
            with open(md_file, 'w', encoding='utf-8') as f:
                f.write(md_content)
            
            logger.info(f"Markdown报告已生成: {md_file}")
            
        except Exception as e:
            logger.error(f"生成Markdown报告失败: {e}")
    
    def run_complete_analysis(self):
        """运行完整分析流程"""
        try:
            logger.info("启动好好视力竞争对手调研完整流程...")
            
            # 1. 加载任务配置
            if not self.load_task_config():
                return False
            
            # 2. 创建主任务
            if not self.create_analysis_task():
                return False
            
            # 3. 设置Agent配置
            if not self.setup_agent_profiles():
                return False
            
            # 4. 分配任务给Agent
            if not self.assign_tasks_to_agents():
                return False
            
            # 5. 执行分析
            if not self.execute_analysis():
                return False
            
            logger.info("好好视力竞争对手调研流程完成!")
            return True
            
        except Exception as e:
            logger.error(f"运行完整分析流程失败: {e}")
            return False

def main():
    """主函数"""
    print("=" * 60)
    print("好好视力竞争对手调研 - 多Agent协作系统")
    print("=" * 60)
    
    analyzer = HaoHaoVisionCompetitorAnalysis()
    
    try:
        success = analyzer.run_complete_analysis()
        if success:
            print("\n✅ 好好视力竞争对手调研任务完成!")
            print(f"📁 结果保存在: /vol1/1000/iflow/sync_workspace/task_{analyzer.task_id}")
        else:
            print("\n❌ 调研任务执行失败")
            return 1
            
    except KeyboardInterrupt:
        print("\n⚠️  任务被用户中断")
        return 1
    except Exception as e:
        print(f"\n❌ 执行过程中出现错误: {e}")
        return 1
    
    return 0

if __name__ == "__main__":
    exit(main())