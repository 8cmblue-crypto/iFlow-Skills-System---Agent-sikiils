#!/usr/bin/env python3
"""
任务拆解对比测试
老大，这个脚本对比死板规则和智能思考两种拆解方式的差异
"""

import sys
import os
from datetime import datetime

# 添加当前目录到Python路径
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from task_coordinator import Task

def test_rule_based_decomposition():
    """测试基于死板规则的拆解"""
    print("=== 死板规则拆解测试 ===\n")
    
    try:
        from task_decomposer import TaskDecomposer
        decomposer = TaskDecomposer()
        
        # 创建测试任务
        task = Task(
            id="test-rule-001",
            name="电商平台支付模块安全审查",
            description="对电商平台的支付处理模块进行全面的安全审查，包括SQL注入防护、XSS攻击防护、支付数据加密、交易完整性验证等安全检查，同时需要考虑高并发场景下的性能表现。",
            priority="high",
            status="pending",
            created_at=datetime.now().isoformat(),
            estimated_time=600,
            required_capabilities=["security_check", "performance_analysis"],
            dependencies=[],
            subtasks=[]
        )
        
        # 执行拆解
        subtasks = decomposer.decompose(task)
        
        print(f"任务类型识别: {decomposer._identify_task_type(task.description)}")
        print(f"生成子任务数量: {len(subtasks)}")
        print("\n子任务列表:")
        for i, subtask in enumerate(subtasks, 1):
            print(f"{i}. {subtask['name']}")
            print(f"   描述: {subtask['description']}")
            print(f"   能力需求: {subtask['required_capabilities']}")
            print(f"   预估时间: {subtask['estimated_time']}秒")
            print()
        
        return subtasks
        
    except Exception as e:
        print(f"死板规则拆解失败: {e}")
        return []

def test_intelligent_decomposition():
    """测试基于智能思考的拆解"""
    print("=== 智能思考拆解测试 ===\n")
    
    try:
        from intelligent_task_decomposer import IntelligentTaskDecomposer
        decomposer = IntelligentTaskDecomposer()
        
        # 创建相同的测试任务
        task = Task(
            id="test-intelligent-001",
            name="电商平台支付模块安全审查",
            description="对电商平台的支付处理模块进行全面的安全审查，包括SQL注入防护、XSS攻击防护、支付数据加密、交易完整性验证等安全检查，同时需要考虑高并发场景下的性能表现。",
            priority="high",
            status="pending",
            created_at=datetime.now().isoformat(),
            estimated_time=600,
            required_capabilities=["security_check", "performance_analysis"],
            dependencies=[],
            subtasks=[]
        )
        
        # 执行智能拆解
        subtasks = decomposer.decompose(task)
        
        # 显示分析结果
        analysis = decomposer._deep_analyze_task(task)
        print(f"智能识别任务类型: {analysis['task_type']}")
        print(f"整体复杂度: {analysis['complexity_indicators']['overall']:.2f}")
        print(f"任务范围: {analysis['scope_assessment']}")
        print(f"上下文关键词: {analysis['context_keywords']}")
        print(f"特殊要求: {analysis['special_requirements']}")
        print(f"估算工作量: {analysis['estimated_effort']}分钟")
        
        # 显示策略思考
        strategy = decomposer._think_decomposition_strategy(analysis)
        print(f"\n拆解策略思考:")
        for reasoning in strategy['reasoning']:
            print(f"  - {reasoning}")
        
        print(f"\n生成子任务数量: {len(subtasks)}")
        print("\n子任务列表:")
        for i, subtask in enumerate(subtasks, 1):
            print(f"{i}. {subtask['name']}")
            print(f"   描述: {subtask['description']}")
            print(f"   能力需求: {subtask['required_capabilities']}")
            print(f"   预估时间: {subtask['estimated_time']}秒")
            print(f"   思考过程: {subtask['reasoning']}")
            print()
        
        return subtasks
        
    except Exception as e:
        print(f"智能思考拆解失败: {e}")
        return []

def compare_decomposition_methods():
    """对比两种拆解方法"""
    print("=== 拆解方法对比分析 ===\n")
    
    # 测试不同类型的任务
    test_tasks = [
        {
            "name": "简单文档编写",
            "description": "编写API接口文档",
            "expected_difficulty": "简单"
        },
        {
            "name": "复杂系统重构",
            "description": "对整个电商系统进行架构重构，包括微服务拆分、数据库优化、缓存策略改进，同时需要保证系统稳定性和性能提升",
            "expected_difficulty": "复杂"
        },
        {
            "name": "特定安全审查",
            "description": "对支付模块进行安全审查，重点关注SQL注入和XSS防护",
            "expected_difficulty": "中等但有特殊要求"
        }
    ]
    
    for i, test_case in enumerate(test_tasks, 1):
        print(f"测试案例 {i}: {test_case['name']} (预期难度: {test_case['expected_difficulty']})")
        print("-" * 80)
        
        task = Task(
            id=f"compare-{i:03d}",
            name=test_case['name'],
            description=test_case['description'],
            priority="medium",
            status="pending",
            created_at=datetime.now().isoformat(),
            estimated_time=300,
            required_capabilities=[],
            dependencies=[],
            subtasks=[]
        )
        
        # 死板规则拆解
        try:
            from task_decomposer import TaskDecomposer
            rule_decomposer = TaskDecomposer()
            rule_subtasks = rule_decomposer.decompose(task)
            print(f"死板规则: {len(rule_subtasks)} 个子任务")
            for subtask in rule_subtasks:
                print(f"  - {subtask['name']} ({subtask['estimated_time']}s)")
        except Exception as e:
            print(f"死板规则失败: {e}")
        
        # 智能思考拆解
        try:
            from intelligent_task_decomposer import IntelligentTaskDecomposer
            intel_decomposer = IntelligentTaskDecomposer()
            intel_subtasks = intel_decomposer.decompose(task)
            print(f"智能思考: {len(intel_subtasks)} 个子任务")
            for subtask in intel_subtasks:
                print(f"  - {subtask['name']} ({subtask['estimated_time']}s) - {subtask['reasoning'][:50]}...")
        except Exception as e:
            print(f"智能思考失败: {e}")
        
        print("\n")

def main():
    """主函数"""
    print("任务拆解方式对比测试")
    print("=" * 80)
    print("\n")
    
    # 测试相同任务的两种拆解方式
    print("使用相同任务测试两种拆解方式的差异:\n")
    
    test_task_description = "对电商平台的支付处理模块进行全面的安全审查，包括SQL注入防护、XSS攻击防护、支付数据加密、交易完整性验证等安全检查，同时需要考虑高并发场景下的性能表现。"
    
    print(f"测试任务: {test_task_description}\n")
    
    # 死板规则拆解
    rule_subtasks = test_rule_based_decomposition()
    
    print("\n" + "=" * 80 + "\n")
    
    # 智能思考拆解
    intel_subtasks = test_intelligent_decomposition()
    
    print("\n" + "=" * 80 + "\n")
    
    # 对比分析
    compare_decomposition_methods()
    
    # 总结差异
    print("=== 差异总结 ===\n")
    print("🤖 死板规则拆解的特点:")
    print("  ✓ 简单快速，基于关键词匹配")
    print("  ✓ 规则明确，结果可预测")
    print("  ✗ 无法理解上下文和特殊要求")
    print("  ✗ 拆解结果可能不符合实际需求")
    print("  ✗ 对复杂任务处理能力有限")
    
    print("\n🧠 智能思考拆解的特点:")
    print("  ✓ 深度分析任务特征和上下文")
    print("  ✓ 根据特殊要求动态调整策略")
    print("  ✓ 提供详细的思考过程说明")
    print("  ✓ 更好地适应复杂和特殊任务")
    print("  ✗ 计算开销相对较大")
    print("  ✗ 结果相对复杂，需要更多验证")
    
    print(f"\n建议: 对于简单、重复性任务使用死板规则；对于复杂、特殊任务使用智能思考。")

if __name__ == "__main__":
    main()