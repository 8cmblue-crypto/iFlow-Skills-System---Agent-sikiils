#!/usr/bin/env python3
"""
备得福竞品分析测试脚本
老大，这个脚本专门测试备得福榨菜竞品分析的完整协同工作流程
验证任务拆解、Agent分配、协同执行和结果聚合的全过程
"""

import sys
import os
import json
import time
import logging
from datetime import datetime
from pathlib import Path

# 添加技能路径
sys.path.append('/vol1/1000/iflow/skills/task-coordinator/scripts')

from task_coordinator import TaskCoordinator

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('/vol1/1000/iflow/skills/task-coordinator/logs/beidefu_test.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class BeiDefuAnalysisTest:
    """备得福竞品分析测试类"""
    
    def __init__(self):
        self.coordinator = TaskCoordinator()
        self.test_task_id = None
        self.test_results = {}
        
    def setup_test_environment(self):
        """设置测试环境"""
        try:
            logger.info("=== 设置备得福竞品分析测试环境 ===")
            
            # 确保必要目录存在
            test_dirs = [
                '/vol1/1000/iflow/skills/task-coordinator/logs',
                '/vol1/1000/iflow/skills/task-coordinator/results',
                '/vol1/1000/iflow/skills/task-coordinator/sessions',
                '/vol1/1000/iflow/sync_workspace'
            ]
            
            for directory in test_dirs:
                Path(directory).mkdir(parents=True, exist_ok=True)
            
            logger.info("测试环境设置完成")
            return True
            
        except Exception as e:
            logger.error(f"设置测试环境失败: {e}")
            return False
    
    def load_test_task_config(self):
        """加载测试任务配置"""
        try:
            config_path = '/vol1/1000/iflow/skills/task-coordinator/tasks/beidefu_competitor_analysis.json'
            with open(config_path, 'r', encoding='utf-8') as f:
                self.task_config = json.load(f)
            logger.info("测试任务配置加载成功")
            return True
        except Exception as e:
            logger.error(f"加载测试任务配置失败: {e}")
            return False
    
    def create_test_task(self):
        """创建测试任务"""
        try:
            logger.info("=== 创建备得福竞品分析测试任务 ===")
            
            task_name = f"[TEST] {self.task_config['task_name']}"
            task_description = f"[测试模式] {self.task_config['task_description']}"
            priority = self.task_config['task_priority']
            
            # 创建测试任务
            self.test_task_id = self.coordinator.create_task(
                name=task_name,
                description=task_description,
                priority=priority
            )
            
            logger.info(f"测试任务创建成功: {self.test_task_id}")
            return True
            
        except Exception as e:
            logger.error(f"创建测试任务失败: {e}")
            return False
    
    def setup_test_agents(self):
        """设置测试Agent"""
        try:
            logger.info("=== 设置测试Agent ===")
            
            # 定义测试专用的简化Agent配置
            test_agents = {
                "test_xiaoming": {
                    "name": "测试-小明",
                    "capabilities": ["market_analysis", "competitor_research"],
                    "max_concurrent_tasks": 3,
                    "specialties": ["市场策略", "品牌分析"]
                },
                "test_xiaobai": {
                    "name": "测试-小白",
                    "capabilities": ["international_market", "export_analysis"],
                    "max_concurrent_tasks": 3,
                    "specialties": ["国际市场", "出口贸易"]
                },
                "test_xiaochen": {
                    "name": "测试-小陈",
                    "capabilities": ["regional_analysis", "local_competition"],
                    "max_concurrent_tasks": 3,
                    "specialties": ["区域市场", "本地竞争"]
                },
                "test_xiaoli": {
                    "name": "测试-小李",
                    "capabilities": ["product_differentiation", "brand_positioning"],
                    "max_concurrent_tasks": 3,
                    "specialties": ["产品差异化", "品牌定位"]
                }
            }
            
            # 更新coordinator中的agents
            for agent_id, profile in test_agents.items():
                if agent_id in self.coordinator.agents:
                    # 更新现有Agent
                    agent = self.coordinator.agents[agent_id]
                    agent.name = profile["name"]
                    agent.capabilities = profile["capabilities"]
                    agent.specialties = profile["specialties"]
                else:
                    # 创建新Agent
                    from task_coordinator import Agent
                    self.coordinator.agents[agent_id] = Agent(
                        id=agent_id,
                        name=profile["name"],
                        capabilities=profile["capabilities"],
                        max_concurrent_tasks=profile["max_concurrent_tasks"],
                        current_tasks=0,
                        specialties=profile["specialties"],
                        status='available',
                        last_active=datetime.now().isoformat()
                    )
            
            logger.info(f"测试Agent设置完成，共{len(test_agents)}个Agent")
            return True
            
        except Exception as e:
            logger.error(f"设置测试Agent失败: {e}")
            return False
    
    def test_task_decomposition(self):
        """测试任务拆解功能"""
        try:
            logger.info("=== 测试任务拆解功能 ===")
            
            if not self.test_task_id:
                logger.error("测试任务ID不存在")
                return False
            
            # 执行任务拆解
            success = self.coordinator.decompose_task(self.test_task_id)
            
            if success:
                task = self.coordinator.tasks[self.test_task_id]
                logger.info(f"任务拆解成功，生成{len(task.subtasks)}个子任务")
                
                # 验证子任务结构
                for i, subtask in enumerate(task.subtasks):
                    logger.info(f"子任务{i+1}: {subtask.get('name', 'Unknown')}")
                
                self.test_results['decomposition'] = {
                    'success': True,
                    'subtask_count': len(task.subtasks),
                    'subtasks': [{'name': st.get('name'), 'id': st.get('id')} for st in task.subtasks]
                }
                return True
            else:
                logger.error("任务拆解失败")
                self.test_results['decomposition'] = {'success': False}
                return False
                
        except Exception as e:
            logger.error(f"测试任务拆解失败: {e}")
            self.test_results['decomposition'] = {'success': False, 'error': str(e)}
            return False
    
    def test_agent_assignment(self):
        """测试Agent分配功能"""
        try:
            logger.info("=== 测试Agent分配功能 ===")
            
            if not self.test_task_id:
                logger.error("测试任务ID不存在")
                return False
            
            # 执行任务分配
            success = self.coordinator.assign_tasks(self.test_task_id, auto_assign=True)
            
            if success:
                assignments = self.coordinator.active_assignments.get(self.test_task_id, [])
                logger.info(f"Agent分配成功，{len(assignments)}个子任务已分配")
                
                # 验证分配结果
                for assignment in assignments:
                    logger.info(f"分配: {assignment.get('agent_name')} -> {assignment.get('task_name')}")
                
                self.test_results['assignment'] = {
                    'success': True,
                    'assignment_count': len(assignments),
                    'assignments': [{'agent': a.get('agent_name'), 'task': a.get('task_name')} for a in assignments]
                }
                return True
            else:
                logger.error("Agent分配失败")
                self.test_results['assignment'] = {'success': False}
                return False
                
        except Exception as e:
            logger.error(f"测试Agent分配失败: {e}")
            self.test_results['assignment'] = {'success': False, 'error': str(e)}
            return False
    
    def test_collaborative_execution(self):
        """测试协同执行功能"""
        try:
            logger.info("=== 测试协同执行功能 ===")
            
            if not self.test_task_id:
                logger.error("测试任务ID不存在")
                return False
            
            # 执行协同任务
            success = self.coordinator.coordinate_collaborative_task(self.test_task_id)
            
            if success:
                logger.info("协同执行启动成功")
                
                # 获取协同状态
                collaboration_status = self.coordinator.get_collaboration_status(self.test_task_id)
                
                self.test_results['execution'] = {
                    'success': True,
                    'task_status': collaboration_status.get('task_status'),
                    'assignment_count': len(collaboration_status.get('assignments', [])),
                    'file_sync_enabled': bool(collaboration_status.get('file_sync_status'))
                }
                return True
            else:
                logger.error("协同执行启动失败")
                self.test_results['execution'] = {'success': False}
                return False
                
        except Exception as e:
            logger.error(f"测试协同执行失败: {e}")
            self.test_results['execution'] = {'success': False, 'error': str(e)}
            return False
    
    def simulate_agent_outputs(self):
        """模拟Agent输出"""
        try:
            logger.info("=== 模拟Agent执行输出 ===")
            
            assignments = self.coordinator.active_assignments.get(self.test_task_id, [])
            agent_outputs = []
            
            for i, assignment in enumerate(assignments):
                # 生成模拟输出
                output = {
                    "task_id": assignment.get('task_id'),
                    "agent_id": assignment.get('agent_id'),
                    "agent_name": assignment.get('agent_name'),
                    "success": True,
                    "execution_time": 300 + i * 60,  # 5-10分钟不等
                    "output": f"""
=== {assignment.get('task_name')} 测试执行结果 ===
执行Agent: {assignment.get('agent_name')}
任务ID: {assignment.get('task_id')}
执行时间: {300 + i * 60}秒

测试分析结果:
- 数据收集: 完成
- 竞品分析: 完成
- 对比研究: 完成
- 策略建议: 已生成

关键发现:
1. 竞品市场定位清晰
2. 产品差异化明显
3. 价格策略合理
4. 渠道布局完善

建议:
1. 加强品牌建设
2. 优化产品结构
3. 拓展销售渠道
4. 提升服务质量

注: 这是测试模式的模拟输出
            """.strip(),
                    "timestamp": datetime.now().isoformat()
                }
                agent_outputs.append(output)
                logger.info(f"模拟Agent {assignment.get('agent_name')} 输出完成")
            
            self.agent_outputs = agent_outputs
            logger.info(f"模拟输出生成完成，共{len(agent_outputs)}个Agent结果")
            return True
            
        except Exception as e:
            logger.error(f"模拟Agent输出失败: {e}")
            return False
    
    def test_result_aggregation(self):
        """测试结果聚合功能"""
        try:
            logger.info("=== 测试结果聚合功能 ===")
            
            if not hasattr(self, 'agent_outputs'):
                logger.error("Agent输出不存在，无法测试结果聚合")
                return False
            
            # 执行结果聚合
            aggregated_results = self.coordinator.collect_and_aggregate_results(
                self.test_task_id, 
                self.agent_outputs
            )
            
            if aggregated_results:
                summary = aggregated_results.get('summary', {})
                logger.info(f"结果聚合成功")
                logger.info(f"总任务数: {summary.get('total_tasks', 0)}")
                logger.info(f"完成任务数: {summary.get('completed_tasks', 0)}")
                logger.info(f"失败任务数: {summary.get('failed_tasks', 0)}")
                
                self.test_results['aggregation'] = {
                    'success': True,
                    'total_tasks': summary.get('total_tasks', 0),
                    'completed_tasks': summary.get('completed_tasks', 0),
                    'failed_tasks': summary.get('failed_tasks', 0),
                    'has_conflicts': len(aggregated_results.get('conflicts', [])) > 0
                }
                return True
            else:
                logger.error("结果聚合失败")
                self.test_results['aggregation'] = {'success': False}
                return False
                
        except Exception as e:
            logger.error(f"测试结果聚合失败: {e}")
            self.test_results['aggregation'] = {'success': False, 'error': str(e)}
            return False
    
    def test_file_sync(self):
        """测试文件同步功能"""
        try:
            logger.info("=== 测试文件同步功能 ===")
            
            if not self.coordinator.file_sync_system:
                logger.warning("文件同步系统未初始化，跳过测试")
                self.test_results['file_sync'] = {'skipped': True, 'reason': '文件同步系统未初始化'}
                return True
            
            # 创建测试文件
            test_files = []
            for i in range(3):
                file_content = f"""
# 备得福竞品分析测试文件 {i+1}
生成时间: {datetime.now().isoformat()}
任务ID: {self.test_task_id}

这是备得福竞品分析测试过程中生成的示例文件。
包含测试执行结果和分析报告。

测试内容:
- 任务拆解验证
- Agent分配验证
- 协同执行验证
- 结果聚合验证
                """.strip()
                
                file_path = f"/tmp/beidefu_test_file_{i+1}.md"
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.write(file_content)
                test_files.append(file_path)
            
            # 测试文件同步
            sync_success = self.coordinator.sync_files_for_task(
                self.test_task_id, 
                test_files, 
                "test_agent"
            )
            
            # 清理测试文件
            for file_path in test_files:
                if os.path.exists(file_path):
                    os.remove(file_path)
            
            if sync_success:
                logger.info("文件同步测试成功")
                self.test_results['file_sync'] = {'success': True}
                return True
            else:
                logger.error("文件同步测试失败")
                self.test_results['file_sync'] = {'success': False}
                return False
                
        except Exception as e:
            logger.error(f"测试文件同步失败: {e}")
            self.test_results['file_sync'] = {'success': False, 'error': str(e)}
            return False
    
    def test_report_generation(self):
        """测试报告生成功能"""
        try:
            logger.info("=== 测试报告生成功能 ===")
            
            # 使用结果聚合器生成报告
            if hasattr(self.coordinator, 'result_aggregator') and self.coordinator.result_aggregator:
                report_result = self.coordinator.result_aggregator.create_comprehensive_report(self.test_task_id)
                
                if report_result.get('status') == 'success':
                    logger.info("报告生成成功")
                    
                    self.test_results['report_generation'] = {
                        'success': True,
                        'report_file': report_result.get('report_file'),
                        'executive_summary': report_result.get('executive_summary')
                    }
                    return True
                else:
                    logger.error("报告生成失败")
                    self.test_results['report_generation'] = {'success': False}
                    return False
            else:
                # 创建简单的报告
                simple_report = f"""
# 备得福竞品分析任务测试报告

**任务ID**: {self.test_task_id}
**生成时间**: {datetime.now().isoformat()}
**测试状态**: 完成

## 测试结果

{chr(10).join([f"- {k}: {v.get('success', False)}" for k, v in self.test_results.items()])}

## 测试数据

任务已创建并执行了完整的工作流程，包括：
- 任务创建
- 任务拆解
- Agent分配
- 协同执行
- 结果聚合

所有核心功能已验证正常工作。
                """.strip()
                
                # 保存报告
                report_file = f"/vol1/1000/iflow/skills/task-coordinator/results/beidefu_test_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.md"
                with open(report_file, 'w', encoding='utf-8') as f:
                    f.write(simple_report)
                
                logger.info("简单报告生成成功")
                
                self.test_results['report_generation'] = {
                    'success': True,
                    'report_file': report_file,
                    'report_length': len(simple_report)
                }
                return True
                
        except Exception as e:
            logger.error(f"测试报告生成失败: {e}")
            self.test_results['report_generation'] = {'success': False, 'error': str(e)}
            return False
    
    def generate_test_summary(self):
        """生成测试总结"""
        try:
            logger.info("=== 生成测试总结 ===")
            
            total_tests = len(self.test_results)
            passed_tests = len([r for r in self.test_results.values() if r.get('success', False)])
            failed_tests = total_tests - passed_tests
            
            summary = f"""
# 备得福竞品分析测试总结

**测试时间**: {datetime.now().isoformat()}
**测试任务ID**: {self.test_task_id}
**总测试项**: {total_tests}
**通过测试**: {passed_tests}
**失败测试**: {failed_tests}
**成功率**: {passed_tests/total_tests*100:.1f}%

## 测试结果详情

"""
            
            for test_name, result in self.test_results.items():
                status = "✅ 通过" if result.get('success', False) else "❌ 失败"
                summary += f"### {test_name}: {status}\n"
                
                if result.get('success'):
                    if 'subtask_count' in result:
                        summary += f"- 子任务数量: {result['subtask_count']}\n"
                    if 'assignment_count' in result:
                        summary += f"- 分配数量: {result['assignment_count']}\n"
                    if 'total_tasks' in result:
                        summary += f"- 总任务数: {result['total_tasks']}\n"
                        summary += f"- 完成任务数: {result['completed_tasks']}\n"
                    if 'report_file' in result:
                        summary += f"- 报告文件: {result['report_file']}\n"
                else:
                    if 'error' in result:
                        summary += f"- 错误信息: {result['error']}\n"
                    if 'skipped' in result:
                        summary += f"- 跳过原因: {result['reason']}\n"
                
                summary += "\n"
            
            # 添加测试结论
            if passed_tests == total_tests:
                summary += "## 测试结论\n\n✅ **所有测试通过**！备得福竞品分析协同工作流程功能正常。\n"
            elif passed_tests >= total_tests * 0.8:
                summary += "## 测试结论\n\n⚠️ **大部分测试通过**！系统基本功能正常，部分功能需要优化。\n"
            else:
                summary += "## 测试结论\n\n❌ **测试失败较多**！系统存在严重问题，需要修复。\n"
            
            # 保存测试总结
            summary_file = f"/vol1/1000/iflow/skills/task-coordinator/results/beidefu_test_summary_{datetime.now().strftime('%Y%m%d_%H%M%S')}.md"
            with open(summary_file, 'w', encoding='utf-8') as f:
                f.write(summary)
            
            logger.info(f"测试总结已保存: {summary_file}")
            print(summary)
            
            return True
            
        except Exception as e:
            logger.error(f"生成测试总结失败: {e}")
            return False
    
    def run_complete_test(self):
        """运行完整的测试流程"""
        try:
            logger.info("=== 开始备得福竞品分析完整测试 ===")
            start_time = time.time()
            
            # 1. 设置测试环境
            if not self.setup_test_environment():
                return False
            
            # 2. 加载测试配置
            if not self.load_test_task_config():
                return False
            
            # 3. 创建测试任务
            if not self.create_test_task():
                return False
            
            # 4. 设置测试Agent
            if not self.setup_test_agents():
                return False
            
            # 5. 测试任务拆解
            if not self.test_task_decomposition():
                return False
            
            # 6. 测试Agent分配
            if not self.test_agent_assignment():
                return False
            
            # 7. 测试协同执行
            if not self.test_collaborative_execution():
                return False
            
            # 8. 模拟Agent输出
            if not self.simulate_agent_outputs():
                return False
            
            # 9. 测试结果聚合
            if not self.test_result_aggregation():
                return False
            
            # 10. 测试文件同步
            if not self.test_file_sync():
                return False
            
            # 11. 测试报告生成
            if not self.test_report_generation():
                return False
            
            # 12. 生成测试总结
            if not self.generate_test_summary():
                return False
            
            end_time = time.time()
            duration = end_time - start_time
            
            logger.info(f"=== 备得福竞品分析测试完成，耗时: {duration:.2f}秒 ===")
            return True
            
        except Exception as e:
            logger.error(f"运行完整测试失败: {e}")
            return False

def main():
    """主函数"""
    print("🧪 备得福榨菜竞品分析协同工作流程测试")
    print("=" * 50)
    
    test_runner = BeiDefuAnalysisTest()
    success = test_runner.run_complete_test()
    
    if success:
        print("\n✅ 测试完成！")
        print(f"📊 测试任务ID: {test_runner.test_task_id}")
        print("📁 查看测试结果:")
        print("   - 日志文件: /vol1/1000/iflow/skills/task-coordinator/logs/beidefu_test.log")
        print("   - 结果目录: /vol1/1000/iflow/skills/task-coordinator/results/")
    else:
        print("\n❌ 测试失败！")
        return 1
    
    return 0

if __name__ == "__main__":
    exit(main())