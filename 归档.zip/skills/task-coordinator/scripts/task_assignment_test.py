#!/usr/bin/env python3
"""
任务分配测试脚本
测试完整的Agent任务分配、执行和结果收集流程
"""

import json
import time
from datetime import datetime
from typing import Dict, List, Any
from session_manager import SessionManager
from pathlib import Path

class TaskAssignmentTester:
    """任务分配测试器"""
    
    def __init__(self):
        self.session_manager = SessionManager()
        self.results_storage = Path("/vol1/1000/iflow/sync_workspace/test_results")
        self.results_storage.mkdir(parents=True, exist_ok=True)
        
    def test_complete_workflow(self) -> Dict[str, Any]:
        """测试完整的工作流程"""
        print("🚀 开始测试完整任务分配工作流程")
        print("=" * 50)
        
        # 定义测试任务
        test_tasks = [
            {
                "agent_name": "小明",
                "task_description": "备得福竞品分析专项",
                "task_command": "请分析乌江榨菜的市场竞争策略，重点关注其品牌定位、价格策略和渠道布局",
                "expected_output": "乌江榨菜市场策略分析报告"
            },
            {
                "agent_name": "小白",
                "task_description": "备得福竞品分析专项", 
                "task_command": "请分析鱼泉榨菜的国际市场表现，重点关注其出口策略和海外渠道建设",
                "expected_output": "鱼泉榨菜国际市场分析报告"
            }
        ]
        
        results = {
            "test_start_time": datetime.now().isoformat(),
            "tasks": [],
            "summary": {},
            "test_end_time": None
        }
        
        # 1. 创建会话并分配任务
        print("\n📝 第一步：创建Agent会话并分配任务")
        created_sessions = []
        
        for i, task in enumerate(test_tasks, 1):
            print(f"\n🔧 处理任务 {i}/{len(test_tasks)}: {task['agent_name']}")
            
            # 创建会话
            session_result = self.session_manager.create_session(
                task["agent_name"], 
                task["task_description"]
            )
            
            if session_result["status"] != "success":
                print(f"❌ 创建会话失败: {session_result}")
                continue
            
            session_id = session_result["session_id"]
            created_sessions.append(session_id)
            
            print(f"✅ 会话创建成功: {session_id}")
            
            # 等待会话稳定
            time.sleep(3)
            
            # 分配任务
            task_result = self.session_manager.assign_task_to_session(
                session_id, 
                task["task_command"]
            )
            
            task_info = {
                "agent_name": task["agent_name"],
                "session_id": session_id,
                "task_command": task["task_command"],
                "expected_output": task["expected_output"],
                "session_creation": session_result,
                "task_assignment": task_result,
                "status": "assigned"
            }
            
            results["tasks"].append(task_info)
            
            if task_result["status"] == "success":
                print(f"✅ 任务分配成功")
            else:
                print(f"⚠️ 任务分配有问题: {task_result.get('error', 'Unknown error')}")
        
        # 2. 等待任务执行
        print(f"\n⏳ 第二步：等待任务执行 (30秒)")
        time.sleep(30)
        
        # 3. 检查任务执行状态
        print("\n📊 第三步：检查任务执行状态")
        
        for task_info in results["tasks"]:
            session_id = task_info["session_id"]
            
            # 获取会话状态
            status_result = self.session_manager.get_session_status(session_id)
            
            if status_result["status"] == "success":
                session = status_result["session"]
                task_info["execution_status"] = session.get("process_status", "unknown")
                task_info["commands_history"] = session.get("commands", [])
                
                print(f"📋 {task_info['agent_name']}: {task_info['execution_status']}")
                print(f"   命令历史: {len(task_info['commands_history'])} 个")
            else:
                task_info["execution_status"] = "error"
                print(f"❌ {task_info['agent_name']}: 获取状态失败")
        
        # 4. 收集结果
        print("\n📤 第四步：收集任务结果")
        
        for task_info in results["tasks"]:
            agent_name = task_info["agent_name"]
            session_id = task_info["session_id"]
            
            # 查找结果文件
            result_files = self._find_result_files(agent_name, session_id)
            task_info["result_files"] = result_files
            
            if result_files:
                print(f"✅ {agent_name}: 找到 {len(result_files)} 个结果文件")
                # 读取结果内容
                result_content = self._read_result_files(result_files)
                task_info["result_content"] = result_content
            else:
                print(f"⚠️ {agent_name}: 未找到结果文件")
                task_info["result_content"] = None
        
        # 5. 清理会话
        print("\n🧹 第五步：清理测试会话")
        
        for session_id in created_sessions:
            terminate_result = self.session_manager.terminate_session(session_id)
            if terminate_result["status"] == "success":
                print(f"✅ 终止会话: {session_id}")
            else:
                print(f"❌ 终止会话失败: {session_id}")
        
        # 6. 生成测试报告
        results["test_end_time"] = datetime.now().isoformat()
        results["summary"] = self._generate_summary(results)
        
        # 保存测试报告
        report_file = self.results_storage / f"task_assignment_test_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(report_file, 'w', encoding='utf-8') as f:
            json.dump(results, f, ensure_ascii=False, indent=2)
        
        print(f"\n📄 测试报告已保存: {report_file}")
        
        return results
    
    def _find_result_files(self, agent_name: str, session_id: str) -> List[str]:
        """查找Agent生成的结果文件"""
        result_files = []
        
        # 查找可能的结果文件位置
        search_paths = [
            f"/vol1/1000/iflow/sync_workspace/task_{session_id}",
            f"/vol1/1000/iflow/sync_workspace/{agent_name}",
            f"/home/vinson/.iflow/sessions/{session_id}",
            f"/vol1/1000/iflow/results/{agent_name}"
        ]
        
        for search_path in search_paths:
            try:
                path = Path(search_path)
                if path.exists():
                    # 查找常见的文件类型
                    for pattern in ["*.md", "*.txt", "*.json", "*.pdf", "*.docx"]:
                        for file_path in path.glob(pattern):
                            result_files.append(str(file_path))
            except Exception as e:
                print(f"⚠️ 搜索路径失败 {search_path}: {e}")
        
        return result_files
    
    def _read_result_files(self, file_paths: List[str]) -> Dict[str, Any]:
        """读取结果文件内容"""
        content = {}
        
        for file_path in file_paths:
            try:
                path = Path(file_path)
                if path.exists() and path.stat().st_size < 1024 * 1024:  # 小于1MB
                    with open(path, 'r', encoding='utf-8') as f:
                        content[path.name] = f.read()[:1000]  # 只读取前1000字符
            except Exception as e:
                content[path.name] = f"读取失败: {e}"
        
        return content
    
    def _generate_summary(self, results: Dict[str, Any]) -> Dict[str, Any]:
        """生成测试摘要"""
        summary = {
            "total_tasks": len(results["tasks"]),
            "successful_sessions": 0,
            "successful_assignments": 0,
            "tasks_with_results": 0,
            "execution_time": None
        }
        
        # 计算执行时间
        if results.get("test_start_time") and results.get("test_end_time"):
            start = datetime.fromisoformat(results["test_start_time"])
            end = datetime.fromisoformat(results["test_end_time"])
            summary["execution_time"] = str(end - start)
        
        # 统计成功情况
        for task in results["tasks"]:
            if task.get("session_creation", {}).get("status") == "success":
                summary["successful_sessions"] += 1
            
            if task.get("task_assignment", {}).get("status") == "success":
                summary["successful_assignments"] += 1
            
            if task.get("result_files"):
                summary["tasks_with_results"] += 1
        
        return summary

def main():
    """主函数"""
    tester = TaskAssignmentTester()
    
    try:
        results = tester.test_complete_workflow()
        
        print("\n" + "=" * 50)
        print("📊 测试摘要:")
        summary = results["summary"]
        print(f"  总任务数: {summary['total_tasks']}")
        print(f"  成功创建会话: {summary['successful_sessions']}")
        print(f"  成功分配任务: {summary['successful_assignments']}")
        print(f"  有结果文件的任务: {summary['tasks_with_results']}")
        print(f"  执行时间: {summary.get('execution_time', 'N/A')}")
        
        # 显示详细结果
        print("\n📋 详细结果:")
        for i, task in enumerate(results["tasks"], 1):
            print(f"\n任务 {i}: {task['agent_name']}")
            print(f"  会话ID: {task['session_id']}")
            print(f"  执行状态: {task.get('execution_status', 'unknown')}")
            print(f"  结果文件数: {len(task.get('result_files', []))}")
            
    except Exception as e:
        print(f"❌ 测试过程中发生错误: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()