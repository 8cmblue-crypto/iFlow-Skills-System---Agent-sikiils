#!/usr/bin/env python3
"""
Agent状态监控系统
老大，这个模块负责监控所有Agent的实时状态
"""

import json
import time
import os
import psutil
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
from dataclasses import dataclass, asdict
from enum import Enum
import logging

logger = logging.getLogger(__name__)

class AgentStatus(Enum):
    """Agent状态枚举"""
    AVAILABLE = "空闲中"
    BUSY = "忙碌中"
    OFFLINE = "失联中"
    ERROR = "错误中"
    MAINTENANCE = "维护中"

@dataclass
class AgentInfo:
    """Agent信息数据结构"""
    id: str
    name: str
    status: AgentStatus
    capabilities: List[str]
    current_tasks: int
    max_concurrent_tasks: int
    specialties: List[str]
    last_active: str
    response_time: float  # 响应时间（毫秒）
    success_rate: float   # 成功率
    error_count: int      # 错误计数
    uptime: float         # 运行时间（小时）

class AgentStatusMonitor:
    """Agent状态监控器"""
    
    def __init__(self):
        self.agents: Dict[str, AgentInfo] = {}
        self.status_history: Dict[str, List[Dict]] = {}
        self.heartbeat_interval = 30  # 心跳间隔（秒）
        self.offline_threshold = 120  # 失联阈值（秒）
        
        # 初始化本地Agent
        self._initialize_local_agent()
    
    def _count_local_iflow_sessions(self) -> int:
        """统计本地iFlow会话数量"""
        try:
            import psutil
            session_count = 0
            current_pid = os.getpid()
            
            # 查找所有包含"iflow"的进程
            for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
                try:
                    cmdline = proc.info.get('cmdline', [])
                    if cmdline and any('iflow' in str(cmd).lower() for cmd in cmdline):
                        session_count += 1
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
            
            return session_count
        except Exception as e:
            logger.error(f"统计iFlow会话失败: {e}")
            return 1  # 默认返回1，表示当前会话
    
    def _initialize_local_agent(self):
        """初始化本地Agent（本机会话）"""
        local_agent = AgentInfo(
            id="iflow-local",
            name="iFlow本机Agent",
            status=AgentStatus.AVAILABLE,
            capabilities=[
                "text_processing", "code_analysis", "file_operations", 
                "web_search", "data_analysis", "coordination"
            ],
            current_tasks=0,
            max_concurrent_tasks=10,
            specialties=["Python", "JavaScript", "系统协调", "任务管理"],
            last_active=datetime.now().isoformat(),
            response_time=0.0,
            success_rate=1.0,
            error_count=0,
            uptime=0.0
        )
        
        self.agents["iflow-local"] = local_agent
        self.status_history["iflow-local"] = []
        
        logger.info("本地iFlow Agent已初始化")
    
    def register_agent(self, agent_id: str, name: str, capabilities: List[str], 
                      max_concurrent_tasks: int = 3, specialties: List[str] = None) -> bool:
        """注册新Agent"""
        try:
            agent_info = AgentInfo(
                id=agent_id,
                name=name,
                status=AgentStatus.AVAILABLE,
                capabilities=capabilities,
                current_tasks=0,
                max_concurrent_tasks=max_concurrent_tasks,
                specialties=specialties or [],
                last_active=datetime.now().isoformat(),
                response_time=0.0,
                success_rate=1.0,
                error_count=0,
                uptime=0.0
            )
            
            self.agents[agent_id] = agent_info
            self.status_history[agent_id] = []
            
            logger.info(f"Agent {name} ({agent_id}) 注册成功")
            return True
            
        except Exception as e:
            logger.error(f"注册Agent失败: {e}")
            return False
    
    def update_agent_status(self, agent_id: str, status: AgentStatus, 
                          current_tasks: int = None, response_time: float = None,
                          success_rate: float = None, error_count: int = None) -> bool:
        """更新Agent状态"""
        if agent_id not in self.agents:
            logger.warning(f"Agent {agent_id} 未注册")
            return False
        
        try:
            agent = self.agents[agent_id]
            old_status = agent.status
            
            # 更新状态
            agent.status = status
            agent.last_active = datetime.now().isoformat()
            
            if current_tasks is not None:
                agent.current_tasks = current_tasks
            if response_time is not None:
                agent.response_time = response_time
            if success_rate is not None:
                agent.success_rate = success_rate
            if error_count is not None:
                agent.error_count = error_count
            
            # 更新运行时间
            if hasattr(agent, 'start_time'):
                agent.uptime = (datetime.now() - agent.start_time).total_seconds() / 3600
            else:
                agent.start_time = datetime.now()
                agent.uptime = 0.0
            
            # 记录状态变化历史
            self._record_status_change(agent_id, old_status, status)
            
            logger.info(f"Agent {agent_id} 状态更新: {old_status.value} → {status.value}")
            return True
            
        except Exception as e:
            logger.error(f"更新Agent状态失败: {e}")
            return False
    
    def _record_status_change(self, agent_id: str, old_status: AgentStatus, new_status: AgentStatus):
        """记录状态变化"""
        if agent_id not in self.status_history:
            self.status_history[agent_id] = []
        
        change_record = {
            "timestamp": datetime.now().isoformat(),
            "old_status": old_status.value,
            "new_status": new_status.value,
            "reason": "status_update"
        }
        
        self.status_history[agent_id].append(change_record)
        
        # 保留最近100条记录
        if len(self.status_history[agent_id]) > 100:
            self.status_history[agent_id] = self.status_history[agent_id][-100:]
    
    def check_agent_health(self) -> Dict[str, Any]:
        """检查所有Agent健康状态"""
        health_status = {
            "total_agents": len(self.agents),
            "healthy_agents": 0,
            "unhealthy_agents": 0,
            "offline_agents": 0,
            "details": {}
        }
        
        current_time = datetime.now()
        
        for agent_id, agent in self.agents.items():
            try:
                # 检查最后活跃时间
                last_active = datetime.fromisoformat(agent.last_active)
                time_diff = (current_time - last_active).total_seconds()
                
                # 更新失联状态
                if time_diff > self.offline_threshold and agent.status != AgentStatus.OFFLINE:
                    self.update_agent_status(agent_id, AgentStatus.OFFLINE)
                
                # 评估健康状态
                is_healthy = (
                    agent.status in [AgentStatus.AVAILABLE, AgentStatus.BUSY] and
                    time_diff <= self.offline_threshold and
                    agent.success_rate >= 0.8 and
                    agent.response_time < 5000  # 响应时间小于5秒
                )
                
                if is_healthy:
                    health_status["healthy_agents"] += 1
                elif agent.status == AgentStatus.OFFLINE:
                    health_status["offline_agents"] += 1
                else:
                    health_status["unhealthy_agents"] += 1
                
                health_status["details"][agent_id] = {
                    "name": agent.name,
                    "status": agent.status.value,
                    "healthy": is_healthy,
                    "last_active": agent.last_active,
                    "time_since_active": f"{int(time_diff)}秒前",
                    "success_rate": f"{agent.success_rate:.1%}",
                    "response_time": f"{agent.response_time:.0f}ms"
                }
                
            except Exception as e:
                logger.error(f"检查Agent {agent_id} 健康状态失败: {e}")
                health_status["details"][agent_id] = {
                    "name": agent.name,
                    "status": "检查失败",
                    "error": str(e)
                }
        
        return health_status
    
    def get_agent_status_summary(self) -> Dict[str, Any]:
        """获取Agent状态摘要"""
        summary = {
            "总数量": len(self.agents),
            "空闲中": 0,
            "忙碌中": 0,
            "失联中": 0,
            "错误中": 0,
            "维护中": 0,
            "负载情况": {
                "总任务数": 0,
                "总容量": 0,
                "利用率": "0%"
            },
            "性能指标": {
                "平均响应时间": "0ms",
                "平均成功率": "100%",
                "错误总数": 0
            },
            "详细列表": []
        }
        
        total_tasks = 0
        total_capacity = 0
        total_response_time = 0
        total_success_rate = 0
        total_errors = 0
        
        for agent in self.agents.values():
            # 统计状态
            status_name = agent.status.value
            if status_name in summary:
                summary[status_name] += 1
            
            # 统计负载
            total_tasks += agent.current_tasks
            total_capacity += agent.max_concurrent_tasks
            
            # 统计性能
            total_response_time += agent.response_time
            total_success_rate += agent.success_rate
            total_errors += agent.error_count
            
            # 添加详细信息
            agent_detail = {
                "ID": agent.id,
                "名称": agent.name,
                "状态": agent.status.value,
                "当前任务": f"{agent.current_tasks}/{agent.max_concurrent_tasks}",
                "响应时间": f"{agent.response_time:.0f}ms",
                "成功率": f"{agent.success_rate:.1%}",
                "最后活跃": agent.last_active.split("T")[1][:5] if "T" in agent.last_active else "未知",
                "专长": ", ".join(agent.specialties[:3])  # 显示前3个专长
            }
            summary["详细列表"].append(agent_detail)
        
        # 计算汇总指标
        if total_capacity > 0:
            utilization = (total_tasks / total_capacity) * 100
            summary["负载情况"]["总任务数"] = total_tasks
            summary["负载情况"]["总容量"] = total_capacity
            summary["负载情况"]["利用率"] = f"{utilization:.1f}%"
        
        if len(self.agents) > 0:
            avg_response_time = total_response_time / len(self.agents)
            avg_success_rate = total_success_rate / len(self.agents)
            summary["性能指标"]["平均响应时间"] = f"{avg_response_time:.0f}ms"
            summary["性能指标"]["平均成功率"] = f"{avg_success_rate:.1%}"
            summary["性能指标"]["错误总数"] = total_errors
        
        return summary
    
    def get_available_agents(self, required_capabilities: List[str] = None) -> List[AgentInfo]:
        """获取可用Agent列表"""
        available_agents = []
        
        for agent in self.agents.values():
            if agent.status == AgentStatus.AVAILABLE:
                # 检查能力匹配
                if required_capabilities:
                    agent_capabilities = set(agent.capabilities)
                    required_set = set(required_capabilities)
                    if required_set.issubset(agent_capabilities):
                        available_agents.append(agent)
                else:
                    available_agents.append(agent)
        
        # 按负载和性能排序
        available_agents.sort(key=lambda x: (
            x.current_tasks / x.max_concurrent_tasks,  # 负载低的优先
            x.response_time,  # 响应快的优先
            -x.success_rate   # 成功率高的优先
        ))
        
        return available_agents
    
    def simulate_agent_workload(self, agent_id: str, task_duration: int = 60):
        """模拟Agent工作负载"""
        if agent_id not in self.agents:
            return False
        
        agent = self.agents[agent_id]
        
        # 更新为忙碌状态
        self.update_agent_status(agent_id, AgentStatus.BUSY, current_tasks=agent.current_tasks + 1)
        
        logger.info(f"Agent {agent_id} 开始执行任务，预计 {task_duration} 秒")
        
        # 这里可以启动一个后台任务来模拟工作
        # 实际实现中可以使用异步任务
        
        return True
    
    def complete_agent_task(self, agent_id: str, success: bool = True, response_time: float = 1000):
        """完成Agent任务"""
        if agent_id not in self.agents:
            return False
        
        agent = self.agents[agent_id]
        
        # 更新任务计数
        agent.current_tasks = max(0, agent.current_tasks - 1)
        
        # 更新成功率
        if success:
            # 简单的移动平均计算成功率
            agent.success_rate = (agent.success_rate * 0.9) + (1.0 * 0.1)
        else:
            agent.success_rate = (agent.success_rate * 0.9) + (0.0 * 0.1)
            agent.error_count += 1
        
        # 更新响应时间
        agent.response_time = (agent.response_time * 0.8) + (response_time * 0.2)
        
        # 更新状态
        if agent.current_tasks == 0:
            self.update_agent_status(agent_id, AgentStatus.AVAILABLE)
        
        logger.info(f"Agent {agent_id} 任务完成，成功: {success}, 响应时间: {response_time}ms")
        return True
    
    def export_status_report(self) -> str:
        """导出状态报告"""
        summary = self.get_agent_status_summary()
        
        report = f"""
=== Agent状态监控报告 ===
生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

【总体概况】
- 总数量: {summary['总数量']}
- 空闲中: {summary['空闲中']}
- 忙碌中: {summary['忙碌中']}
- 失联中: {summary['失联中']}
- 错误中: {summary['错误中']}
- 维护中: {summary['维护中']}

【负载情况】
- 总任务数: {summary['负载情况']['总任务数']}
- 总容量: {summary['负载情况']['总容量']}
- 利用率: {summary['负载情况']['利用率']}

【性能指标】
- 平均响应时间: {summary['性能指标']['平均响应时间']}
- 平均成功率: {summary['性能指标']['平均成功率']}
- 错误总数: {summary['性能指标']['错误总数']}

【详细列表】
"""
        
        for agent in summary['详细列表']:
            report += f"""
{agent['名称']} ({agent['ID']})
  状态: {agent['状态']}
  负载: {agent['当前任务']}
  响应: {agent['响应时间']}
  成功率: {agent['成功率']}
  最后活跃: {agent['最后活跃']}
  专长: {agent['专长']}
"""
        
        return report

# 全局监控实例
agent_monitor = AgentStatusMonitor()

def initialize_task_coordinator_agents(coordinator=None):
    """初始化任务协调器的Agent"""
    try:
        if coordinator is None:
            from task_coordinator import TaskCoordinator
            coordinator = TaskCoordinator()
        
        agents = coordinator.agents
        
        for agent_id, agent in agents.items():
            agent_monitor.register_agent(
                agent_id=agent_id,
                name=agent.name,
                capabilities=agent.capabilities,
                max_concurrent_tasks=agent.max_concurrent_tasks,
                specialties=agent.specialties
            )
        
        logger.info(f"已注册 {len(agents)} 个任务协调Agent")
        
    except Exception as e:
        logger.error(f"初始化任务协调Agent失败: {e}")

def get_agent_status():
    """获取Agent状态 - 供外部调用"""
    return agent_monitor.get_agent_status_summary()

def update_local_agent_status(busy: bool = False):
    """更新本地Agent状态"""
    status = AgentStatus.BUSY if busy else AgentStatus.AVAILABLE
    agent_monitor.update_agent_status("iflow-local", status)

def get_session_info():
    """获取会话信息"""
    try:
        session_count = agent_monitor._count_local_iflow_sessions()
        health_status = agent_monitor.check_agent_health()
        
        session_info = {
            "会话统计": {
                "当前iFlow会话数": session_count,
                "系统进程数": len(list(psutil.process_iter())),
                "当前会话PID": os.getpid()
            },
            "健康状态": health_status,
            "时间戳": datetime.now().isoformat()
        }
        
        return session_info
    except Exception as e:
        logger.error(f"获取会话信息失败: {e}")
        return {"error": str(e)}

def show_agent_status():
    """显示Agent状态 - 简化接口"""
    try:
        # 获取会话限制检查
        session_info = get_session_info()
        session_count = session_info["会话统计"]["当前iFlow会话数"]
        
        print(f"\n=== iFlow Agent状态监控 ===")
        print(f"当前会话数: {session_count}")
        
        if session_count > 1:
            print(f"⚠️  检测到多个iFlow会话运行")
        
        # 获取Agent状态
        status = get_agent_status()
        
        print(f"\n【Agent概况】")
        print(f"总数量: {status['总数量']}")
        print(f"空闲中: {status['空闲中']}")
        print(f"忙碌中: {status['忙碌中']}")
        print(f"失联中: {status['失联中']}")
        
        print(f"\n【负载情况】")
        print(f"总任务数: {status['负载情况']['总任务数']}")
        print(f"总容量: {status['负载情况']['总容量']}")
        print(f"利用率: {status['负载情况']['利用率']}")
        
        print(f"\n【性能指标】")
        print(f"平均响应时间: {status['性能指标']['平均响应时间']}")
        print(f"平均成功率: {status['性能指标']['平均成功率']}")
        print(f"错误总数: {status['性能指标']['错误总数']}")
        
        if status['详细列表']:
            print(f"\n【Agent详细列表】")
            for agent in status['详细列表']:
                status_icon = "✅" if agent['状态'] == "空闲中" else "🔄" if agent['状态'] == "忙碌中" else "❌"
                print(f"{status_icon} {agent['名称']} ({agent['ID']})")
                print(f"   状态: {agent['状态']}")
                print(f"   负载: {agent['当前任务']}")
                print(f"   响应: {agent['响应时间']}")
                print(f"   成功率: {agent['成功率']}")
                print(f"   专长: {agent['专长']}")
                print()
        
        return True
        
    except Exception as e:
        logger.error(f"显示Agent状态失败: {e}")
        print(f"❌ 获取Agent状态失败: {e}")
        return False

def check_session_limit():
    """检查会话限制"""
    try:
        session_count = agent_monitor._count_local_iflow_sessions()
        
        print(f"当前iFlow会话数: {session_count}")
        
        if session_count > 5:
            print("⚠️  警告: 会话数量过多，可能影响性能")
            return False
        elif session_count > 1:
            print("ℹ️  检测到多个会话运行")
            return True
        else:
            print("✅ 会话数量正常")
            return True
            
    except Exception as e:
        print(f"❌ 检查会话限制失败: {e}")
        return False

if __name__ == "__main__":
    # 初始化
    initialize_task_coordinator_agents()
    
    # 显示状态
    show_agent_status()