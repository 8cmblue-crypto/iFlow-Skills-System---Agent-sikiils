#!/usr/bin/env python3
"""
电商平台竞争策略分析
使用任务协调器分析淘宝、京东、拼多多的竞争策略差异
"""

import json
from datetime import datetime
from complete_task_coordinator import CompleteTaskCoordinator

def analyze_ecommerce_platforms():
    """分析三大电商平台竞争策略"""
    
    coordinator = CompleteTaskCoordinator()
    
    # 定义电商平台分析任务配置
    ecommerce_task_config = {
        "description": "淘宝、京东、拼多多三大电商平台竞争策略差异分析",
        "monitoring_duration": 60,  # 60秒监控时间
        "check_interval": 15,  # 15秒检查间隔
        "agents": [
            {
                "name": "平台分析师",
                "task": "分析淘宝、京东、拼多多三大电商平台的竞争策略差异",
                "focus": "平台策略对比分析",
                "command": """请分析淘宝、京东、拼多多三大电商平台的竞争策略差异，给出核心优势对比，每个平台不超过100字：

要求：
1. 分析淘宝的核心竞争策略和优势
2. 分析京东的核心竞争策略和优势  
3. 分析拼多多的核心竞争策略和优势
4. 对比三者的差异和各自定位
5. 每个平台分析控制在100字以内

请基于真实市场数据和商业模式进行分析，不要编造信息。"""
            }
        ]
    }
    
    print("🔍 开始分析三大电商平台竞争策略...")
    print(f"任务描述: {ecommerce_task_config['description']}")
    print(f"监控时长: {ecommerce_task_config['monitoring_duration']}秒")
    
    # 执行任务协调
    result = coordinator.coordinate_task(ecommerce_task_config)
    
    print(f"\n📊 分析结果:")
    print(f"状态: {result['status']}")
    
    if result["status"] == "success":
        summary = result["execution_summary"]
        print(f"任务ID: {summary['task_id']}")
        print(f"最终状态: {summary['status']}")
        print(f"执行时长: {summary['duration']}")
        
        # 尝试读取分析结果
        try:
            if "final_report" in result and "report_file" in result["final_report"]:
                report_file = result["final_report"]["report_file"]
                print(f"详细报告: {report_file}")
                
                # 读取并显示关键结果
                with open(report_file, 'r', encoding='utf-8') as f:
                    report_data = json.load(f)
                
                print(f"\n📋 分析成功!")
                return True
                
        except Exception as e:
            print(f"读取报告时出错: {e}")
            
    else:
        print(f"分析失败: {result.get('error', 'Unknown error')}")
        return False
    
    return False

if __name__ == "__main__":
    success = analyze_ecommerce_platforms()
    if success:
        print("\n✅ 电商平台竞争策略分析完成")
    else:
        print("\n❌ 分析未能完成，将直接提供基础分析")