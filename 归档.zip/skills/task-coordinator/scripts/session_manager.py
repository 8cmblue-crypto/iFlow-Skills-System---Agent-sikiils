#!/usr/bin/env python3
"""
iFlow会话管理器
负责任务分配时创建新的iFlow会话
"""

import json
import subprocess
import uuid
import time
from datetime import datetime
from typing import Dict, List, Any, Optional
from pathlib import Path
import logging

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class SessionManager:
    """iFlow会话管理器"""
    
    def __init__(self, session_storage_path: str = "/home/vinson/.iflow/sessions"):
        self.session_storage_path = Path(session_storage_path)
        self.session_storage_path.mkdir(parents=True, exist_ok=True)
        self.active_sessions = {}
        
    def create_session(self, agent_name: str, task_description: str) -> Dict[str, Any]:
        """为Agent创建新的iFlow会话"""
        try:
            # 生成会话ID
            session_id = f"agent_{agent_name}_{uuid.uuid4().hex[:8]}"
            
            # 创建会话配置
            session_config = {
                "session_id": session_id,
                "agent_name": agent_name,
                "task_description": task_description,
                "created_at": datetime.now().isoformat(),
                "status": "created",
                "commands": []
            }
            
            # 保存会话配置
            session_file = self.session_storage_path / f"{session_id}.json"
            with open(session_file, 'w', encoding='utf-8') as f:
                json.dump(session_config, f, ensure_ascii=False, indent=2)
            
            # 启动iFlow会话
            startup_result = self._start_iflow_session(session_id, task_description)
            
            if startup_result["status"] == "success":
                session_config["status"] = "active"
                session_config["pid"] = startup_result["pid"]
                
                # 更新会话文件
                with open(session_file, 'w', encoding='utf-8') as f:
                    json.dump(session_config, f, ensure_ascii=False, indent=2)
                
                # 记录活跃会话
                self.active_sessions[session_id] = session_config
                
                logger.info(f"✅ 成功创建会话: {session_id} for Agent: {agent_name}")
                
                return {
                    "status": "success",
                    "session_id": session_id,
                    "agent_name": agent_name,
                    "pid": startup_result["pid"],
                    "created_at": session_config["created_at"]
                }
            else:
                # 启动失败，删除会话文件
                session_file.unlink(missing_ok=True)
                return startup_result
                
        except Exception as e:
            logger.error(f"❌ 创建会话失败: {e}")
            return {
                "status": "error",
                "error": str(e),
                "timestamp": datetime.now().isoformat()
            }
    
    def _start_iflow_session(self, session_id: str, task_description: str) -> Dict[str, Any]:
        """启动iFlow会话"""
        try:
            # iFlow实际用法：使用--resume来启动/恢复会话
            # 如果会话不存在，iFlow会创建新的会话
            command = f'iflow --resume {session_id} -p "{task_description}"'
            
            logger.info(f"🚀 启动iFlow会话: {command}")
            
            # 在后台启动iFlow会话
            process = subprocess.Popen(
                command,
                shell=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            
            # 等待一小段时间确保进程启动
            time.sleep(2)
            
            # 检查进程是否还在运行
            if process.poll() is None:
                return {
                    "status": "success",
                    "session_id": session_id,
                    "pid": process.pid,
                    "command": command
                }
            else:
                stdout, stderr = process.communicate()
                return {
                    "status": "error",
                    "error": f"iFlow进程启动失败: {stderr}",
                    "stdout": stdout,
                    "command": command
                }
                
        except Exception as e:
            logger.error(f"❌ 启动iFlow会话失败: {e}")
            return {
                "status": "error",
                "error": str(e)
            }
    
    def assign_task_to_session(self, session_id: str, task_command: str) -> Dict[str, Any]:
        """向会话分配任务"""
        try:
            if session_id not in self.active_sessions:
                return {
                    "status": "error",
                    "error": f"会话不存在: {session_id}"
                }
            
            # 构建任务分配命令，增加超时时间
            command = f'timeout 1800s iflow --resume {session_id} -p "{task_command}"'
            
            logger.info(f"📤 向会话分配任务: {session_id} -> {task_command}")
            
            # 执行任务分配
            result = subprocess.run(
                command,
                shell=True,
                capture_output=True,
                text=True
            )
            
            # 更新会话配置
            session_config = self.active_sessions[session_id]
            session_config["commands"].append({
                "command": task_command,
                "timestamp": datetime.now().isoformat(),
                "status": "success" if result.returncode == 0 else "error"
            })
            
            # 保存更新的会话配置
            session_file = self.session_storage_path / f"{session_id}.json"
            with open(session_file, 'w', encoding='utf-8') as f:
                json.dump(session_config, f, ensure_ascii=False, indent=2)
            
            return {
                "status": "success" if result.returncode == 0 else "error",
                "session_id": session_id,
                "command": task_command,
                "stdout": result.stdout,
                "stderr": result.stderr,
                "returncode": result.returncode
            }
            
        except subprocess.TimeoutExpired:
            return {
                "status": "timeout",
                "error": "任务分配超时",
                "session_id": session_id
            }
        except Exception as e:
            return {
                "status": "error",
                "error": str(e),
                "session_id": session_id
            }
    
    def get_session_status(self, session_id: str) -> Dict[str, Any]:
        """获取会话状态"""
        try:
            session_file = self.session_storage_path / f"{session_id}.json"
            
            if not session_file.exists():
                return {
                    "status": "error",
                    "error": f"会话文件不存在: {session_id}"
                }
            
            with open(session_file, 'r', encoding='utf-8') as f:
                session_config = json.load(f)
            
            # 检查进程是否还在运行
            if "pid" in session_config:
                try:
                    import psutil
                    process = psutil.Process(session_config["pid"])
                    if process.is_running():
                        session_config["process_status"] = "running"
                    else:
                        session_config["process_status"] = "stopped"
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    session_config["process_status"] = "unknown"
            
            return {
                "status": "success",
                "session": session_config
            }
            
        except Exception as e:
            return {
                "status": "error",
                "error": str(e)
            }
    
    def list_active_sessions(self) -> Dict[str, Any]:
        """列出所有活跃会话"""
        try:
            sessions = []
            
            for session_file in self.session_storage_path.glob("*.json"):
                try:
                    with open(session_file, 'r', encoding='utf-8') as f:
                        session_config = json.load(f)
                    
                    # 检查进程状态
                    if "pid" in session_config:
                        try:
                            import psutil
                            process = psutil.Process(session_config["pid"])
                            session_config["process_status"] = "running" if process.is_running() else "stopped"
                        except (psutil.NoSuchProcess, psutil.AccessDenied):
                            session_config["process_status"] = "unknown"
                    
                    sessions.append(session_config)
                    
                except Exception as e:
                    logger.warning(f"读取会话文件失败 {session_file}: {e}")
            
            return {
                "status": "success",
                "sessions": sessions,
                "total_count": len(sessions)
            }
            
        except Exception as e:
            return {
                "status": "error",
                "error": str(e)
            }
    
    def terminate_session(self, session_id: str) -> Dict[str, Any]:
        """终止会话"""
        try:
            if session_id not in self.active_sessions:
                return {
                    "status": "error",
                    "error": f"会话不存在: {session_id}"
                }
            
            session_config = self.active_sessions[session_id]
            
            # 终止进程
            if "pid" in session_config:
                try:
                    import psutil
                    process = psutil.Process(session_config["pid"])
                    process.terminate()
                    
                    # 等待进程结束
                    try:
                        process.wait(timeout=10)
                    except psutil.TimeoutExpired:
                        process.kill()
                    
                    logger.info(f"✅ 终止会话进程: {session_id} (PID: {session_config['pid']})")
                    
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    logger.warning(f"进程已不存在或无权限访问: {session_config['pid']}")
            
            # 更新会话状态
            session_config["status"] = "terminated"
            session_config["terminated_at"] = datetime.now().isoformat()
            
            # 保存更新的会话配置
            session_file = self.session_storage_path / f"{session_id}.json"
            with open(session_file, 'w', encoding='utf-8') as f:
                json.dump(session_config, f, ensure_ascii=False, indent=2)
            
            # 从活跃会话中移除
            del self.active_sessions[session_id]
            
            return {
                "status": "success",
                "session_id": session_id,
                "terminated_at": session_config["terminated_at"]
            }
            
        except Exception as e:
            return {
                "status": "error",
                "error": str(e),
                "session_id": session_id
            }

def main():
    """测试会话管理器"""
    manager = SessionManager()
    
    print("🚀 iFlow会话管理器测试")
    print("=" * 40)
    
    # 测试创建会话
    print("\n📝 测试创建会话...")
    result = manager.create_session("小明", "分析备得福竞品乌江榨菜")
    print(f"创建结果: {result}")
    
    if result["status"] == "success":
        session_id = result["session_id"]
        
        # 测试分配任务
        print(f"\n📤 测试向会话分配任务: {session_id}")
        task_result = manager.assign_task_to_session(session_id, "请分析乌江榨菜的市场策略")
        print(f"任务分配结果: {task_result}")
        
        # 测试获取会话状态
        print(f"\n📊 测试获取会话状态: {session_id}")
        status_result = manager.get_session_status(session_id)
        print(f"会话状态: {status_result}")
        
        # 测试列出所有会话
        print(f"\n📋 测试列出所有会话:")
        list_result = manager.list_active_sessions()
        print(f"会话列表: {list_result}")
        
        # 测试终止会话
        print(f"\n🛑 测试终止会话: {session_id}")
        terminate_result = manager.terminate_session(session_id)
        print(f"终止结果: {terminate_result}")

if __name__ == "__main__":
    main()