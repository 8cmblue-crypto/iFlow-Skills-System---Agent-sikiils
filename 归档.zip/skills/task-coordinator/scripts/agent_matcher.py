#!/usr/bin/env python3
"""
Agent匹配器
老大，这个模块负责将子任务智能分配给最合适的Agent
"""

import json
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
import logging

logger = logging.getLogger(__name__)

@dataclass
class Assignment:
    """任务分配数据结构"""
    task_id: str
    agent_id: str
    assigned_at: str
    estimated_completion: str
    priority: int
    confidence_score: float

class AgentMatcher:
    """Agent匹配器"""
    
    def __init__(self, agents: Dict[str, Any]):
        self.agents = agents
        self.matching_weights = {
            "capability_match": 0.4,      # 能力匹配权重
            "availability": 0.3,          # 可用性权重
            "specialty_match": 0.2,       # 专长匹配权重
            "load_balance": 0.1           # 负载均衡权重
        }
    
    def match_and_assign(self, subtasks: List[Dict], available_agents: Dict[str, Any]) -> List[Dict]:
        """匹配并分配任务给Agent"""
        logger.info(f"开始为 {len(subtasks)} 个子任务匹配Agent")
        
        assignments = []
        
        # 按优先级排序子任务
        sorted_subtasks = sorted(subtasks, key=lambda x: x.get("priority", 0), reverse=True)
        
        for subtask in sorted_subtasks:
            best_agent = self._find_best_agent(subtask, available_agents)
            
            if best_agent:
                assignment = self._create_assignment(subtask, best_agent)
                assignments.append(assignment)
                
                # 更新Agent负载
                agent_id = getattr(best_agent, 'id', None)
                if agent_id:
                    self._update_agent_load(agent_id, available_agents)
                
                agent_name = getattr(best_agent, 'name', str(best_agent))
                logger.info(f"子任务 {subtask['name']} 分配给Agent {agent_name}")
            else:
                logger.warning(f"无法为子任务 {subtask['name']} 找到合适的Agent")
        
        logger.info(f"任务分配完成，成功分配 {len(assignments)} 个子任务")
        return assignments
    
    def _find_best_agent(self, subtask: Dict, available_agents: Dict[str, Any]) -> Optional[Any]:
        """找到最适合的Agent"""
        best_agent = None
        best_score = 0.0
        best_agent_id = None
        
        for agent_id, agent in available_agents.items():
            # 检查Agent是否可用
            if not self._is_agent_available(agent):
                continue
            
            # 计算匹配分数
            score = self._calculate_match_score(subtask, agent)
            
            if score > best_score:
                best_score = score
                best_agent = agent
                best_agent_id = agent_id
        
        # 设置最低匹配阈值
        if best_score < 0.3:
            return None
        
        # 存储agent_id在agent对象中
        if best_agent and best_agent_id:
            if not hasattr(best_agent, 'id'):
                best_agent.id = best_agent_id
        
        return best_agent
    
    def _is_agent_available(self, agent: Any) -> bool:
        """检查Agent是否可用"""
        # 检查Agent状态
        if hasattr(agent, 'status') and agent.status != "available":
            return False
        
        # 检查负载
        current_tasks = getattr(agent, 'current_tasks', 0)
        max_tasks = getattr(agent, 'max_concurrent_tasks', 3)
        
        return current_tasks < max_tasks
    
    def _calculate_match_score(self, subtask: Dict, agent: Dict[str, Any]) -> float:
        """计算Agent与子任务的匹配分数"""
        scores = {}
        
        # 1. 能力匹配分数
        scores["capability_match"] = self._calculate_capability_match(subtask, agent)
        
        # 2. 可用性分数
        scores["availability"] = self._calculate_availability_score(agent)
        
        # 3. 专长匹配分数
        scores["specialty_match"] = self._calculate_specialty_match(subtask, agent)
        
        # 4. 负载均衡分数
        scores["load_balance"] = self._calculate_load_balance_score(agent)
        
        # 计算加权总分
        total_score = sum(
            scores[factor] * self.matching_weights[factor] 
            for factor in self.matching_weights
        )
        
        return total_score
    
    def _calculate_capability_match(self, subtask: Dict, agent: Any) -> float:
        """计算能力匹配分数"""
        required_capabilities = set(subtask.get("required_capabilities", []))
        agent_capabilities = set(getattr(agent, 'capabilities', []))
        
        if not required_capabilities:
            return 0.5  # 如果没有特定要求，给中等分数
        
        # 计算匹配的能力数量
        matched_capabilities = required_capabilities & agent_capabilities
        
        # 完全匹配给1.0分，部分匹配按比例给分
        match_ratio = len(matched_capabilities) / len(required_capabilities)
        
        # 如果有完全匹配的能力，额外加分
        if matched_capabilities == required_capabilities:
            return 1.0
        
        return match_ratio
    
    def _calculate_availability_score(self, agent: Any) -> float:
        """计算可用性分数"""
        current_tasks = getattr(agent, 'current_tasks', 0)
        max_tasks = getattr(agent, 'max_concurrent_tasks', 3)
        
        if current_tasks == 0:
            return 1.0  # 完全空闲
        
        # 负载越低分数越高
        availability_ratio = 1.0 - (current_tasks / max_tasks)
        return availability_ratio
    
    def _calculate_specialty_match(self, subtask: Dict, agent: Any) -> float:
        """计算专长匹配分数"""
        agent_specialties = getattr(agent, 'specialties', [])
        if not agent_specialties:
            return 0.3  # 没有专长信息，给基础分数
        
        # 从子任务描述中提取关键词
        task_keywords = self._extract_keywords_from_task(subtask)
        
        # 计算专长匹配度
        specialty_matches = 0
        for specialty in agent_specialties:
            if specialty.lower() in task_keywords:
                specialty_matches += 1
        
        if specialty_matches == 0:
            return 0.2
        
        # 匹配的专长越多分数越高
        return min(1.0, specialty_matches / len(agent_specialties) + 0.3)
    
    def _extract_keywords_from_task(self, subtask: Dict) -> set:
        """从子任务中提取关键词"""
        text = f"{subtask.get('name', '')} {subtask.get('description', '')}".lower()
        
        # 常见的技术关键词
        tech_keywords = {
            "python", "javascript", "typescript", "java", "go", "rust", "c++",
            "react", "vue", "angular", "node", "express", "django", "flask",
            "docker", "kubernetes", "aws", "azure", "gcp",
            "mysql", "postgresql", "mongodb", "redis",
            "api", "rest", "graphql", "microservices",
            "testing", "security", "performance", "optimization",
            "documentation", "markdown", "json", "yaml"
        }
        
        found_keywords = set()
        for keyword in tech_keywords:
            if keyword in text:
                found_keywords.add(keyword)
        
        return found_keywords
    
    def _calculate_load_balance_score(self, agent: Any) -> float:
        """计算负载均衡分数"""
        current_tasks = getattr(agent, 'current_tasks', 0)
        max_tasks = getattr(agent, 'max_concurrent_tasks', 3)
        
        # 负载越均衡分数越高
        if current_tasks == 0:
            return 0.8  # 空闲Agent适合分配新任务
        elif current_tasks < max_tasks * 0.5:
            return 1.0  # 轻负载最佳
        elif current_tasks < max_tasks * 0.8:
            return 0.6  # 中等负载
        else:
            return 0.2  # 高负载避免分配
    
    def _create_assignment(self, subtask: Dict, agent: Any) -> Dict:
        """创建任务分配记录"""
        from datetime import datetime
        
        return {
            "task_id": subtask["id"],
            "agent_id": getattr(agent, 'id', agent.id),
            "agent_name": getattr(agent, 'name', str(agent)),
            "task_name": subtask["name"],
            "assigned_at": datetime.now().isoformat(),
            "estimated_completion": subtask.get("estimated_time", 300),
            "priority": subtask.get("priority", 5),
            "confidence_score": self._calculate_match_score(subtask, agent),
            "status": "assigned"
        }
    
    def _update_agent_load(self, agent_id: str, available_agents: Dict[str, Any]):
        """更新Agent负载"""
        if agent_id in available_agents:
            agent = available_agents[agent_id]
            agent.current_tasks += 1
            
            # 如果达到最大负载，标记为忙碌
            max_tasks = getattr(agent, 'max_concurrent_tasks', 3)
            current_tasks = getattr(agent, 'current_tasks', 0)
            
            if current_tasks >= max_tasks:
                agent.status = "busy"
    
    def get_agent_performance_stats(self, agent_id: str) -> Dict[str, Any]:
        """获取Agent性能统计"""
        if agent_id not in self.agents:
            return {}
        
        agent = self.agents[agent_id]
        
        return {
            "agent_id": agent_id,
            "name": agent.get("name", "Unknown"),
            "capabilities": agent.get("capabilities", []),
            "specialties": agent.get("specialties", []),
            "current_load": agent.get("current_tasks", 0),
            "max_capacity": agent.get("max_concurrent_tasks", 3),
            "utilization_rate": agent.get("current_tasks", 0) / agent.get("max_concurrent_tasks", 3),
            "status": agent.get("status", "unknown")
        }
    
    def rebalance_tasks(self, current_assignments: List[Dict], available_agents: Dict[str, Any]) -> List[Dict]:
        """重新平衡任务分配"""
        logger.info("开始重新平衡任务分配")
        
        # 重置所有Agent的负载
        for agent in available_agents.values():
            agent.current_tasks = 0
            agent.status = "available"
        
        # 重新分配所有任务
        rebalanced_assignments = []
        
        # 提取子任务信息
        subtasks = []
        for assignment in current_assignments:
            subtask = {
                "id": assignment["task_id"],
                "name": assignment["task_name"],
                "required_capabilities": [],  # 这里需要从原任务获取
                "priority": assignment["priority"],
                "estimated_time": assignment["estimated_completion"]
            }
            subtasks.append(subtask)
        
        # 重新匹配
        rebalanced_assignments = self.match_and_assign(subtasks, available_agents)
        
        logger.info(f"任务重新平衡完成，分配了 {len(rebalanced_assignments)} 个任务")
        return rebalanced_assignments