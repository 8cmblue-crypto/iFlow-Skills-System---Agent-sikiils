#!/usr/bin/env python3
"""
Agent状态查看器 - 简化版
老大，这是一个专门用于查看Agent状态的独立工具
"""

import json
import os
import psutil
from datetime import datetime
from typing import Dict, Any

def count_iflow_sessions() -> int:
    """统计活跃iFlow会话数量（只算独立终端会话）"""
    try:
        terminal_sessions = set()
        
        # 查找所有包含"iflow"的活跃进程
        for proc in psutil.process_iter(['pid', 'name', 'cmdline', 'status', 'terminal']):
            try:
                # 统计运行中和睡眠中的进程
                if proc.info['status'] not in [psutil.STATUS_RUNNING, psutil.STATUS_SLEEPING]:
                    continue
                    
                cmdline = proc.info.get('cmdline', [])
                if not cmdline:
                    continue
                
                # 检查是否是iFlow相关进程
                cmdline_str = ' '.join(cmdline).lower()
                
                # 排除系统命令、npm子进程等
                if any(keyword in cmdline_str for keyword in ['grep', 'ps', 'awk', 'sed', 'npm exec']):
                    continue
                
                # 只匹配主要的iFlow进程
                if ('iflow' in cmdline_str and 
                    'node' in cmdline_str and 
                    'bundle/iflow.js' not in cmdline_str):
                    
                    # 使用终端作为会话标识
                    terminal = proc.info.get('terminal')
                    if terminal:
                        terminal_sessions.add(terminal)
                    else:
                        # 如果没有终端信息，使用进程组ID
                        try:
                            pgid = os.getpgid(proc.info['pid'])
                            terminal_sessions.add(f"pgid_{pgid}")
                        except:
                            terminal_sessions.add(f"pid_{proc.info['pid']}")
                    
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        
        return len(terminal_sessions)
    except Exception as e:
        print(f"❌ 统计iFlow会话失败: {e}")
        return 1  # 默认返回1，表示当前会话

def check_agent_capacity():
    """检查Agent容量状态"""
    # 模拟检查当前运行的Agent任务
    running_agents = 1  # 当前运行的Agent数量
    max_agents = 8      # 每个主机最多3个并发Agent
    
    if running_agents == 0:
        status = "🔴 无Agent运行"
        capacity_status = "空闲"
    elif running_agents == 1:
        status = f"🟡 {running_agents}/{max_agents} Agent运行中"
        capacity_status = "可扩展"
    elif running_agents <= max_agents:
        status = f"🟢 {running_agents}/{max_agents} Agent运行中"
        capacity_status = "正常"
    else:
        status = f"🔴 {running_agents}/{max_agents} Agent超载运行"
        capacity_status = "超载"
    
    return {
        "running_agents": running_agents,
        "max_agents": max_agents,
        "status": status,
        "capacity": capacity_status
    }

def show_agent_summary():
    """显示Agent概览信息"""
    try:
        # 简化的人名化Agent，都是通用能力，有自己的记忆和习惯
        agents = [
            {"name": "小明", "status": "空闲中", "response": "0ms", "habit": "喜欢简洁回复"},
            {"name": "小白", "status": "空闲中", "response": "0ms", "habit": "注重细节"},
            {"name": "小陈", "status": "空闲中", "response": "0ms", "habit": "逻辑清晰"},
            {"name": "小李", "status": "空闲中", "response": "0ms", "habit": "快速响应"},
            {"name": "小张", "status": "空闲中", "response": "0ms", "habit": "善于总结"},
            {"name": "小王", "status": "空闲中", "response": "0ms", "habit": "条理性强"},
            {"name": "小刘", "status": "空闲中", "response": "0ms", "habit": "言简意赅"},
            {"name": "小赵", "status": "空闲中", "response": "0ms", "habit": "专注高效"}
        ]
        
        total_agents = len(agents)
        available_agents = sum(1 for agent in agents if agent['status'] == '空闲中')
        busy_agents = sum(1 for agent in agents if agent['status'] == '忙碌中')
        
        print(f"\n=== Agent状态概览 ===")
        print(f"总Agent数: {total_agents}")
        print(f"空闲中: {available_agents}")
        print(f"忙碌中: {busy_agents}")
        print(f"可用率: {(available_agents/total_agents*100):.1f}%")
        
        return agents
        
    except Exception as e:
        print(f"❌ 获取Agent概览失败: {e}")
        return []

def show_agent_status_simple():
    """显示简化的Agent状态"""
    try:
        # 获取Agent概览
        agents = show_agent_summary()
        
        if not agents:
            return False
        
        print(f"\n【Agent详细状态】")
        for agent in agents:
            status_icon = "✅" if agent['status'] == "空闲中" else "🔄" if agent['status'] == "忙碌中" else "❌"
            print(f"{status_icon} {agent['name']}")
            print(f"   状态: {agent['status']}")
            print(f"   特点: {agent['habit']}")
            print()
        
        return True
        
    except Exception as e:
        print(f"❌ 显示Agent状态失败: {e}")
        return False

def main():
    """主函数"""
    print("🔍 iFlow Agent状态查看器")
    print(f"生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 50)
    print()
    
    # 检查Agent容量状态
    agent_capacity = check_agent_capacity()
    print("【Agent容量检查】")
    print(f"🤖 {agent_capacity['status']}")
    print(f"📋 容量状态: {agent_capacity['capacity']}")
    print(f"⚙️  主机容量: 8个并发Agent")
    print()
    
    # 显示Agent状态
    show_agent_status_simple()
    
    print("=" * 50)
    print("📝 Agent规则: 每个主机最多8个并发Agent任务")
    print("🧠 每个Agent都有自己的记忆和使用习惯")
    print("💬 回复言简意赅，专注高效完成任务")
    print("🔄 可根据任务习惯和个人偏好选择Agent")
if __name__ == "__main__":
    main()