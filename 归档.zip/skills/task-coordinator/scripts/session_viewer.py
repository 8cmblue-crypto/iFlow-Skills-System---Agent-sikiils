#!/usr/bin/env python3
"""
会话查看技能 - 查看和恢复老会话
"""

import json
import os
import subprocess
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Any

class SessionViewer:
    """会话查看器"""
    
    def __init__(self):
        self.session_path = Path("/home/vinson/.iflow/sessions")
        
    def list_all_sessions(self) -> Dict[str, Any]:
        """列出所有会话"""
        try:
            sessions = []
            for session_file in self.session_path.glob("*.json"):
                with open(session_file, 'r', encoding='utf-8') as f:
                    session_data = json.load(f)
                    
                sessions.append({
                    "session_id": session_data.get("session_id", "unknown"),
                    "agent_name": session_data.get("agent_name", "unknown"),
                    "task_description": session_data.get("task_description", "unknown"),
                    "status": session_data.get("status", "unknown"),
                    "created_at": session_data.get("created_at", "unknown"),
                    "commands_count": len(session_data.get("commands", [])),
                    "file_size": os.path.getsize(session_file),
                    "file_path": str(session_file)
                })
            
            # 按创建时间排序
            sessions.sort(key=lambda x: x["created_at"], reverse=True)
            
            return {
                "status": "success",
                "total_sessions": len(sessions),
                "sessions": sessions
            }
            
        except Exception as e:
            return {
                "status": "error",
                "error": str(e),
                "total_sessions": 0,
                "sessions": []
            }
    
    def get_session_details(self, session_id: str) -> Dict[str, Any]:
        """获取指定会话的详细信息"""
        try:
            session_file = self.session_path / f"{session_id}.json"
            if not session_file.exists():
                return {
                    "status": "error",
                    "error": f"会话文件不存在: {session_id}.json"
                }
            
            with open(session_file, 'r', encoding='utf-8') as f:
                session_data = json.load(f)
            
            return {
                "status": "success",
                "session_data": session_data,
                "file_path": str(session_file)
            }
            
        except Exception as e:
            return {
                "status": "error",
                "error": str(e)
            }
    
    def resume_session(self, session_id: str) -> Dict[str, Any]:
        """恢复指定会话"""
        try:
            # 首先检查会话是否存在
            session_details = self.get_session_details(session_id)
            if session_details["status"] != "success":
                return session_details
            
            session_data = session_details["session_data"]
            agent_name = session_data.get("agent_name", "Agent")
            
            print(f"🔄 恢复会话: {session_id} ({agent_name})")
            
            # 使用iflow恢复会话
            command = f"iflow --resume {session_id}"
            result = subprocess.run(
                command,
                shell=True,
                capture_output=True,
                text=True
            )
            
            return {
                "status": "success" if result.returncode == 0 else "error",
                "command": command,
                "stdout": result.stdout,
                "stderr": result.stderr,
                "returncode": result.returncode,
                "session_id": session_id,
                "agent_name": agent_name
            }
            
        except Exception as e:
            return {
                "status": "error",
                "error": str(e)
            }
    
    def send_command_to_session(self, session_id: str, command: str) -> Dict[str, Any]:
        """向指定会话发送命令"""
        try:
            # 检查会话是否存在
            session_details = self.get_session_details(session_id)
            if session_details["status"] != "success":
                return session_details
            
            print(f"📤 向会话 {session_id} 发送命令: {command}")
            
            # 使用iflow向会话发送命令
            full_command = f'timeout 1800s iflow --resume {session_id} -p "{command}"'
            result = subprocess.run(
                full_command,
                shell=True,
                capture_output=True,
                text=True
            )
            
            return {
                "status": "success" if result.returncode == 0 else "error",
                "command": command,
                "session_id": session_id,
                "stdout": result.stdout,
                "stderr": result.stderr,
                "returncode": result.returncode,
                "timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            return {
                "status": "error",
                "error": str(e)
            }
    
    def get_active_sessions(self) -> Dict[str, Any]:
        """获取活跃会话（有进程的）"""
        try:
            # 查找iflow进程
            result = subprocess.run(
                "ps aux | grep iflow | grep -v grep",
                shell=True,
                capture_output=True,
                text=True
            )
            
            active_sessions = []
            if result.stdout:
                lines = result.stdout.strip().split('\n')
                for line in lines:
                    if 'iflow' in line and '--resume' in line:
                        parts = line.split()
                        if len(parts) >= 2:
                            pid = parts[1]
                            command_line = ' '.join(parts)
                            # 更安全的session_id提取
                            try:
                                session_part = command_line.split('--resume')[1].strip().split()[0]
                                active_sessions.append({
                                    "pid": pid,
                                    "session_id": session_part,
                                    "command_line": command_line
                                })
                            except (IndexError, AttributeError):
                                continue
            
            return {
                "status": "success",
                "active_sessions": active_sessions,
                "total_active": len(active_sessions)
            }
            
        except Exception as e:
            return {
                "status": "error",
                "error": str(e),
                "active_sessions": [],
                "total_active": 0
            }
    
    def cleanup_old_sessions(self, days: int = 7) -> Dict[str, Any]:
        """清理旧会话文件"""
        try:
            import time
            cutoff_time = time.time() - (days * 24 * 60 * 60)
            cleaned_files = []
            
            for session_file in self.session_path.glob("*.json"):
                file_time = os.path.getmtime(session_file)
                if file_time < cutoff_time:
                    os.remove(session_file)
                    cleaned_files.append(str(session_file))
            
            return {
                "status": "success",
                "cleaned_files": cleaned_files,
                "cleaned_count": len(cleaned_files),
                "days_threshold": days
            }
            
        except Exception as e:
            return {
                "status": "error",
                "error": str(e),
                "cleaned_files": [],
                "cleaned_count": 0
            }

def main():
    """主函数"""
    import sys
    
    viewer = SessionViewer()
    
    if len(sys.argv) < 2:
        print("🚀 会话查看技能")
        print("=" * 40)
        print("用法:")
        print("  python3 session_viewer.py list                    # 列出所有会话")
        print("  python3 session_viewer.py details <session_id>    # 查看会话详情")
        print("  python3 session_viewer.py resume <session_id>     # 恢复会话")
        print("  python3 session_viewer.py command <session_id> <command>  # 向会话发送命令")
        print("  python3 session_viewer.py active                  # 查看活跃会话")
        print("  python3 session_viewer.py cleanup [days]          # 清理旧会话")
        return
    
    command = sys.argv[1]
    
    if command == "list":
        print("📋 所有会话列表:")
        result = viewer.list_all_sessions()
        if result["status"] == "success":
            print(f"总计: {result['total_sessions']} 个会话")
            print("-" * 80)
            for i, session in enumerate(result["sessions"], 1):
                print(f"{i:2d}. {session['session_id']}")
                print(f"    Agent: {session['agent_name']}")
                print(f"    任务: {session['task_description']}")
                print(f"    状态: {session['status']}")
                print(f"    创建: {session['created_at']}")
                print(f"    命令数: {session['commands_count']}")
                print()
        else:
            print(f"❌ 错误: {result['error']}")
    
    elif command == "details" and len(sys.argv) >= 3:
        session_id = sys.argv[2]
        print(f"📄 会话详情: {session_id}")
        result = viewer.get_session_details(session_id)
        if result["status"] == "success":
            session_data = result["session_data"]
            print(f"会话ID: {session_data.get('session_id')}")
            print(f"Agent名称: {session_data.get('agent_name')}")
            print(f"任务描述: {session_data.get('task_description')}")
            print(f"状态: {session_data.get('status')}")
            print(f"创建时间: {session_data.get('created_at')}")
            print(f"进程ID: {session_data.get('pid', 'N/A')}")
            
            commands = session_data.get('commands', [])
            print(f"\n命令历史 ({len(commands)} 个):")
            for i, cmd in enumerate(commands, 1):
                print(f"  {i}. {cmd.get('command', 'N/A')}")
                print(f"     时间: {cmd.get('timestamp', 'N/A')}")
                print(f"     状态: {cmd.get('status', 'N/A')}")
        else:
            print(f"❌ 错误: {result['error']}")
    
    elif command == "resume" and len(sys.argv) >= 3:
        session_id = sys.argv[2]
        result = viewer.resume_session(session_id)
        if result["status"] == "success":
            print(f"✅ 会话 {session_id} 恢复成功")
            if result["stdout"]:
                print("输出:", result["stdout"])
        else:
            print(f"❌ 恢复失败: {result.get('error', 'Unknown error')}")
    
    elif command == "command" and len(sys.argv) >= 4:
        session_id = sys.argv[2]
        command_text = " ".join(sys.argv[3:])
        result = viewer.send_command_to_session(session_id, command_text)
        if result["status"] == "success":
            print(f"✅ 命令发送成功到会话 {session_id}")
            if result["stdout"]:
                print("输出:", result["stdout"])
        else:
            print(f"❌ 命令发送失败: {result.get('error', 'Unknown error')}")
    
    elif command == "active":
        print("🟢 活跃会话:")
        result = viewer.get_active_sessions()
        if result["status"] == "success":
            print(f"总计: {result['total_active']} 个活跃会话")
            for session in result["active_sessions"]:
                print(f"  PID: {session['pid']}, 会话: {session['session_id']}")
        else:
            print(f"❌ 错误: {result['error']}")
    
    elif command == "cleanup":
        days = int(sys.argv[2]) if len(sys.argv) >= 3 else 7
        print(f"🧹 清理 {days} 天前的旧会话...")
        result = viewer.cleanup_old_sessions(days)
        if result["status"] == "success":
            print(f"✅ 清理完成，删除了 {result['cleaned_count']} 个文件")
        else:
            print(f"❌ 清理失败: {result['error']}")
    
    else:
        print("❌ 未知命令或参数不足")

if __name__ == "__main__":
    main()