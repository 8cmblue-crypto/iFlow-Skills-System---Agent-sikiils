#!/usr/bin/env python3
"""
备得福竞品分析任务测试脚本
老大，这是专门用于测试备得福竞品分析任务的轻量级测试脚本
快速验证任务协调器的核心功能和协同工作流程
"""

import sys
import os
import json
import time
import logging
from datetime import datetime
from pathlib import Path

# 添加技能路径
sys.path.append('/vol1/1000/iflow/skills/task-coordinator/scripts')

from task_coordinator import TaskCoordinator

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('/vol1/1000/iflow/skills/task-coordinator/logs/beidefu_task_test.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class BeiDefuTaskTest:
    """备得福竞品分析任务测试类"""
    
    def __init__(self):
        self.coordinator = TaskCoordinator()
        self.test_task_id = None
        self.test_results = {}
        
    def setup_directories(self):
        """设置必要的目录"""
        try:
            directories = [
                '/vol1/1000/iflow/skills/task-coordinator/logs',
                '/vol1/1000/iflow/skills/task-coordinator/results',
                '/vol1/1000/iflow/sync_workspace',
                '/vol1/1000/iflow/skills/task-coordinator/tasks'
            ]
            
            for directory in directories:
                Path(directory).mkdir(parents=True, exist_ok=True)
            
            logger.info("目录设置完成")
            return True
        except Exception as e:
            logger.error(f"设置目录失败: {e}")
            return False
    
    def create_task_config(self):
        """创建备得福竞品分析任务配置"""
        try:
            task_config = {
                "task_name": "备得福榨菜品牌竞品分析",
                "task_description": "对备得福榨菜品牌进行全面竞品分析，包括乌江榨菜、鱼泉榨菜、铜钱桥榨菜、六必居、吉香居、川南榨菜、乡下妹、钱江榨菜、聚味特等主要竞品的市场定位、产品策略、价格策略、渠道策略、品牌策略等方面进行深入分析，为备得福品牌发展提供策略建议。",
                "task_priority": "high",
                "task_type": "collaborative_analysis",
                "estimated_duration": 3600,
                "created_at": datetime.now().isoformat(),
                "agents": [
                    {
                        "agent_name": "小明",
                        "agent_type": "market_strategy_agent",
                        "focus_area": "市场策略分析",
                        "assigned_competitors": ["乌江榨菜", "鱼泉榨菜"],
                        "special_instructions": "重点关注市场领导者的成功策略和备得福的差异化机会",
                        "analysis_dimensions": ["市场份额", "品牌影响力", "消费者认知", "竞争优势"]
                    },
                    {
                        "agent_name": "小白",
                        "agent_type": "international_market_agent",
                        "focus_area": "国际市场分析",
                        "assigned_competitors": ["鱼泉榨菜", "吉香居"],
                        "special_instructions": "分析出口策略和国际市场拓展经验",
                        "analysis_dimensions": ["出口数据", "国际市场表现", "海外渠道", "品牌国际化"]
                    },
                    {
                        "agent_name": "小陈",
                        "agent_type": "regional_competition_agent",
                        "focus_area": "区域竞争分析",
                        "assigned_competitors": ["铜钱桥榨菜", "钱江榨菜"],
                        "special_instructions": "重点关注浙江及周边区域的竞争格局",
                        "analysis_dimensions": ["区域市场占有率", "本地渠道优势", "区域品牌认知", "地方政策影响"]
                    },
                    {
                        "agent_name": "小李",
                        "agent_type": "product_differentiation_agent",
                        "focus_area": "产品差异化分析",
                        "assigned_competitors": ["六必居", "乡下妹"],
                        "special_instructions": "分析产品特色和差异化策略",
                        "analysis_dimensions": ["产品特色", "包装设计", "品质定位", "创新点"]
                    },
                    {
                        "agent_name": "小张",
                        "agent_type": "brand_positioning_agent",
                        "focus_area": "品牌定位分析",
                        "assigned_competitors": ["乌江榨菜", "六必居"],
                        "special_instructions": "分析品牌定位策略和传播效果",
                        "analysis_dimensions": ["品牌定位", "传播策略", "品牌价值", "消费者忠诚度"]
                    },
                    {
                        "agent_name": "小王",
                        "agent_type": "pricing_strategy_agent",
                        "focus_area": "价格策略分析",
                        "assigned_competitors": ["川南榨菜", "聚味特"],
                        "special_instructions": "分析价格策略和市场细分",
                        "analysis_dimensions": ["价格定位", "性价比分析", "市场细分", "价格敏感度"]
                    },
                    {
                        "agent_name": "小刘",
                        "agent_type": "channel_strategy_agent",
                        "focus_area": "渠道策略分析",
                        "assigned_competitors": ["乌江榨菜", "钱江榨菜"],
                        "special_instructions": "分析渠道布局和终端管理",
                        "analysis_dimensions": ["渠道布局", "终端覆盖", "渠道管理", "供应链优化"]
                    },
                    {
                        "agent_name": "小赵",
                        "agent_type": "regional_characteristics_agent",
                        "focus_area": "地域特色分析",
                        "assigned_competitors": ["铜钱桥榨菜", "川南榨菜"],
                        "special_instructions": "分析地域特色和文化适应性",
                        "analysis_dimensions": ["地域特色", "文化适应性", "本地化策略", "区域偏好"]
                    }
                ],
                "expected_deliverables": [
                    "竞品分析报告",
                    "市场策略建议",
                    "品牌定位方案",
                    "渠道优化建议",
                    "价格策略调整方案"
                ],
                "success_criteria": [
                    "全面覆盖主要竞品",
                    "深度分析各维度",
                    "提供可执行建议",
                    "数据支撑充分"
                ]
            }
            
            config_path = '/vol1/1000/iflow/skills/task-coordinator/tasks/beidefu_competitor_analysis.json'
            with open(config_path, 'w', encoding='utf-8') as f:
                json.dump(task_config, f, ensure_ascii=False, indent=2)
            
            logger.info(f"任务配置创建完成: {config_path}")
            return True
        except Exception as e:
            logger.error(f"创建任务配置失败: {e}")
            return False
    
    def create_test_agents(self):
        """创建测试Agent"""
        try:
            test_agents = {
                "xiaoming_agent": {
                    "id": "xiaoming_agent",
                    "name": "小明-市场策略分析专家",
                    "capabilities": ["market_analysis", "competitor_research", "data_analysis", "strategy_development"],
                    "max_concurrent_tasks": 3,
                    "current_tasks": 0,
                    "specialties": ["市场策略", "品牌分析", "渠道管理", "竞争情报"],
                    "status": 'available',
                    "last_active": datetime.now().isoformat()
                },
                "xiaobai_agent": {
                    "id": "xiaobai_agent",
                    "name": "小白-国际市场专家",
                    "capabilities": ["international_market", "export_analysis", "global_strategy", "cross_cultural_marketing"],
                    "max_concurrent_tasks": 3,
                    "current_tasks": 0,
                    "specialties": ["国际市场", "出口贸易", "海外渠道", "品牌国际化"],
                    "status": 'available',
                    "last_active": datetime.now().isoformat()
                },
                "xiaochen_agent": {
                    "id": "xiaochen_agent",
                    "name": "小陈-区域竞争专家",
                    "capabilities": ["regional_analysis", "local_competition", "channel_optimization", "market_penetration"],
                    "max_concurrent_tasks": 3,
                    "current_tasks": 0,
                    "specialties": ["区域市场", "本地竞争", "渠道深耕", "客户关系"],
                    "status": 'available',
                    "last_active": datetime.now().isoformat()
                },
                "xiaoli_agent": {
                    "id": "xiaoli_agent",
                    "name": "小李-产品差异化专家",
                    "capabilities": ["product_differentiation", "brand_positioning", "consumer_insights", "innovation_analysis"],
                    "max_concurrent_tasks": 3,
                    "current_tasks": 0,
                    "specialties": ["产品差异化", "品牌定位", "消费者洞察", "产品创新"],
                    "status": 'available',
                    "last_active": datetime.now().isoformat()
                },
                "xiaozhang_agent": {
                    "id": "xiaozhang_agent",
                    "name": "小张-品牌定位专家",
                    "capabilities": ["brand_strategy", "positioning_analysis", "brand_comparison", "marketing_communication"],
                    "max_concurrent_tasks": 3,
                    "current_tasks": 0,
                    "specialties": ["品牌战略", "定位分析", "品牌对比", "营销传播"],
                    "status": 'available',
                    "last_active": datetime.now().isoformat()
                },
                "xiaowang_agent": {
                    "id": "xiaowang_agent",
                    "name": "小王-价格策略专家",
                    "capabilities": ["pricing_strategy", "cost_analysis", "competitor_pricing", "value_proposition"],
                    "max_concurrent_tasks": 3,
                    "current_tasks": 0,
                    "specialties": ["价格策略", "成本分析", "竞争定价", "价值主张"],
                    "status": 'available',
                    "last_active": datetime.now().isoformat()
                },
                "xiaoliu_agent": {
                    "id": "xiaoliu_agent",
                    "name": "小刘-渠道策略专家",
                    "capabilities": ["channel_strategy", "distribution_analysis", "supply_chain", "retail_optimization"],
                    "max_concurrent_tasks": 3,
                    "current_tasks": 0,
                    "specialties": ["渠道策略", "分销分析", "供应链", "零售优化"],
                    "status": 'available',
                    "last_active": datetime.now().isoformat()
                },
                "xiaozhao_agent": {
                    "id": "xiaozhao_agent",
                    "name": "小赵-地域特色专家",
                    "capabilities": ["regional_characteristics", "localization_strategy", "cultural_adaptation", "regional_marketing"],
                    "max_concurrent_tasks": 3,
                    "current_tasks": 0,
                    "specialties": ["地域特色", "本地化策略", "文化适应", "区域营销"],
                    "status": 'available',
                    "last_active": datetime.now().isoformat()
                }
            }
            
            # 添加到coordinator
            for agent_id, agent_data in test_agents.items():
                from task_coordinator import Agent
                self.coordinator.agents[agent_id] = Agent(**agent_data)
            
            logger.info(f"测试Agent创建完成，共{len(test_agents)}个")
            return True
        except Exception as e:
            logger.error(f"创建测试Agent失败: {e}")
            return False
    
    def test_create_task(self):
        """测试创建任务"""
        try:
            logger.info("=== 测试创建备得福竞品分析任务 ===")
            
            task_name = "备得福榨菜品牌竞品分析测试"
            task_description = "测试任务：对备得福榨菜品牌进行全面竞品分析，包括主要竞品的市场定位、产品策略、价格策略等方面分析。"
            
            self.test_task_id = self.coordinator.create_task(
                name=task_name,
                description=task_description,
                priority="high"
            )
            
            if self.test_task_id:
                logger.info(f"任务创建成功，ID: {self.test_task_id}")
                self.test_results['create_task'] = {'success': True, 'task_id': self.test_task_id}
                return True
            else:
                logger.error("任务创建失败")
                self.test_results['create_task'] = {'success': False}
                return False
        except Exception as e:
            logger.error(f"测试创建任务失败: {e}")
            self.test_results['create_task'] = {'success': False, 'error': str(e)}
            return False
    
    def test_task_decomposition(self):
        """测试任务拆解"""
        try:
            logger.info("=== 测试任务拆解 ===")
            
            if not self.test_task_id:
                logger.error("任务ID不存在")
                return False
            
            success = self.coordinator.decompose_task(self.test_task_id)
            
            if success:
                task = self.coordinator.tasks[self.test_task_id]
                logger.info(f"任务拆解成功，生成{len(task.subtasks)}个子任务")
                
                self.test_results['decomposition'] = {
                    'success': True,
                    'subtask_count': len(task.subtasks)
                }
                return True
            else:
                logger.error("任务拆解失败")
                self.test_results['decomposition'] = {'success': False}
                return False
        except Exception as e:
            logger.error(f"测试任务拆解失败: {e}")
            self.test_results['decomposition'] = {'success': False, 'error': str(e)}
            return False
    
    def test_agent_assignment(self):
        """测试Agent分配"""
        try:
            logger.info("=== 测试Agent分配 ===")
            
            if not self.test_task_id:
                logger.error("任务ID不存在")
                return False
            
            success = self.coordinator.assign_tasks(self.test_task_id, auto_assign=True)
            
            if success:
                assignments = self.coordinator.active_assignments.get(self.test_task_id, [])
                logger.info(f"Agent分配成功，{len(assignments)}个子任务已分配")
                
                self.test_results['assignment'] = {
                    'success': True,
                    'assignment_count': len(assignments)
                }
                return True
            else:
                logger.error("Agent分配失败")
                self.test_results['assignment'] = {'success': False}
                return False
        except Exception as e:
            logger.error(f"测试Agent分配失败: {e}")
            self.test_results['assignment'] = {'success': False, 'error': str(e)}
            return False
    
    def test_collaborative_execution(self):
        """测试协同执行"""
        try:
            logger.info("=== 测试协同执行 ===")
            
            if not self.test_task_id:
                logger.error("任务ID不存在")
                return False
            
            success = self.coordinator.coordinate_collaborative_task(self.test_task_id)
            
            if success:
                logger.info("协同执行启动成功")
                
                self.test_results['execution'] = {
                    'success': True,
                    'task_id': self.test_task_id
                }
                return True
            else:
                logger.error("协同执行启动失败")
                self.test_results['execution'] = {'success': False}
                return False
        except Exception as e:
            logger.error(f"测试协同执行失败: {e}")
            self.test_results['execution'] = {'success': False, 'error': str(e)}
            return False
    
    def create_mock_results(self):
        """创建模拟结果"""
        try:
            logger.info("=== 创建模拟执行结果 ===")
            
            assignments = self.coordinator.active_assignments.get(self.test_task_id, [])
            mock_results = []
            
            for i, assignment in enumerate(assignments):
                result = {
                    "task_id": assignment.get('task_id'),
                    "agent_id": assignment.get('agent_id'),
                    "agent_name": assignment.get('agent_name'),
                    "success": True,
                    "execution_time": 300 + i * 60,
                    "output": f"""
{assignment.get('agent_name')} 执行结果

任务: {assignment.get('task_name')}
执行时间: {300 + i * 60}秒

分析结果:
✅ 数据收集完成
✅ 竞品分析完成
✅ 对比研究完成
✅ 策略建议生成

关键发现:
1. 市场定位清晰明确
2. 产品差异化显著
3. 价格策略合理
4. 渠道布局完善

建议:
1. 强化品牌建设
2. 优化产品结构
3. 拓展销售渠道
4. 提升服务质量

注: 这是测试模式的模拟结果
            """.strip(),
                    "timestamp": datetime.now().isoformat()
                }
                mock_results.append(result)
            
            self.mock_results = mock_results
            logger.info(f"模拟结果创建完成，共{len(mock_results)}个")
            return True
        except Exception as e:
            logger.error(f"创建模拟结果失败: {e}")
            return False
    
    def test_result_aggregation(self):
        """测试结果聚合"""
        try:
            logger.info("=== 测试结果聚合 ===")
            
            if not hasattr(self, 'mock_results'):
                logger.error("模拟结果不存在")
                return False
            
            aggregated = self.coordinator.collect_and_aggregate_results(
                self.test_task_id, 
                self.mock_results
            )
            
            if aggregated:
                logger.info("结果聚合成功")
                
                self.test_results['aggregation'] = {
                    'success': True,
                    'result_count': len(self.mock_results)
                }
                return True
            else:
                logger.error("结果聚合失败")
                self.test_results['aggregation'] = {'success': False}
                return False
        except Exception as e:
            logger.error(f"测试结果聚合失败: {e}")
            self.test_results['aggregation'] = {'success': False, 'error': str(e)}
            return False
    
    def test_report_generation(self):
        """测试报告生成"""
        try:
            logger.info("=== 测试报告生成 ===")
            
            # 使用结果聚合器生成报告
            if hasattr(self.coordinator, 'result_aggregator') and self.coordinator.result_aggregator:
                report_result = self.coordinator.result_aggregator.create_comprehensive_report(self.test_task_id)
                
                if report_result.get('status') == 'success':
                    logger.info("报告生成成功")
                    
                    self.test_results['report'] = {
                        'success': True,
                        'report_file': report_result.get('report_file'),
                        'executive_summary': report_result.get('executive_summary')
                    }
                    return True
                else:
                    logger.error("报告生成失败")
                    self.test_results['report'] = {'success': False}
                    return False
            else:
                # 创建简单的报告
                simple_report = f"""
# 备得福竞品分析任务测试报告

**任务ID**: {self.test_task_id}
**生成时间**: {datetime.now().isoformat()}
**测试状态**: 完成

## 测试结果

{chr(10).join([f"- {k}: {v.get('success', False)}" for k, v in self.test_results.items()])}

## 测试数据

任务已创建并执行了完整的工作流程，包括：
- 任务创建
- 任务拆解
- Agent分配
- 协同执行
- 结果聚合

所有核心功能已验证正常工作。
                """.strip()
                
                # 保存报告
                report_file = f"/vol1/1000/iflow/skills/task-coordinator/results/beidefu_task_test_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.md"
                with open(report_file, 'w', encoding='utf-8') as f:
                    f.write(simple_report)
                
                logger.info("简单报告生成成功")
                
                self.test_results['report'] = {
                    'success': True,
                    'report_file': report_file,
                    'report_length': len(simple_report)
                }
                return True
                
        except Exception as e:
            logger.error(f"测试报告生成失败: {e}")
            self.test_results['report'] = {'success': False, 'error': str(e)}
            return False
    
    def generate_test_report(self):
        """生成测试报告"""
        try:
            logger.info("=== 生成测试报告 ===")
            
            total_tests = len(self.test_results)
            passed_tests = len([r for r in self.test_results.values() if r.get('success', False)])
            
            report = f"""
# 备得福竞品分析任务测试报告

**测试时间**: {datetime.now().isoformat()}
**测试任务ID**: {self.test_task_id}
**总测试项**: {total_tests}
**通过测试**: {passed_tests}
**成功率**: {passed_tests/total_tests*100:.1f}%

## 测试结果

"""
            
            for test_name, result in self.test_results.items():
                status = "✅ 通过" if result.get('success', False) else "❌ 失败"
                report += f"### {test_name}: {status}\n"
                if 'error' in result:
                    report += f"- 错误: {result['error']}\n"
                report += "\n"
            
            # 结论
            if passed_tests == total_tests:
                report += "## 结论\n\n✅ 所有测试通过！备得福竞品分析任务功能正常。\n"
            else:
                report += "## 结论\n\n⚠️ 部分测试失败，需要检查和修复。\n"
            
            # 保存报告
            report_file = f"/vol1/1000/iflow/skills/task-coordinator/results/beidefu_task_test_summary_{datetime.now().strftime('%Y%m%d_%H%M%S')}.md"
            with open(report_file, 'w', encoding='utf-8') as f:
                f.write(report)
            
            logger.info(f"测试报告已保存: {report_file}")
            print(report)
            
            return True
        except Exception as e:
            logger.error(f"生成测试报告失败: {e}")
            return False
    
    def run_complete_test(self):
        """运行完整测试"""
        try:
            logger.info("=== 开始备得福竞品分析任务完整测试 ===")
            start_time = time.time()
            
            # 1. 设置目录
            if not self.setup_directories():
                return False
            
            # 2. 创建任务配置
            if not self.create_task_config():
                return False
            
            # 3. 创建测试Agent
            if not self.create_test_agents():
                return False
            
            # 4. 测试创建任务
            if not self.test_create_task():
                return False
            
            # 5. 测试任务拆解
            if not self.test_task_decomposition():
                return False
            
            # 6. 测试Agent分配
            if not self.test_agent_assignment():
                return False
            
            # 7. 测试协同执行
            if not self.test_collaborative_execution():
                return False
            
            # 8. 创建模拟结果
            if not self.create_mock_results():
                return False
            
            # 9. 测试结果聚合
            if not self.test_result_aggregation():
                return False
            
            # 10. 测试报告生成
            if not self.test_report_generation():
                return False
            
            # 11. 生成测试报告
            if not self.generate_test_report():
                return False
            
            end_time = time.time()
            duration = end_time - start_time
            
            logger.info(f"=== 备得福竞品分析任务测试完成，耗时: {duration:.2f}秒 ===")
            return True
            
        except Exception as e:
            logger.error(f"运行完整测试失败: {e}")
            return False

def main():
    """主函数"""
    print("🧪 备得福竞品分析任务测试")
    print("=" * 40)
    
    tester = BeiDefuTaskTest()
    success = tester.run_complete_test()
    
    if success:
        print("\n✅ 测试完成！")
        print(f"📊 任务ID: {tester.test_task_id}")
        print("📁 查看结果:")
        print("   - 日志: /vol1/1000/iflow/skills/task-coordinator/logs/beidefu_task_test.log")
        print("   - 报告: /vol1/1000/iflow/skills/task-coordinator/results/")
    else:
        print("\n❌ 测试失败！")
        return 1
    
    return 0

if __name__ == "__main__":
    exit(main())
