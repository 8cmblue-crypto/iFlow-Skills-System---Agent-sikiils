#!/usr/bin/env python3
"""
协同分配功能演示脚本
老大，这个脚本演示任务分配协同技能的完整工作流程
"""

import sys
import os
import json
import time
from datetime import datetime

# 添加当前目录到Python路径
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from task_coordinator import TaskCoordinator

def demo_collaborative_task_execution():
    """演示协同任务执行"""
    print("=== 任务分配协同技能演示 ===\n")
    
    # 初始化协调器
    coordinator = TaskCoordinator()
    
    # 1. 创建一个复杂的协同任务
    print("1. 创建协同任务...")
    task_id = coordinator.create_task(
        name="电商平台代码审查与文档生成",
        description="对电商平台系统进行全面的代码审查，包括安全性检查、性能分析，并生成完整的技术文档。需要检查用户认证模块、支付处理模块、商品管理模块和订单处理模块。",
        priority="high"
    )
    print(f"   任务创建成功: {task_id}")
    
    # 2. 执行协同任务
    print("\n2. 执行协同任务分配...")
    success = coordinator.coordinate_collaborative_task(task_id)
    if success:
        print("   任务分配成功!")
    else:
        print("   任务分配失败!")
        return
    
    # 3. 查看任务状态
    print("\n3. 查看协同任务状态...")
    collaboration_status = coordinator.get_collaboration_status(task_id)
    print(f"   任务状态: {collaboration_status['task_status']}")
    print(f"   分配的Agent数量: {len(collaboration_status['assignments'])}")
    
    for assignment in collaboration_status['assignments']:
        print(f"   - Agent: {assignment['agent_name']} (置信度: {assignment['confidence_score']:.2f})")
        print(f"     任务: {assignment['task_name']}")
    
    # 4. 模拟Agent执行结果
    print("\n4. 模拟Agent执行...")
    agent_outputs = []
    
    # 为每个分配生成模拟输出
    for i, assignment in enumerate(collaboration_status['assignments']):
        output = {
            "task_id": assignment['task_id'],
            "agent_id": assignment['agent_id'],
            "agent_type": assignment['agent_id'].split('-')[0] if '-' in assignment['agent_id'] else 'general',
            "success": True,
            "execution_time": 120 + i * 30,
            "output": f"""
=== {assignment['task_name']} 执行结果 ===
执行Agent: {assignment['agent_name']}
任务ID: {assignment['task_id']}
执行时间: {120 + i * 30}秒

检查结果:
- 代码质量: 良好
- 安全性: 通过
- 性能: 优化建议已提供
- 文档完整性: 95%

建议:
1. 优化数据库查询性能
2. 增强输入验证
3. 完善错误处理机制
4. 添加更多单元测试

详细分析报告已生成并保存。
            """.strip(),
            "timestamp": datetime.now().isoformat()
        }
        agent_outputs.append(output)
        print(f"   Agent {assignment['agent_name']} 执行完成")
    
    # 5. 收集和聚合结果
    print("\n5. 聚合执行结果...")
    aggregated_results = coordinator.collect_and_aggregate_results(task_id, agent_outputs)
    
    if aggregated_results:
        summary = aggregated_results.get('summary', {})
        print(f"   总任务数: {summary.get('total_tasks', 0)}")
        print(f"   完成任务数: {summary.get('completed_tasks', 0)}")
        print(f"   失败任务数: {summary.get('failed_tasks', 0)}")
        print(f"   成功率: {summary.get('completed_tasks', 0) / max(summary.get('total_tasks', 1), 1):.2%}")
        
        conflicts = aggregated_results.get('conflicts', [])
        if conflicts:
            print(f"   检测到冲突: {len(conflicts)} 个")
        else:
            print("   无冲突检测")
    
    # 6. 生成完整报告
    print("\n6. 生成任务执行报告...")
    report = coordinator.generate_task_report(task_id)
    print(report)
    
    # 7. 演示文件同步
    print("\n7. 演示文件同步功能...")
    if coordinator.file_sync_system:
        # 创建一些示例文件
        demo_files = []
        for i in range(3):
            file_content = f"""
# 示例文件 {i+1}
生成时间: {datetime.now().isoformat()}
任务ID: {task_id}
Agent: general-purpose

这是协同任务执行过程中生成的示例文件。
包含任务执行结果和分析报告。
            """.strip()
            
            file_path = f"/tmp/demo_file_{i+1}.md"
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(file_content)
            demo_files.append(file_path)
        
        # 同步文件
        sync_success = coordinator.sync_files_for_task(task_id, demo_files, "general-purpose")
        if sync_success:
            print("   文件同步成功!")
        else:
            print("   文件同步失败!")
        
        # 清理临时文件
        for file_path in demo_files:
            if os.path.exists(file_path):
                os.remove(file_path)
    
    # 8. 查看系统状态
    print("\n8. 查看系统状态...")
    system_status = coordinator.get_system_status()
    print(f"   总任务数: {system_status['total_tasks']}")
    print(f"   可用Agent数: {system_status['available_agents']}")
    print(f"   活跃分配数: {system_status['active_assignments']}")
    
    print("\n=== 演示完成 ===")

def demo_agent_performance():
    """演示Agent性能统计"""
    print("\n=== Agent性能统计演示 ===\n")
    
    coordinator = TaskCoordinator()
    
    # 获取Agent列表
    agents = coordinator.list_agents()
    
    print("Agent性能统计:")
    for agent in agents:
        print(f"\n{agent['name']} ({agent['id']}):")
        print(f"  状态: {agent['status']}")
        print(f"  当前任务数: {agent['current_tasks']}/{agent['max_concurrent_tasks']}")
        print(f"  能力: {', '.join(agent['capabilities'])}")
        print(f"  专长: {', '.join(agent['specialties'])}")
        print(f"  最后活跃: {agent['last_active']}")

def demo_file_sync_status():
    """演示文件同步状态"""
    print("\n=== 文件同步状态演示 ===\n")
    
    coordinator = TaskCoordinator()
    
    if coordinator.file_sync_system:
        sync_status = coordinator.file_sync_system.get_sync_status()
        print("文件同步状态:")
        print(f"  总文件数: {sync_status['total_files']}")
        print(f"  已同步文件数: {sync_status['synced_files']}")
        print(f"  待同步文件数: {sync_status['pending_files']}")
        print(f"  总操作数: {sync_status['total_operations']}")
        print(f"  完成操作数: {sync_status['completed_operations']}")
        print(f"  失败操作数: {sync_status['failed_operations']}")
        
        if sync_status['recent_operations']:
            print("\n最近操作:")
            for op in sync_status['recent_operations'][:3]:
                print(f"  - {op['operation_type']}: {op['file_path']} ({op['status']})")
    else:
        print("文件同步系统未初始化")

def main():
    """主函数"""
    try:
        # 演示协同任务执行
        demo_collaborative_task_execution()
        
        # 演示Agent性能
        demo_agent_performance()
        
        # 演示文件同步状态
        demo_file_sync_status()
        
    except Exception as e:
        print(f"演示过程中发生错误: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()