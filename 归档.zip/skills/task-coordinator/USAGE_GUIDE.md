# 备得福榨菜竞品分析 - 使用指南

## 快速开始

### 方法一：一键启动（推荐）
```bash
/vol1/1000/iflow/skills/task-coordinator/start_beidefu_analysis.sh
```

### 方法二：手动执行
```bash
cd /vol1/1000/iflow/skills/task-coordinator/scripts
python3 beidefu_analysis_executor.py
```

## 核心文件说明

### 配置文件
- **任务配置**: `/vol1/1000/iflow/skills/task-coordinator/tasks/beidefu_competitor_analysis.json`
- **Agent指令**: `/vol1/1000/iflow/skills/task-coordinator/tasks/agent_instructions.md`

### 执行文件
- **执行引擎**: `/vol1/1000/iflow/skills/task-coordinator/scripts/beidefu_analysis_executor.py`
- **启动脚本**: `/vol1/1000/iflow/skills/task-coordinator/start_beidefu_analysis.sh`

### 输出文件
- **项目总结**: `/vol1/1000/iflow/skills/task-coordinator/results/beidefu_project_summary.md`
- **工作空间**: `/vol1/1000/iflow/sync_workspace/task_[task_id]/`

## Agent分工详情

| Agent | 竞品 | 专注领域 | 关键任务 |
|-------|------|----------|----------|
| 小明 | 乌江榨菜 | 市场策略 | 龙头企业策略解析 |
| 小白 | 鱼泉榨菜 | 国际市场 | 出口经验总结 |
| 小陈 | 铜钱桥榨菜 | 区域竞争 | 本地化竞争分析 |
| 小李 | 乡下妹榨菜 | 产品差异化 | 差异化定位方法 |
| 小张 | 六必居&吉香居 | 品牌定位 | 传统vs现代对比 |
| 小王 | 川南&聚味特 | 价格策略 | 价格分层分析 |
| 小刘 | 钱江榨菜 | 渠道策略 | 渠道优化方案 |
| 小赵 | 红山方便榨菜 | 地域特色 | 地域化适配策略 |

## 分析维度

每个Agent将从以下6个维度进行分析：
1. **公司背景和规模** - 企业实力评估
2. **产品特色和优势** - 核心竞争力分析  
3. **市场定位和价格策略** - 战略定位解析
4. **销售渠道和区域分布** - 渠道能力评估
5. **与备得福的竞争关系** - 直接竞争分析
6. **可借鉴的地方** - 战略启示提炼

## 预期产出

### 直接产出
- 8份专业分析报告（PPT格式）
- 1份竞品对比分析表
- 1套备得福战略建议
- 1个可执行的行动计划

### 交付格式
```
最终交付/
├── 个人分析报告/
├── 横向对比分析/
├── 战略建议报告/
├── 市场机会分析/
└── 执行行动计划/
```

## 执行时间线

- **任务创建**: 5分钟
- **Agent分配**: 5分钟
- **并行分析**: 45分钟（8个Agent同时工作）
- **结果聚合**: 5分钟
- **报告生成**: 10分钟
- **总计**: 约70分钟

## 质量保证

### 数据要求
- ✅ 必须使用真实市场数据
- ✅ 严禁使用模拟数据
- ✅ 数据来源要可靠可查
- ✅ 分析要有数据支撑

### 分析标准
- ✅ 深度分析，避免表面化
- ✅ 与备得福实际情况结合
- ✅ 建议要具体可执行
- ✅ 体现专业性和洞察力

## 监控与日志

### 实时监控
执行期间可通过以下方式监控进度：
```bash
# 查看实时日志
tail -f /vol1/1000/iflow/skills/task-coordinator/logs/beidefu_analysis.log

# 查看Agent工作状态
ls -la /vol1/1000/iflow/sync_workspace/task_*/
```

### 关键日志信息
- 任务创建和分配状态
- 各Agent执行进度
- 文件同步状态
- 结果聚合过程
- 异常和错误信息

## 故障排查

### 常见问题

**Q: 执行失败怎么办？**
A: 查看日志文件，检查Python环境和依赖模块

**Q: Agent没有响应？**
A: 检查系统资源，确认Agent容量限制

**Q: 结果文件缺失？**
A: 检查工作空间权限和磁盘空间

**Q: 报告格式错误？**
A: 确认所有Agent都按时提交了分析结果

### 应急措施
```bash
# 检查Python环境
python3 --version

# 检查依赖模块
python3 -c "import task_coordinator"

# 查看错误日志
tail -50 /vol1/1000/iflow/skills/task-coordinator/logs/beidefu_analysis.log

# 重新启动（如需要）
/vol1/1000/iflow/skills/task-coordinator/start_beidefu_analysis.sh
```

## 联系支持

如遇到技术问题，请提供：
1. 错误日志内容
2. 执行时间点
3. 系统环境信息
4. 具体错误描述

---

**版本**: v1.0  
**更新时间**: 2025-12-25  
**适用系统**: iFlow CLI  
**文档维护**: 任务协调器团队