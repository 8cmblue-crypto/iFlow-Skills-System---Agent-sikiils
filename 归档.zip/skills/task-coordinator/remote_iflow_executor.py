#!/usr/bin/env python3
"""
远程iFlow任务执行器
通过SSH连接到远程主机执行iFlow任务
"""

import subprocess
import json
import time
from datetime import datetime
from typing import Dict, List, Any, Optional
from pathlib import Path

class RemoteIFlowExecutor:
    """远程iFlow任务执行器"""
    
    def __init__(self, host: str, username: str = "林浩"):
        self.host = host
        self.username = username
        self.workspace = "~/iflow_workspace"
        
    def execute_remote_command(self, command: str, timeout: int = 30) -> Dict[str, Any]:
        """执行远程命令"""
        try:
            full_command = f"ssh {self.username}@{self.host} '{command}'"
            
            print(f"🚀 执行远程命令: {full_command}")
            
            result = subprocess.run(
                full_command,
                shell=True,
                capture_output=True,
                text=True,
                timeout=timeout
            )
            
            return {
                "success": result.returncode == 0,
                "stdout": result.stdout.strip(),
                "stderr": result.stderr.strip(),
                "returncode": result.returncode,
                "command": command
            }
            
        except subprocess.TimeoutExpired:
            return {
                "success": False,
                "error": f"命令执行超时 ({timeout}秒)",
                "command": command
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "command": command
            }
    
    def setup_remote_environment(self) -> Dict[str, Any]:
        """设置远程环境"""
        print("🔧 设置远程iFlow环境...")
        
        setup_commands = [
            f"mkdir -p {self.workspace}",
            f"cd {self.workspace} && echo '工作目录已创建'",
            "python3 --version",
            "git --version",
            "echo '环境检查完成'"
        ]
        
        results = []
        for cmd in setup_commands:
            result = self.execute_remote_command(cmd)
            results.append(result)
            if not result["success"]:
                print(f"❌ 环境设置失败: {result}")
                break
        
        return {
            "success": all(r["success"] for r in results),
            "results": results
        }
    
    def create_remote_skills_structure(self) -> Dict[str, Any]:
        """创建远程skills结构"""
        print("📁 创建远程skills结构...")
        
        commands = [
            f"cd {self.workspace} && mkdir -p skills/task-coordinator/scripts",
            f"cd {self.workspace} && mkdir -p skills/task-coordinator/assets",
            f"cd {self.workspace} && echo 'Skills目录结构已创建'"
        ]
        
        results = []
        for cmd in commands:
            result = self.execute_remote_command(cmd)
            results.append(result)
        
        return {
            "success": all(r["success"] for r in results),
            "results": results
        }
    
    def transfer_task_coordinator(self) -> Dict[str, Any]:
        """传输任务协调器到远程"""
        print("📦 传输任务协调器到远程...")
        
        # 传输必要的文件
        files_to_transfer = [
            "/vol1/1000/iflow/skills/task-coordinator/assets/config.json",
            "/vol1/1000/iflow/skills/task-coordinator/scripts/complete_task_coordinator.py",
            "/vol1/1000/iflow/skills/task-coordinator/scripts/task_coordinator.py"
        ]
        
        results = []
        for local_file in files_to_transfer:
            if Path(local_file).exists():
                # 使用scp传输文件
                remote_path = f"{self.workspace}/{Path(local_file).name}"
                cmd = f"scp {local_file} {self.username}@{self.host}:{remote_path}"
                
                try:
                    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
                    results.append({
                        "file": local_file,
                        "success": result.returncode == 0,
                        "stdout": result.stdout.strip(),
                        "stderr": result.stderr.strip()
                    })
                except Exception as e:
                    results.append({
                        "file": local_file,
                        "success": False,
                        "error": str(e)
                    })
        
        return {
            "success": all(r["success"] for r in results),
            "results": results
        }
    
    def execute_remote_task(self, task_config: Dict[str, Any]) -> Dict[str, Any]:
        """执行远程任务"""
        print(f"🎯 执行远程任务: {task_config.get('task_name', 'Unknown')}")
        
        # 创建任务配置文件
        task_config_str = json.dumps(task_config, ensure_ascii=False, indent=2)
        
        commands = [
            f"cd {self.workspace} && echo '{task_config_str}' > task_config.json",
            f"cd {self.workspace} && echo '任务配置已保存'",
            f"cd {self.workspace} && python3 -c 'import json; print(json.load(open(\"task_config.json\")))'"
        ]
        
        results = []
        for cmd in commands:
            result = self.execute_remote_command(cmd)
            results.append(result)
            if not result["success"]:
                break
        
        return {
            "success": all(r["success"] for r in results),
            "results": results,
            "task_config": task_config
        }
    
    def test_remote_connection(self) -> Dict[str, Any]:
        """测试远程连接"""
        print("🔍 测试远程连接...")
        
        test_result = self.execute_remote_command("echo '连接测试成功' && date")
        
        if test_result["success"]:
            print("✅ 远程连接测试成功")
            print(f"   主机: {self.host}")
            print(f"   用户: {self.username}")
            print(f"   响应: {test_result['stdout']}")
        else:
            print("❌ 远程连接测试失败")
            print(f"   错误: {test_result.get('error', 'Unknown')}")
        
        return test_result

def main():
    """主函数"""
    print("🚀 远程iFlow任务执行器启动")
    print("=" * 50)
    
    # 创建执行器
    executor = RemoteIFlowExecutor("192.168.31.144")
    
    # 测试连接
    connection_test = executor.test_remote_connection()
    if not connection_test["success"]:
        print("❌ 无法连接到远程主机，退出")
        return
    
    # 设置环境
    env_setup = executor.setup_remote_environment()
    if not env_setup["success"]:
        print("❌ 环境设置失败，退出")
        return
    
    # 创建skills结构
    skills_setup = executor.create_remote_skills_structure()
    if not skills_setup["success"]:
        print("❌ Skills结构创建失败，退出")
        return
    
    # 示例任务
    sample_task = {
        "task_name": "远程测试任务",
        "task_type": "test",
        "priority": "medium",
        "description": "测试远程iFlow任务执行",
        "created_at": datetime.now().isoformat(),
        "steps": [
            {"name": "环境检查", "command": "echo '环境检查完成'"},
            {"name": "任务执行", "command": "echo '任务执行完成'"},
            {"name": "结果收集", "command": "echo '结果收集完成'"}
        ]
    }
    
    # 执行任务
    task_result = executor.execute_remote_task(sample_task)
    
    print("\n🎉 远程任务执行完成!")
    print(f"✅ 连接测试: {'成功' if connection_test['success'] else '失败'}")
    print(f"✅ 环境设置: {'成功' if env_setup['success'] else '失败'}")
    print(f"✅ Skills设置: {'成功' if skills_setup['success'] else '失败'}")
    print(f"✅ 任务执行: {'成功' if task_result['success'] else '失败'}")
    
    return {
        "connection_test": connection_test,
        "env_setup": env_setup,
        "skills_setup": skills_setup,
        "task_result": task_result
    }

if __name__ == "__main__":
    main()