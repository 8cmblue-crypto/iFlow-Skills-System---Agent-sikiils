#!/usr/bin/env python3
"""
SSH连接测试脚本
测试到指定服务器的连接状态
"""

import subprocess
import socket
import sys
from datetime import datetime

def test_ssh_connection(host, user, timeout=10):
    """测试SSH连接"""
    print(f"🔍 测试SSH连接到 {user}@{host}")
    print("=" * 50)
    
    # 1. 测试网络连通性
    print("1. 测试网络连通性...")
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout)
        result = sock.connect_ex((host, 22))
        sock.close()
        
        if result == 0:
            print("   ✅ 端口22开放")
        else:
            print("   ❌ 端口22不可达")
            return False
    except Exception as e:
        print(f"   ❌ 网络测试失败: {e}")
        return False
    
    # 2. 测试SSH服务
    print("2. 测试SSH服务...")
    try:
        cmd = ['ssh', '-o', 'ConnectTimeout=5', '-o', 'BatchMode=yes', 
               f'{user}@{host}', 'echo "SSH连接测试"']
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        
        if result.returncode == 0:
            print("   ✅ SSH服务正常")
            print(f"   📝 响应: {result.stdout.strip()}")
            return True
        else:
            print("   ❌ SSH连接失败")
            print(f"   📝 错误: {result.stderr.strip()}")
            return False
    except subprocess.TimeoutExpired:
        print("   ❌ SSH连接超时")
        return False
    except Exception as e:
        print(f"   ❌ SSH测试失败: {e}")
        return False

def main():
    """主函数"""
    if len(sys.argv) < 3:
        print("用法: python3 ssh_test.py <host> <user>")
        print("示例: python3 ssh_test.py 192.168.31.144 vinson")
        sys.exit(1)
    
    host = sys.argv[1]
    user = sys.argv[2]
    
    print(f"🚀 SSH连接测试工具")
    print(f"⏰ 测试时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print()
    
    success = test_ssh_connection(host, user)
    
    print("\n" + "=" * 50)
    if success:
        print("🎉 连接测试成功！")
        print("\n📖 连接命令:")
        print(f"   ssh {user}@{host}")
    else:
        print("❌ 连接测试失败！")
        print("\n🔧 故障排除建议:")
        print("   1. 检查目标服务器SSH服务状态")
        print("   2. 确认防火墙设置")
        print("   3. 验证网络连通性")
        print("   4. 检查用户名和权限")

if __name__ == "__main__":
    main()