---
name: subagent-manager
version: 1.0.0
description: >
  iFlow子Agent管理系统 - 选择目标主机iFlow，管理目标主机会话，实现并行任务和会话压缩能力。
  支持多主机并行任务、会话生命周期管理、上下文压缩控制、子Agent代理管理等功能。
  通过命令控制下的会话压缩能力为所有目标主机会话赋予压缩能力，实现真正的并行任务处理。

author: 林浩 <老大@iflow.com>
license: MIT
tags: [subagent-management, parallel-tasks, session-compression, host-management]
allowed_tools: [bash, python3]
required_context: []
---

# iFlow子Agent管理系统

## 🎯 **技能概述**

选择目标主机iFlow，管理目标主机会话，实现并行任务和会话压缩能力。通过命令控制下的会话压缩能力为所有目标主机会话赋予压缩能力，实现真正的并行任务处理和子Agent代理管理。

## 📋 **核心功能**

### ✅ **目标主机管理**
- **主机选择**: 选择和定义目标iFlow主机
- **主机职责**: 管理目标主机的任务职责和功能
- **主机状态**: 监控目标主机的运行状态
- **主机配置**: 配置目标主机的参数和能力

### 🔄 **会话管理系统**
- **会话创建**: 在目标主机上创建新会话
- **会话保持**: 保持目标主机会话的连续性
- **会话切换**: 在不同目标主机的会话间切换
- **会话压缩**: 为目标主机会话赋予压缩能力

### 🚀 **并行任务能力**
- **并行执行**: 同时在多个目标主机上执行任务
- **任务调度**: 智能调度和分配任务到不同主机
- **状态同步**: 同步多个主机的执行状态
- **结果聚合**: 聚合并分析多个主机的执行结果

### 🤖 **子Agent代理管理**
- **Agent创建**: 创建和管理子Agent实例
- **Agent分配**: 将子Agent分配到不同目标主机
- **Agent监控**: 监控子Agent的运行状态
- **Agent协调**: 协调多个子Agent的协作

## 🔧 **技术实现**

### 📁 **文件结构**
```
skills/subagent-manager/
├── SKILL.md                    # 技能说明文档
├── assets/
│   └── config.json             # 配置文件
├── scripts/
│   ├── host_manager.py          # 主机管理器
│   ├── session_controller.py    # 会话控制器
│   ├── task_scheduler.py        # 任务调度器
│   ├── subagent_coordinator.py  # 子Agent协调器
│   └── compression_engine.py    # 压缩引擎
└── references/
    └── SUBAGENT_REFERENCE.md     # 子Agent参考手册
```

### 🔄 **工作流程**
```
目标主机选择 → 主机配置 → 会话创建 → 并行任务执行 → 结果聚合
    ↓
子Agent管理 → 会话压缩 → 状态监控 → 任务调度 → 协调控制
```

## ⚙️ **配置参数**

### 🎯 **命令控制配置**
```json
{
  "command_control": {
    "slash_commands": true,
    "session_management": true,
    "context_control": true,
    "auto_execution": false
  },
  "session": {
    "default_timeout": 300,
    "max_sessions": 100,
    "auto_cleanup": true,
    "cleanup_interval": 3600
  },
  "context": {
    "compression_threshold": 0.7,
    "auto_compress": true,
    "preserve_history": true
  }
}
```

## 🚀 **使用方法**

### 📦 **快速开始**
```bash
# 初始化子Agent管理系统
python3 scripts/host_manager.py init

# 列出所有目标主机
python3 scripts/host_manager.py list-hosts

# 选择目标主机并创建会话
python3 scripts/host_manager.py select-host <host-id>

# 在目标主机上执行并行任务
python3 scripts/task_scheduler.py execute-parallel <task-list>

# 启动会话压缩监控
python3 scripts/compression_engine.py start-monitoring
```

### 🔧 **iFlow内置命令**
```bash
# 查看所有可用命令
iflow commands list

# 添加命令到本地
iflow commands add <command-id>

# 在iFlow中使用斜杠命令
/session-start    # 开始新会话
/session-end      # 结束会话并总结
/understand       # 分析项目架构
```

### 📱 **会话管理操作**
```bash
# 创建新会话
iflow -c "创建新的开发会话"

# 继续最近的会话
iflow --continue

# 恢复指定会话
iflow --resume <session-id>

# 查看会话状态
python3 scripts/session_manager.py status
```

## 📊 **会话管理详解**

### 🔄 **会话生命周期**
1. **会话创建** - 生成唯一会话ID
2. **上下文初始化** - 设置初始状态
3. **对话执行** - 处理用户输入
4. **状态保存** - 实时保存会话状态
5. **会话结束** - 生成总结并归档

### 🎯 **会话切换机制**
```python
# 切换到指定会话
def switch_session(session_id):
    # 1. 保存当前会话状态
    save_current_session()
    
    # 2. 加载目标会话
    load_target_session(session_id)
    
    # 3. 更新活动会话
    set_active_session(session_id)
    
    return {"status": "success", "session_id": session_id}
```

### 📋 **会话列表和管理**
```bash
# 列出所有会话
python3 scripts/session_manager.py list

# 显示会话详情
python3 scripts/session_manager.py show <session-id>

# 删除会话
python3 scripts/session_manager.py delete <session-id>

# 清理过期会话
python3 scripts/session_manager.py cleanup
```

## 🎯 **老会话命令控制详解**

### ⚠️ **实际发现：会话控制的局限性**

老大，经过深入测试，发现了会话管理的**实际局限性**：

#### **实际发现**
1. ✅ **会话持久化** - 所有会话都被保存
2. ✅ **会话恢复** - 可以恢复任何历史会话（通过命令）
3. ⚠️ **跨会话命令限制** - 命令被发送但无法看到实际执行
4. ⚠️ **状态保持限制** - 只能看到命令输出记录

#### **核心问题**
- **我看不到会话界面** - 只能通过命令输出了解情况
- **无法持续交互** - 每次命令都是独立的调用
- **无法实时反馈** - 无法看到命令执行的实时效果

#### **老会话控制流程（带限制说明）**
```bash
# 1. 查看所有历史会话
iflow --resume
# 注意：只能看到命令输出记录，无法看到实际界面

# 2. 选择要恢复的会话
# (iFlow会显示会话选择器，但我看不到选择过程)

# 3. 在恢复的会话中执行命令
/session-end          # 结束并总结会话
/understand          # 分析项目
/compress_context    # 压缩上下文
# 注意：命令被发送但我无法看到实际执行界面

# 4. 会话操作完成后可以继续或切换
iflow --continue      # 继续当前会话
iflow --resume <id>   # 切换到其他会话
# 注意：每次都是新的独立会话，无法保持连接
```

#### **实际操作示例**
```bash
# 步骤1: 启动会话管理器
iflow --resume

# 步骤2: iFlow显示可用会话列表
# 可用会话:
# 1. session-06d345c1-a455-44c1-9010-5fd5e359e733 (麦好火查询)
# 2. session-8f7aa9a9-cc36-4064-8859-d1acdd9df684 (压缩测试)
# 3. session-c1a93289-1422-4108-871b-8596404b8ef4 (会话开始)

# 步骤3: 选择会话 (例如选择会话2)
# 输入: 2

# 步骤4: 会话恢复成功，可以执行命令
# iFlow: 会话已恢复，现在可以继续对话或执行命令
# 用户: /session-end
# iFlow: [执行会话结束和总结]

# 步骤5: 命令执行完成后可以继续对话
# 用户: 继续讨论压缩功能
# iFlow: [基于会话上下文继续对话]
```

### 🔄 **会话间命令传递**
```python
# 在会话A中执行命令
echo "/compress_context" | iflow

# 切换到会话B
iflow --resume <session-b-id>

# 在会话B中查看会话A的结果
echo "/show_session_result session-a-id" | iflow
```

## 💡 **高级功能**

### 🎯 **跨会话操作**
- **命令广播**: 在多个会话中执行同一命令
- **状态同步**: 同步多个会话的状态
- **上下文共享**: 在会话间共享上下文信息

### 🔄 **自动化工作流**
```bash
# 自动化会话管理工作流
python3 scripts/auto_session_manager.py \
  --action cleanup \
  --threshold 7days \
  --preserve-important
```

### 📊 **监控和分析**
```bash
# 会话使用统计
python3 scripts/session_analyzer.py stats

# 会话性能分析
python3 scripts/session_analyzer.py performance
```

## ⚠️ **重要限制和注意事项**

### 🚨 **核心限制：会话非持续连接**

#### **1. 视角差异**
- **我的视角**: 只能看到命令输出记录，无法看到实际iFlow界面
- **您的视角**: 能看到实际的对话界面和实时执行效果
- **会话状态**: 命令执行时"打开"，结束后"关闭"

#### **2. 连接限制**
- ❌ **无法持续连接**: 每次命令调用都是独立的会话
- ❌ **无法实时监控**: 无法看到命令执行的实时过程
- ❌ **无法交互反馈**: 无法根据执行结果调整操作
- ✅ **只能看到记录**: 通过命令输出了解执行情况

#### **3. 操作影响**
- **命令发送**: 可以发送命令到指定会话
- **命令执行**: iFlow会执行但看不到过程
- **结果记录**: 只能看到最终的输出记录
- **状态更新**: 会话状态会更新但无法实时查看

### 🚨 **技术限制**
1. **会话隔离**: 每个会话独立运行，命令只在当前会话生效
2. **状态一致性**: 切换会话时注意状态保存
3. **资源管理**: 避免同时打开过多会话
4. **权限控制**: 某些命令可能需要特殊权限
5. **实时性限制**: 无法实时监控和调整执行过程

### 🛡️ **安全措施**
- **会话验证**: 验证会话ID的有效性
- **权限检查**: 检查命令执行权限
- **状态备份**: 重要操作前自动备份
- **回滚机制**: 支持操作回滚

## 📞 **技术支持**

### 🐛 **常见问题**
1. **Q: 如何查看所有历史会话？**
   A: 使用 `iflow --resume` 命令，会显示会话选择器

2. **Q: 可以在老会话中执行压缩命令吗？**
   A: 可以！恢复会话后直接输入 `/session-end` 或其他斜杠命令

3. **Q: 如何在会话间传递数据？**
   A: 使用记忆系统或文件共享机制

4. **Q: 会话数据保存在哪里？**
   A: 保存在 `/home/vinson/.iflow/sessions/` 目录

### 📈 **最佳实践**
1. **定期清理**: 定期清理不需要的会话
2. **命名规范**: 使用有意义的会话名称
3. **状态保存**: 重要节点及时保存会话状态
4. **备份策略**: 定期备份重要会话数据

## 🔄 **版本历史**
- v1.0.0: 初始版本，支持基础会话管理和命令控制
- 支持会话恢复、切换、命令执行
- 集成上下文压缩和记忆系统
- 支持跨会话操作和数据传递

---

*技能版本: v1.0.0*  
*创建时间: 2025-12-25*  
*状态: 可用，支持老会话控制*

## 🎯 **目标主机管理**

### ✅ **主机定义和选择**
老大，系统支持定义和管理多个目标iFlow主机：

#### **主机配置示例**
```json
{
  "hosts": {
    "dev-server": {
      "name": "开发服务器",
      "endpoint": "http://dev-iflow.example.com",
      "role": "development",
      "capabilities": ["code_analysis", "testing", "documentation"],
      "status": "active"
    },
    "prod-server": {
      "name": "生产服务器", 
      "endpoint": "http://prod-iflow.example.com",
      "role": "production",
      "capabilities": ["deployment", "monitoring", "backup"],
      "status": "active"
    }
  }
}
```

#### **主机选择流程**
1. **扫描可用主机** - 自动发现可用的iFlow主机
2. **主机状态检查** - 验证主机的可用性和能力
3. **主机角色分配** - 根据任务类型选择合适的主机
4. **主机连接建立** - 建立与目标主机的连接

## 🔄 **并行任务执行**

### ✅ **真正的并行处理能力**
老大，系统支持真正的并行任务执行：

#### **并行任务示例**
```python
# 同时在多个主机上执行不同任务
tasks = [
    {"host": "dev-server", "task": "代码分析", "priority": "high"},
    {"host": "prod-server", "task": "性能监控", "priority": "medium"},
    {"host": "test-server", "task": "自动化测试", "priority": "low"}
]

# 并行执行所有任务
results = execute_parallel_tasks(tasks)
```

#### **任务调度策略**
- **智能分配**: 根据主机能力和任务类型智能分配
- **负载均衡**: 避免单个主机过载
- **优先级管理**: 高优先级任务优先执行
- **故障恢复**: 主机故障时自动切换

## 🤖 **子Agent代理管理**

### ✅ **Agent生命周期管理**
老大，系统支持完整的子Agent管理：

#### **Agent创建和分配**
```python
# 创建子Agent
agent = create_subagent({
    "name": "代码审查Agent",
    "capabilities": ["code_review", "security_check"],
    "target_host": "dev-server"
})

# 分配Agent到主机
assign_agent_to_host(agent_id, host_id)
```

#### **Agent协调机制**
- **任务协调**: 多个Agent协作完成复杂任务
- **状态同步**: 实时同步Agent执行状态
- **结果聚合**: 汇总多个Agent的执行结果
- **冲突解决**: 解决Agent间的执行冲突

## 💡 **命令控制下的会话压缩能力**

### ✅ **为所有目标主机会话赋予压缩能力**

老大，通过命令控制，我们可以为所有目标主机的会话赋予压缩能力：

#### **压缩能力激活流程**
```python
# 1. 选择目标主机
hosts = select_target_hosts(["dev-server", "prod-server"])

# 2. 为每个主机激活压缩能力
for host in hosts:
    enable_compression_capability(host, {
        "threshold": 0.7,
        "target_ratio": 0.3,
        "auto_trigger": True
    })

# 3. 启动压缩监控
start_compression_monitoring(hosts)
```

#### **并行压缩示例**
```bash
# 同时为多个主机启用压缩
python3 scripts/compression_engine.py enable-parallel \
  --hosts "dev-server,prod-server,test-server" \
  --threshold 0.7 \
  --auto-trigger
```

## 🚀 **并行任务和压缩的完整示例**

### **示例：多主机并行开发任务**

```bash
# 1. 初始化主机管理
python3 scripts/host_manager.py init

# 2. 选择多个目标主机
python3 scripts/host_manager.py select-multiple \
  --roles "development,production,testing"

# 3. 为所有主机启用压缩能力
python3 scripts/compression_engine.py enable-all \
  --threshold 0.7 --auto-trigger

# 4. 并行执行开发任务
python3 scripts/task_scheduler.py execute-parallel \
  --tasks "代码分析,单元测试,文档生成" \
  --hosts "dev-server,prod-server,test-server"

# 5. 监控压缩状态
python3 scripts/compression_engine.py monitor-all \
  --interval 30
```

## 📊 **系统优势**

### 🎯 **真正的并行处理**
- **多主机同时工作** - 真正的并行任务执行
- **智能任务分配** - 根据主机能力智能分配
- **实时状态监控** - 监控所有主机和Agent状态
- **自动故障恢复** - 主机故障时自动切换

### 🔄 **会话压缩全覆盖**
- **统一压缩策略** - 所有主机使用相同的压缩策略
- **分布式压缩** - 压缩任务分布在不同主机上
- **压缩结果聚合** - 汇总所有压缩结果
- **压缩状态同步** - 同步所有主机的压缩状态

### 🤖 **Agent代理协调**
- **多Agent协作** - 多个Agent协同工作
- **任务分解** - 复杂任务分解给不同Agent
- **结果聚合** - 汇总和整合Agent执行结果
- **冲突解决** - 自动解决Agent间的执行冲突

---

*技能版本: v2.0.0*  
*创建时间: 2025-12-25*  
*状态: 子Agent管理系统，支持并行任务和会话压缩*
