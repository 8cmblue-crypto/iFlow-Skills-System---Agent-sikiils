#!/usr/bin/env python3
"""
远程主机连接器 - 连接和管理远程iFlow主机
老大，这个模块专门用来连接144主机进行任务分配测试
"""

import json
import subprocess
import time
import socket
from datetime import datetime
from typing import Dict, List, Any, Optional
from pathlib import Path

class RemoteHostConnector:
    """远程主机连接器"""
    
    def __init__(self):
        self.hosts_config = {
            "144-host": {
                "name": "144主机",
                "ip": "192.168.31.144",
                "port": 22,
                "username": "vinson",
                "role": "remote_agent",
                "capabilities": ["task_execution", "code_analysis", "data_processing"],
                "status": "offline"
            }
        }
        self.active_connections = {}
        
    def check_host_connectivity(self, host_id: str) -> Dict[str, Any]:
        """检查主机连通性"""
        try:
            if host_id not in self.hosts_config:
                return {"status": "error", "error": f"主机 {host_id} 不存在"}
            
            host_config = self.hosts_config[host_id]
            ip = host_config["ip"]
            
            print(f"🔍 检查主机 {host_id} ({ip}) 连通性...")
            
            # 1. Ping测试
            ping_result = subprocess.run(
                f"ping -c 3 -W 2 {ip}",
                shell=True,
                capture_output=True,
                text=True
            )
            
            if ping_result.returncode != 0:
                return {
                    "status": "error", 
                    "error": f"主机 {ip} 无法ping通",
                    "ping_output": ping_result.stderr
                }
            
            # 2. SSH端口测试
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(3)
                result = sock.connect_ex((ip, 22))
                sock.close()
                
                if result != 0:
                    return {
                        "status": "error",
                        "error": f"主机 {ip} SSH端口22无法连接"
                    }
            except Exception as e:
                return {
                    "status": "error",
                    "error": f"SSH连接测试失败: {str(e)}"
                }
            
            # 3. SSH连接测试
            ssh_test = subprocess.run(
                f'ssh -o ConnectTimeout=5 -o BatchMode=yes vinson@{ip} "echo SSH连接成功"',
                shell=True,
                capture_output=True,
                text=True
            )
            
            if ssh_test.returncode != 0:
                return {
                    "status": "error",
                    "error": f"SSH连接失败: {ssh_test.stderr.strip()}"
                }
            
            # 更新主机状态
            self.hosts_config[host_id]["status"] = "online"
            
            return {
                "status": "success",
                "host_id": host_id,
                "ip": ip,
                "message": "主机连接正常",
                "ping_output": ping_result.stdout,
                "ssh_output": ssh_test.stdout
            }
            
        except Exception as e:
            return {
                "status": "error",
                "error": f"连接检查失败: {str(e)}"
            }
    
    def check_iflow_on_remote_host(self, host_id: str) -> Dict[str, Any]:
        """检查远程主机上的iFlow状态"""
        try:
            if host_id not in self.hosts_config:
                return {"status": "error", "error": f"主机 {host_id} 不存在"}
            
            host_config = self.hosts_config[host_id]
            ip = host_config["ip"]
            
            print(f"🔍 检查主机 {host_id} 上的iFlow状态...")
            
            # 检查iFlow是否安装
            iflow_check = subprocess.run(
                f'ssh vinson@{ip} "which iflow"',
                shell=True,
                capture_output=True,
                text=True
            )
            
            if iflow_check.returncode != 0:
                return {
                    "status": "error",
                    "error": "远程主机上未安装iFlow"
                }
            
            # 检查iFlow版本
            version_check = subprocess.run(
                f'ssh vinson@{ip} "iflow --version"',
                shell=True,
                capture_output=True,
                text=True
            )
            
            # 检查iFlow进程
            process_check = subprocess.run(
                f'ssh vinson@{ip} "ps aux | grep iflow | grep -v grep | wc -l"',
                shell=True,
                capture_output=True,
                text=True
            )
            
            process_count = int(process_check.stdout.strip()) if process_check.stdout.strip().isdigit() else 0
            
            return {
                "status": "success",
                "host_id": host_id,
                "iflow_path": iflow_check.stdout.strip(),
                "version": version_check.stdout.strip() if version_check.returncode == 0 else "Unknown",
                "process_count": process_count,
                "message": f"iFlow运行正常，当前{process_count}个进程"
            }
            
        except Exception as e:
            return {
                "status": "error",
                "error": f"检查iFlow状态失败: {str(e)}"
            }
    
    def execute_remote_command(self, host_id: str, command: str, timeout: int = 30) -> Dict[str, Any]:
        """在远程主机上执行命令"""
        try:
            if host_id not in self.hosts_config:
                return {"status": "error", "error": f"主机 {host_id} 不存在"}
            
            host_config = self.hosts_config[host_id]
            ip = host_config["ip"]
            
            print(f"📤 在主机 {host_id} ({ip}) 执行命令: {command}")
            
            # 执行远程命令
            ssh_command = f'ssh -o ConnectTimeout={timeout} vinson@{ip} "{command}"'
            result = subprocess.run(
                ssh_command,
                shell=True,
                capture_output=True,
                text=True,
                timeout=timeout + 10
            )
            
            return {
                "status": "success" if result.returncode == 0 else "error",
                "host_id": host_id,
                "command": command,
                "stdout": result.stdout,
                "stderr": result.stderr,
                "returncode": result.returncode,
                "timestamp": datetime.now().isoformat()
            }
            
        except subprocess.TimeoutExpired:
            return {
                "status": "timeout",
                "host_id": host_id,
                "command": command,
                "error": f"命令执行超时 ({timeout}秒)",
                "timestamp": datetime.now().isoformat()
            }
        except Exception as e:
            return {
                "status": "error",
                "host_id": host_id,
                "command": command,
                "error": str(e),
                "timestamp": datetime.now().isoformat()
            }
    
    def create_remote_iflow_session(self, host_id: str, task_description: str) -> Dict[str, Any]:
        """在远程主机上创建iFlow会话"""
        try:
            print(f"🚀 在主机 {host_id} 创建iFlow会话: {task_description}")
            
            # 生成会话ID
            session_id = f"remote-{host_id}-{int(time.time())}"
            
            # 创建会话命令
            create_command = f'iflow -p "{task_description}" --session-id {session_id}'
            
            result = self.execute_remote_command(host_id, create_command, timeout=60)
            
            if result["status"] == "success":
                # 记录会话信息
                self.active_connections[session_id] = {
                    "host_id": host_id,
                    "session_id": session_id,
                    "task_description": task_description,
                    "created_at": datetime.now().isoformat(),
                    "status": "active"
                }
                
                return {
                    "status": "success",
                    "session_id": session_id,
                    "host_id": host_id,
                    "message": "远程会话创建成功",
                    "command_result": result
                }
            else:
                return {
                    "status": "error",
                    "error": f"创建远程会话失败: {result.get('stderr', 'Unknown error')}",
                    "command_result": result
                }
                
        except Exception as e:
            return {
                "status": "error",
                "error": f"创建远程会话异常: {str(e)}"
            }
    
    def assign_task_to_remote_host(self, host_id: str, task_command: str, session_id: str = None) -> Dict[str, Any]:
        """分配任务给远程主机"""
        try:
            print(f"📋 分配任务给主机 {host_id}: {task_command}")
            
            if session_id and session_id in self.active_connections:
                # 使用现有会话
                full_command = f'iflow --resume {session_id} -p "{task_command}"'
            else:
                # 创建新会话
                full_command = f'iflow -p "{task_command}"'
            
            result = self.execute_remote_command(host_id, full_command, timeout=300)
            
            return {
                "status": "success" if result["status"] == "success" else "error",
                "host_id": host_id,
                "session_id": session_id,
                "task_command": task_command,
                "result": result,
                "timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            return {
                "status": "error",
                "error": f"任务分配失败: {str(e)}"
            }
    
    def get_remote_host_status(self, host_id: str) -> Dict[str, Any]:
        """获取远程主机状态"""
        try:
            print(f"📊 获取主机 {host_id} 状态...")
            
            # 获取系统信息
            system_info = self.execute_remote_command(host_id, "uname -a")
            
            # 获取iFlow进程信息
            iflow_info = self.execute_remote_command(host_id, "ps aux | grep iflow | grep -v grep")
            
            # 获取内存使用情况
            memory_info = self.execute_remote_command(host_id, "free -h")
            
            # 获取磁盘使用情况
            disk_info = self.execute_remote_command(host_id, "df -h /")
            
            return {
                "status": "success",
                "host_id": host_id,
                "system_info": system_info,
                "iflow_processes": iflow_info,
                "memory_usage": memory_info,
                "disk_usage": disk_info,
                "active_sessions": len([s for s in self.active_connections.values() if s["host_id"] == host_id]),
                "timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            return {
                "status": "error",
                "error": f"获取主机状态失败: {str(e)}"
            }
    
    def list_all_hosts(self) -> Dict[str, Any]:
        """列出所有配置的主机"""
        return {
            "status": "success",
            "hosts": self.hosts_config,
            "active_connections": self.active_connections,
            "timestamp": datetime.now().isoformat()
        }

def main():
    """主函数 - 测试144主机连接"""
    import sys
    
    connector = RemoteHostConnector()
    
    print("🚀 远程主机连接器测试")
    print("=" * 50)
    
    # 1. 列出所有主机
    print("\n📋 配置的主机:")
    hosts = connector.list_all_hosts()
    for host_id, host_config in hosts["hosts"].items():
        status_icon = "🟢" if host_config["status"] == "online" else "🔴"
        print(f"  {status_icon} {host_id}: {host_config['name']} ({host_config['ip']}) - {host_config['status']}")
    
    # 2. 检查144主机连通性
    print("\n🔍 检查144主机连通性...")
    connectivity = connector.check_host_connectivity("144-host")
    if connectivity["status"] == "success":
        print(f"✅ {connectivity['message']}")
    else:
        print(f"❌ 连接失败: {connectivity['error']}")
        return
    
    # 3. 检查iFlow状态
    print("\n🔍 检查144主机iFlow状态...")
    iflow_status = connector.check_iflow_on_remote_host("144-host")
    if iflow_status["status"] == "success":
        print(f"✅ {iflow_status['message']}")
        print(f"   iFlow路径: {iflow_status['iflow_path']}")
        print(f"   版本: {iflow_status['version']}")
        print(f"   进程数: {iflow_status['process_count']}")
    else:
        print(f"❌ iFlow检查失败: {iflow_status['error']}")
        return
    
    # 4. 获取主机状态
    print("\n📊 获取144主机详细状态...")
    host_status = connector.get_remote_host_status("144-host")
    if host_status["status"] == "success":
        print("✅ 主机状态获取成功")
        if host_status["system_info"]["status"] == "success":
            print(f"   系统信息: {host_status['system_info']['stdout'].strip()}")
        if host_status["memory_usage"]["status"] == "success":
            print(f"   内存使用: {host_status['memory_usage']['stdout'].strip()}")
        print(f"   活跃会话数: {host_status['active_sessions']}")
    
    # 5. 创建测试会话
    print("\n🚀 创建测试会话...")
    test_task = "你好，这是一个来自本机的远程测试任务，请回复确认收到"
    session_result = connector.create_remote_iflow_session("144-host", test_task)
    
    if session_result["status"] == "success":
        session_id = session_result["session_id"]
        print(f"✅ 测试会话创建成功: {session_id}")
        
        # 6. 分配测试任务
        print("\n📋 分配测试任务...")
        task_result = connector.assign_task_to_remote_host(
            "144-host", 
            "请分析当前系统状态并简要报告", 
            session_id
        )
        
        if task_result["status"] == "success":
            print("✅ 任务分配成功")
            if task_result["result"]["stdout"]:
                print(f"   输出: {task_result['result']['stdout'][:200]}...")
        else:
            print(f"❌ 任务分配失败: {task_result['error']}")
    else:
        print(f"❌ 测试会话创建失败: {session_result['error']}")
    
    print("\n🎉 144主机连接测试完成！")

if __name__ == "__main__":
    main()