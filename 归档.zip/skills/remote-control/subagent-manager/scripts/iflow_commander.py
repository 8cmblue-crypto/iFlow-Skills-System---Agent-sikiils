#!/usr/bin/env python3
"""
iFlow命令执行器 - 核心命令控制模块
"""

import json
import subprocess
import time
from datetime import datetime
from typing import Dict, List, Any, Optional
from pathlib import Path

class iFlowCommander:
    """iFlow命令执行器"""
    
    def __init__(self, config_path: str = None):
        self.config = self._load_config(config_path)
        self.session_storage = Path(self.config["session"]["session_storage_path"])
        
    def _load_config(self, config_path: str) -> Dict[str, Any]:
        """加载配置文件"""
        if config_path is None:
            config_path = Path(__file__).parent.parent / "assets" / "config.json"
        
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except FileNotFoundError:
            return {
                "session": {"session_storage_path": "/home/vinson/.iflow/sessions"},
                "commands": {"builtin_commands": ["/session-start", "/session-end", "/understand"]}
            }
    
    def execute_command(self, command: str, session_id: str = None) -> Dict[str, Any]:
        """执行iFlow命令"""
        try:
            print(f"📤 执行命令: {command}")
            
            # 构建完整的iFlow命令
            if session_id:
                full_command = f'timeout 1800s iflow --resume {session_id} -p "{command}"'
            else:
                full_command = f'timeout 1800s iflow -p "{command}"'
            
            # 执行命令，增加超时时间
            result = subprocess.run(
                full_command,
                shell=True,
                capture_output=True,
                text=True
            )
            
            return {
                "status": "success" if result.returncode == 0 else "error",
                "command": command,
                "session_id": session_id,
                "stdout": result.stdout,
                "stderr": result.stderr,
                "returncode": result.returncode,
                "timestamp": datetime.now().isoformat()
            }
            
        except subprocess.TimeoutExpired:
            return {
                "status": "timeout",
                "command": command,
                "error": "Command execution timeout",
                "timestamp": datetime.now().isoformat()
            }
        except Exception as e:
            return {
                "status": "error",
                "command": command,
                "error": str(e),
                "timestamp": datetime.now().isoformat()
            }
    
    def list_sessions(self) -> Dict[str, Any]:
        """列出所有可用会话"""
        try:
            # 使用iflow --resume来获取会话列表
            result = subprocess.run(
                "iflow --resume",
                shell=True,
                capture_output=True,
                text=True,
                timeout=10
            )
            
            return {
                "status": "success",
                "sessions": self._parse_session_output(result.stdout),
                "raw_output": result.stdout,
                "timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            return {
                "status": "error",
                "error": str(e),
                "timestamp": datetime.now().isoformat()
            }
    
    def _parse_session_output(self, output: str) -> List[Dict[str, Any]]:
        """解析会话输出"""
        sessions = []
        lines = output.split('\n')
        
        for line in lines:
            if 'session-' in line:
                # 简单解析会话ID
                parts = line.split()
                for part in parts:
                    if part.startswith('session-'):
                        sessions.append({
                            "session_id": part,
                            "description": line.replace(part, "").strip(),
                            "status": "available"
                        })
        
        return sessions
    
    def switch_session(self, session_id: str) -> Dict[str, Any]:
        """切换到指定会话"""
        return self.execute_command(f"/switch_to_session {session_id}", session_id)
    
    def get_builtin_commands(self) -> List[str]:
        """获取内置命令列表"""
        return self.config["commands"]["builtin_commands"]
    
    def validate_command(self, command: str) -> Dict[str, Any]:
        """验证命令有效性"""
        builtin_commands = self.get_builtin_commands()
        
        if command.startswith('/'):
            # 斜杠命令
            if command in builtin_commands:
                return {"valid": True, "type": "builtin", "command": command}
            else:
                return {"valid": False, "error": f"Unknown builtin command: {command}"}
        else:
            # 普通命令
            return {"valid": True, "type": "regular", "command": command}

def main():
    """主函数"""
    import sys
    
    commander = iFlowCommander()
    
    # 处理命令行参数
    command_to_execute = None
    session_id = None
    
    if len(sys.argv) > 1:
        if sys.argv[1] == "--command" and len(sys.argv) > 2:
            command_to_execute = sys.argv[2]
        elif sys.argv[1] == "--help":
            print("🚀 iFlow命令执行器")
            print("=" * 40)
            print("用法:")
            print("  python3 iflow_commander.py --command <命令>")
            print("  python3 iflow_commander.py --help")
            print("\n可用内置命令:")
            for cmd in commander.get_builtin_commands():
                print(f"  {cmd}")
            return
        else:
            print("❌ 未知参数，使用 --help 查看帮助")
            return
    
    print("🚀 iFlow命令执行器")
    print("=" * 40)
    
    # 显示内置命令
    print("📋 可用内置命令:")
    for cmd in commander.get_builtin_commands():
        print(f"  {cmd}")
    
    # 列出会话
    print("\n📱 可用会话:")
    sessions = commander.list_sessions()
    if sessions["status"] == "success":
        for session in sessions["sessions"]:
            print(f"  • {session['session_id']} - {session.get('description', 'N/A')}")
    else:
        print(f"  ❌ 无法获取会话列表: {sessions.get('error', 'Unknown error')}")
    
    # 执行指定命令
    if command_to_execute:
        print(f"\n🔧 执行命令: {command_to_execute}")
        result = commander.execute_command(command_to_execute, session_id)
        print(f"📤 执行结果: {result}")

if __name__ == "__main__":
    main()
