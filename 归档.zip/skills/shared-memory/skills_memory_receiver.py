#!/usr/bin/env python3
"""
iFlow Skills记忆系统接收器
用于接收和存储skills相关的记忆数据
"""

import json
import os
import time
import hashlib
import threading
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Any, Optional
from dataclasses import dataclass, asdict
import logging

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class MemoryRecord:
    """记忆记录数据结构"""
    id: str
    content: str
    category: str  # skills, agent_config, task_result, etc.
    source: str    # 来源主机或系统
    timestamp: str
    tags: List[str]
    metadata: Dict[str, Any]
    checksum: str

class SkillsMemoryReceiver:
    """Skills记忆接收器"""
    
    def __init__(self, iflow_root: str = None):
        if iflow_root is None:
            self.iflow_root = Path.home() / ".iflow"
        else:
            self.iflow_root = Path(iflow_root)
        
        # 记忆存储目录
        self.memory_dir = self.iflow_root / "skills_memory"
        self.memory_dir.mkdir(exist_ok=True)
        
        # 子目录结构
        self.skills_dir = self.memory_dir / "skills"
        self.agents_dir = self.memory_dir / "agents"
        self.tasks_dir = self.memory_dir / "tasks"
        self.config_dir = self.memory_dir / "config"
        
        for dir_path in [self.skills_dir, self.agents_dir, self.tasks_dir, self.config_dir]:
            dir_path.mkdir(exist_ok=True)
        
        # 索引文件
        self.index_file = self.memory_dir / "memory_index.json"
        self.lock_file = self.memory_dir / ".receiver.lock"
        
        # 内存索引
        self.memory_index = self._load_memory_index()
        
        # 线程锁
        self._lock = threading.Lock()
        
        logger.info(f"Skills记忆接收器初始化完成: {self.memory_dir}")
    
    def _load_memory_index(self) -> Dict[str, Any]:
        """加载记忆索引"""
        try:
            if self.index_file.exists():
                with open(self.index_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
        except Exception as e:
            logger.warning(f"加载记忆索引失败: {e}")
        
        return {
            "version": "1.0",
            "created_at": datetime.now().isoformat(),
            "last_updated": datetime.now().isoformat(),
            "total_records": 0,
            "categories": {},
            "sources": {},
            "records": {}
        }
    
    def _save_memory_index(self):
        """保存记忆索引"""
        try:
            self.memory_index["last_updated"] = datetime.now().isoformat()
            with open(self.index_file, 'w', encoding='utf-8') as f:
                json.dump(self.memory_index, f, ensure_ascii=False, indent=2)
        except Exception as e:
            logger.error(f"保存记忆索引失败: {e}")
    
    def _generate_checksum(self, content: str) -> str:
        """生成内容校验和"""
        return hashlib.md5(content.encode('utf-8')).hexdigest()
    
    def _generate_record_id(self, content: str, source: str) -> str:
        """生成记录ID"""
        timestamp = datetime.now().isoformat()
        content_hash = hashlib.md5(content.encode('utf-8')).hexdigest()[:8]
        source_hash = hashlib.md5(source.encode('utf-8')).hexdigest()[:8]
        return f"mem_{timestamp[:10].replace('-', '')}_{content_hash}_{source_hash}"
    
    def _get_category_dir(self, category: str) -> Path:
        """获取分类目录"""
        category_map = {
            "skills": self.skills_dir,
            "agents": self.agents_dir,
            "tasks": self.tasks_dir,
            "config": self.config_dir
        }
        return category_map.get(category, self.memory_dir)
    
    def receive_memory(self, content: str, category: str = "skills", 
                      source: str = "unknown", tags: List[str] = None,
                      metadata: Dict[str, Any] = None) -> Dict[str, Any]:
        """接收记忆数据"""
        with self._lock:
            try:
                # 生成记录
                checksum = self._generate_checksum(content)
                record_id = self._generate_record_id(content, source)
                
                # 检查重复
                if record_id in self.memory_index["records"]:
                    return {
                        "success": False,
                        "error": "记忆记录已存在",
                        "record_id": record_id
                    }
                
                # 创建记忆记录
                record = MemoryRecord(
                    id=record_id,
                    content=content,
                    category=category,
                    source=source,
                    timestamp=datetime.now().isoformat(),
                    tags=tags or [],
                    metadata=metadata or {},
                    checksum=checksum
                )
                
                # 保存到文件
                category_dir = self._get_category_dir(category)
                record_file = category_dir / f"{record_id}.json"
                
                with open(record_file, 'w', encoding='utf-8') as f:
                    json.dump(asdict(record), f, ensure_ascii=False, indent=2)
                
                # 更新索引
                self.memory_index["records"][record_id] = {
                    "category": category,
                    "source": source,
                    "timestamp": record.timestamp,
                    "tags": record.tags,
                    "file_path": str(record_file.relative_to(self.memory_dir)),
                    "checksum": checksum
                }
                
                # 更新统计
                self.memory_index["total_records"] += 1
                
                if category not in self.memory_index["categories"]:
                    self.memory_index["categories"][category] = 0
                self.memory_index["categories"][category] += 1
                
                if source not in self.memory_index["sources"]:
                    self.memory_index["sources"][source] = 0
                self.memory_index["sources"][source] += 1
                
                # 保存索引
                self._save_memory_index()
                
                logger.info(f"记忆接收成功: {record_id} ({category})")
                
                return {
                    "success": True,
                    "record_id": record_id,
                    "category": category,
                    "timestamp": record.timestamp
                }
                
            except Exception as e:
                logger.error(f"接收记忆失败: {e}")
                return {
                    "success": False,
                    "error": str(e)
                }
    
    def search_memory(self, query: str = None, category: str = None,
                     source: str = None, tags: List[str] = None,
                     limit: int = 50) -> List[Dict[str, Any]]:
        """搜索记忆"""
        results = []
        
        for record_id, record_info in self.memory_index["records"].items():
            # 应用过滤条件
            if category and record_info["category"] != category:
                continue
            
            if source and record_info["source"] != source:
                continue
            
            if tags and not any(tag in record_info["tags"] for tag in tags):
                continue
            
            # 读取记录内容
            try:
                record_file = self.memory_dir / record_info["file_path"]
                with open(record_file, 'r', encoding='utf-8') as f:
                    record = json.load(f)
                
                # 文本搜索
                if query:
                    content = record.get("content", "").lower()
                    if query.lower() not in content:
                        continue
                
                results.append(record)
                
                if len(results) >= limit:
                    break
                    
            except Exception as e:
                logger.warning(f"读取记忆记录失败 {record_id}: {e}")
        
        return results
    
    def get_memory_stats(self) -> Dict[str, Any]:
        """获取记忆统计信息"""
        return {
            "total_records": self.memory_index["total_records"],
            "categories": dict(self.memory_index["categories"]),
            "sources": dict(self.memory_index["sources"]),
            "last_updated": self.memory_index["last_updated"],
            "memory_dir": str(self.memory_dir)
        }
    
    def export_memory(self, output_file: str = None, category: str = None) -> Dict[str, Any]:
        """导出记忆数据"""
        try:
            records = self.search_memory(category=category, limit=10000)
            
            if not output_file:
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                output_file = f"skills_memory_export_{timestamp}.json"
            
            export_data = {
                "export_time": datetime.now().isoformat(),
                "total_records": len(records),
                "category": category,
                "records": records
            }
            
            with open(output_file, 'w', encoding='utf-8') as f:
                json.dump(export_data, f, ensure_ascii=False, indent=2)
            
            return {
                "success": True,
                "output_file": output_file,
                "total_records": len(records)
            }
            
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    def cleanup_old_memories(self, days: int = 30) -> Dict[str, Any]:
        """清理旧记忆"""
        cutoff_time = datetime.now().timestamp() - (days * 24 * 3600)
        removed_count = 0
        
        with self._lock:
            try:
                records_to_remove = []
                
                for record_id, record_info in self.memory_index["records"].items():
                    record_time = datetime.fromisoformat(record_info["timestamp"]).timestamp()
                    if record_time < cutoff_time:
                        records_to_remove.append(record_id)
                
                # 删除文件和索引
                for record_id in records_to_remove:
                    record_info = self.memory_index["records"][record_id]
                    record_file = self.memory_dir / record_info["file_path"]
                    
                    if record_file.exists():
                        record_file.unlink()
                    
                    del self.memory_index["records"][record_id]
                    removed_count += 1
                
                # 更新统计
                self.memory_index["total_records"] -= removed_count
                self._save_memory_index()
                
                logger.info(f"清理旧记忆完成: 删除 {removed_count} 条记录")
                
                return {
                    "success": True,
                    "removed_count": removed_count
                }
                
            except Exception as e:
                logger.error(f"清理旧记忆失败: {e}")
                return {
                    "success": False,
                    "error": str(e)
                }

def main():
    """主函数演示"""
    print("🧠 Skills记忆系统接收器演示")
    print("=" * 50)
    
    # 创建接收器
    receiver = SkillsMemoryReceiver()
    
    # 接收示例记忆
    sample_memories = [
        {
            "content": "任务分配协调技能：支持8个Agent并行工作，通过SSH远程执行任务",
            "category": "skills",
            "source": "main_host",
            "tags": ["task_coordination", "agent_management", "remote_execution"],
            "metadata": {"priority": "high", "version": "1.0"}
        },
        {
            "content": "小张-市场领导地位分析专家：负责市场分析、竞争研究、领导地位评估",
            "category": "agents",
            "source": "144_host",
            "tags": ["market_analysis", "leadership", "expert_agent"],
            "metadata": {"host": "192.168.31.144", "capabilities": ["市场分析", "竞争研究"]}
        },
        {
            "content": "双主机协调任务：144主机作为Primary，77主机作为Secondary",
            "category": "config",
            "source": "system",
            "tags": ["host_config", "coordination", "multi_host"],
            "metadata": {"hosts": ["192.168.31.144", "192.168.31.77"]}
        }
    ]
    
    print(f"📥 接收 {len(sample_memories)} 条记忆...")
    
    for memory in sample_memories:
        result = receiver.receive_memory(**memory)
        if result["success"]:
            print(f"✅ {result['record_id']} - {memory['category']}")
        else:
            print(f"❌ {memory['category']}: {result.get('error', 'Unknown')}")
    
    # 显示统计信息
    stats = receiver.get_memory_stats()
    print(f"\n📊 记忆统计:")
    print(f"   总记录数: {stats['total_records']}")
    print(f"   分类统计: {stats['categories']}")
    print(f"   来源统计: {stats['sources']}")
    
    # 搜索记忆
    print(f"\n🔍 搜索包含'Agent'的记忆:")
    agent_memories = receiver.search_memory(query="Agent", limit=5)
    for memory in agent_memories:
        print(f"   - {memory['id']}: {memory['content'][:50]}...")
    
    print(f"\n🎉 Skills记忆系统接收器演示完成!")

if __name__ == "__main__":
    main()