#!/usr/bin/env python3
"""
记忆技能自启动器
第一次使用时自动初始化记忆系统并启动后台进程
"""

import os
import sys
import json
import time
import subprocess
import signal
from pathlib import Path

class MemorySkillLauncher:
    def __init__(self):
        self.skill_dir = Path(__file__).parent.parent
        self.memory_dir = self.skill_dir / "memory_data"
        self.config_file = self.skill_dir / "assets" / "config.json"
        self.pid_file = self.skill_dir / "memory_daemon.pid"
        self.memory_file = self.memory_dir / "user_memories.json"
        
        # 确保目录存在
        self.memory_dir.mkdir(exist_ok=True)
    
    def is_first_run(self):
        """检查是否是第一次运行"""
        return not self.memory_file.exists() or not self.config_file.exists()
    
    def initialize_memory_system(self):
        """初始化记忆系统"""
        print("🚀 首次运行，正在初始化记忆系统...")
        
        # 1. 复制现有记忆到技能目录
        source_memory = Path("/vol1/1000/iflow/user_memories.json")
        if source_memory.exists():
            import shutil
            shutil.copy2(source_memory, self.memory_file)
            print(f"✅ 已复制现有记忆到技能目录: {self.memory_file}")
        
        # 2. 创建技能本地配置
        config = {
            "name": "shared-memory-system",
            "version": "1.0.0",
            "memory_file": str(self.memory_file),
            "skill_dir": str(self.skill_dir),
            "initialized": True,
            "initialized_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            "user_preference": {
                "name": "林浩",
                "preferred_name": "老大"
            }
        }
        
        with open(self.config_file, 'w', encoding='utf-8') as f:
            json.dump(config, f, ensure_ascii=False, indent=2)
        
        print("✅ 记忆系统初始化完成")
        return config
    
    def start_memory_daemon(self):
        """启动记忆守护进程"""
        if self.is_daemon_running():
            print("🧠 记忆守护进程已在运行")
            return True
        
        print("🔄 启动记忆守护进程...")
        
        # 创建守护进程脚本
        daemon_script = self.skill_dir / "scripts" / "memory_daemon.py"
        self._create_daemon_script(daemon_script)
        
        # 启动守护进程
        try:
            process = subprocess.Popen([
                sys.executable, str(daemon_script)
            ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            
            # 保存PID
            with open(self.pid_file, 'w') as f:
                f.write(str(process.pid))
            
            time.sleep(1)  # 等待进程启动
            
            if process.poll() is None:
                print("✅ 记忆守护进程启动成功")
                return True
            else:
                print("❌ 记忆守护进程启动失败")
                return False
                
        except Exception as e:
            print(f"❌ 启动守护进程失败: {str(e)}")
            return False
    
    def _create_daemon_script(self, daemon_script):
        """创建守护进程脚本"""
        daemon_content = f'''#!/usr/bin/env python3
"""
记忆守护进程
提供持久的记忆服务
"""

import sys
import time
import json
import signal
from pathlib import Path

# 添加技能路径
sys.path.insert(0, "{self.skill_dir}")
sys.path.insert(0, "/vol1/1000/iflow")

class MemoryDaemon:
    def __init__(self):
        self.skill_dir = Path("{self.skill_dir}")
        self.memory_file = Path("{self.memory_file}")
        self.running = True
        
        # 注册信号处理
        signal.signal(signal.SIGTERM, self._signal_handler)
        signal.signal(signal.SIGINT, self._signal_handler)
    
    def _signal_handler(self, signum, frame):
        """信号处理器"""
        print(f"\\n🛑 收到信号 {{signum}}，正在关闭记忆守护进程...")
        self.running = False
    
    def run(self):
        """运行守护进程"""
        print("🧠 记忆守护进程启动")
        
        while self.running:
            try:
                # 检查记忆文件状态
                if self.memory_file.exists():
                    with open(self.memory_file, 'r', encoding='utf-8') as f:
                        memories = json.load(f)
                    
                    # 可以在这里添加记忆维护逻辑
                    # 比如清理过期记忆、优化存储等
                    
                time.sleep(30)  # 每30秒检查一次
                
            except Exception as e:
                print(f"❌ 守护进程错误: {{str(e)}}")
                time.sleep(5)
        
        print("🧠 记忆守护进程已关闭")

if __name__ == "__main__":
    daemon = MemoryDaemon()
    daemon.run()
'''
        
        with open(daemon_script, 'w', encoding='utf-8') as f:
            f.write(daemon_content)
        
        os.chmod(daemon_script, 0o755)
    
    def is_daemon_running(self):
        """检查守护进程是否运行"""
        if not self.pid_file.exists():
            return False
        
        try:
            with open(self.pid_file, 'r') as f:
                pid = int(f.read().strip())
            
            # 检查进程是否存在
            os.kill(pid, 0)
            return True
        except (OSError, ValueError):
            return False
    
    def stop_daemon(self):
        """停止守护进程"""
        if not self.pid_file.exists():
            return
        
        try:
            with open(self.pid_file, 'r') as f:
                pid = int(f.read().strip())
            
            os.kill(pid, signal.SIGTERM)
            time.sleep(1)
            
            # 删除PID文件
            self.pid_file.unlink()
            print("🛑 记忆守护进程已停止")
            
        except (OSError, ValueError):
            pass
    
    def get_memory_client(self):
        """获取记忆客户端"""
        client_script = self.skill_dir / "scripts" / "memory_client.py"
        sys.path.insert(0, str(self.skill_dir))
        sys.path.insert(0, "/vol1/1000/iflow")
        
        try:
            from memory_client import MemoryClient
            return MemoryClient(str(self.memory_file))
        except ImportError:
            # 创建简化的内存客户端
            return SimpleMemoryClient(str(self.memory_file))

class SimpleMemoryClient:
    """简化的记忆客户端"""
    def __init__(self, memory_file):
        self.memory_file = Path(memory_file)
    
    def recall_memory(self, question):
        """回忆记忆"""
        try:
            if not self.memory_file.exists():
                return {"use_memory": False, "memory_response": "记忆文件不存在"}
            
            with open(self.memory_file, 'r', encoding='utf-8') as f:
                memories = json.load(f)
            
            # 简单的关键词匹配
            question_lower = question.lower()
            
            # 检查称呼偏好
            for key, memory in memories.items():
                if ("称呼" in question_lower or "叫什么" in question_lower) and ("preferred_name" in key or "name_preference" in key):
                    return {
                        "use_memory": True,
                        "memory_response": f"根据记忆，{memory['value']}"
                    }
                
                # 检查姓名
                if ("名字" in question_lower or "叫什么" in question_lower) and ("user_name" in key):
                    return {
                        "use_memory": True,
                        "memory_response": f"根据记忆，您的姓名是{memory['value']}"
                    }
            
            return {"use_memory": False, "memory_response": "没有找到相关记忆"}
            
        except Exception as e:
            return {"use_memory": False, "memory_response": f"记忆检索错误: {str(e)}"}
    
    def store_memory(self, key, value, category="user_preference"):
        """存储记忆"""
        try:
            # 加载现有记忆
            memories = {}
            if self.memory_file.exists():
                with open(self.memory_file, 'r', encoding='utf-8') as f:
                    memories = json.load(f)
            
            # 添加新记忆
            memories[key] = {
                "value": value,
                "category": category,
                "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
                "metadata": {"source": "memory_skill"}
            }
            
            # 保存记忆
            with open(self.memory_file, 'w', encoding='utf-8') as f:
                json.dump(memories, f, ensure_ascii=False, indent=2)
            
            return {"success": True, "message": f"记忆 '{key}' 已存储"}
            
        except Exception as e:
            return {"success": False, "error": str(e)}

def main():
    """主函数"""
    launcher = MemorySkillLauncher()
    
    # 检查是否第一次运行
    if launcher.is_first_run():
        config = launcher.initialize_memory_system()
        print("🎉 记忆技能初始化完成！")
    
    # 启动守护进程
    launcher.start_memory_daemon()
    
    # 获取记忆客户端
    client = launcher.get_memory_client()
    
    # 处理命令
    if len(sys.argv) > 1:
        command = sys.argv[1].lower()
        
        if command == "recall" and len(sys.argv) > 2:
            question = " ".join(sys.argv[2:])
            result = client.recall_memory(question)
            
            if result["use_memory"]:
                print(f"🧠 {result['memory_response']}")
            else:
                print("❌ 没有找到相关记忆")
        
        elif command == "store" and len(sys.argv) > 3:
            key = sys.argv[2]
            value = " ".join(sys.argv[3:])
            result = client.store_memory(key, value)
            
            if result["success"]:
                print(f"✅ {result['message']}")
            else:
                print(f"❌ 存储失败: {result['error']}")
        
        elif command == "status":
            print("🧠 记忆技能状态:")
            print(f"  技能目录: {launcher.skill_dir}")
            print(f"  记忆文件: {launcher.memory_file}")
            print(f"  守护进程: {'运行中' if launcher.is_daemon_running() else '未运行'}")
            
            # 显示记忆统计
            if launcher.memory_file.exists():
                with open(launcher.memory_file, 'r', encoding='utf-8') as f:
                    memories = json.load(f)
                print(f"  记忆数量: {len(memories)}")
        
        elif command == "stop":
            launcher.stop_daemon()
        
        else:
            print("❌ 未知命令")
    else:
        print("🧠 记忆技能自启动器")
        print("用法:")
        print("  python3 auto_launcher.py recall <问题>")
        print("  python3 auto_launcher.py store <key> <value>")
        print("  python3 auto_launcher.py status")
        print("  python3 auto_launcher.py stop")

if __name__ == "__main__":
    main()
