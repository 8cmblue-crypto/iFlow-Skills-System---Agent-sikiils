#!/usr/bin/env python3
"""
记忆技能性能分析工具
测试记忆系统的性能表现和容量限制
"""

import json
import time
import os
import sys
from pathlib import Path

class MemoryPerformanceAnalyzer:
    def __init__(self):
        self.skill_dir = Path(__file__).parent.parent
        self.memory_file = self.skill_dir / "memory_data" / "user_memories.json"
        
    def analyze_current_performance(self):
        """分析当前记忆系统性能"""
        print("🔍 当前记忆系统性能分析")
        print("=" * 50)
        
        if not self.memory_file.exists():
            print("❌ 记忆文件不存在")
            return
        
        # 文件大小
        file_size = self.memory_file.stat().st_size / 1024  # KB
        print(f"📁 记忆文件大小: {file_size:.1f}KB")
        
        # 记忆数量
        with open(self.memory_file, 'r', encoding='utf-8') as f:
            memories = json.load(f)
        
        print(f"📝 记忆条数: {len(memories)}")
        
        # 分类统计
        categories = {}
        for key, memory in memories.items():
            category = memory.get('category', 'unknown')
            categories[category] = categories.get(category, 0) + 1
        
        print("📊 记忆分类:")
        for category, count in categories.items():
            print(f"  {category}: {count}条")
        
        # 测试检索性能
        if len(memories) > 0:
            self._test_search_performance(memories)
    
    def _test_search_performance(self, memories):
        """测试搜索性能"""
        print("\n🧠 记忆检索性能测试")
        print("-" * 30)
        
        # 模拟关键词搜索
        test_queries = [
            "我应该怎么称呼自己？",
            "我叫什么名字？",
            "我在哪里工作？",
            "我会什么技能？"
        ]
        
        total_time = 0
        successful_searches = 0
        
        for query in test_queries:
            start_time = time.time()
            
            # 简单的关键词匹配测试
            query_lower = query.lower()
            found_count = 0
            
            for key, memory in memories.items():
                if any(word in memory['value'].lower() for word in query_lower.split()):
                    found_count += 1
            
            search_time = (time.time() - start_time) * 1000
            total_time += search_time
            
            if found_count > 0:
                successful_searches += 1
            
            print(f"  \"{query}\": {search_time:.2f}ms, 找到{found_count}条")
        
        avg_time = total_time / len(test_queries)
        print(f"\n📈 平均检索时间: {avg_time:.2f}ms")
        print(f"✅ 成功率: {successful_searches}/{len(test_queries)}")
    
    def simulate_capacity_test(self):
        """模拟容量测试"""
        print("\n🧪 记忆容量模拟测试")
        print("=" * 50)
        
        # 基于当前记忆条目大小推算
        if self.memory_file.exists():
            current_size = self.memory_file.stat().st_size
            with open(self.memory_file, 'r', encoding='utf-8') as f:
                current_memories = json.load(f)
            current_count = len(current_memories)
            
            if current_count > 0:
                avg_size_per_memory = current_size / current_count
                
                print(f"📏 当前平均每条记忆大小: {avg_size_per_memory:.0f}字节")
                
                # 推算不同数量的文件大小
                test_scenarios = [
                    (1000, "1K条记忆"),
                    (5000, "5K条记忆"),
                    (10000, "1W条记忆"),
                    (50000, "5W条记忆"),
                    (100000, "10W条记忆")
                ]
                
                print("\n📊 容量预估:")
                for count, description in test_scenarios:
                    estimated_size = (count * avg_size_per_memory) / 1024  # KB
                    estimated_size_mb = estimated_size / 1024  # MB
                    
                    if estimated_size_mb < 1:
                        print(f"  {description}: {estimated_size:.1f}KB")
                    else:
                        print(f"  {description}: {estimated_size_mb:.1f}MB")
                    
                    # 性能警告
                    if estimated_size_mb > 50:
                        print(f"    ⚠️  文件较大，建议优化")
    
    def performance_recommendations(self):
        """性能优化建议"""
        print("\n💡 性能优化建议")
        print("=" * 50)
        
        recommendations = [
            {
                "title": "记忆数量控制",
                "desc": "建议控制在10,000条以内，超过后考虑分层存储",
                "priority": "高"
            },
            {
                "title": "文件大小监控",
                "desc": "当文件超过10MB时，建议启用记忆压缩",
                "priority": "中"
            },
            {
                "title": "定期清理",
                "desc": "定期清理重复、过期、无价值的记忆",
                "priority": "中"
            },
            {
                "title": "索引优化",
                "desc": "为高频查询的记忆建立索引",
                "priority": "低"
            },
            {
                "title": "分片存储",
                "desc": "大量记忆可按类别分片存储",
                "priority": "低"
            }
        ]
        
        for rec in recommendations:
            priority_icon = {"高": "🔴", "中": "🟡", "低": "🟢"}
            print(f"{priority_icon[rec['priority']]} {rec['title']}")
            print(f"   {rec['desc']}")
            print()
    
    def benchmark_comparison(self):
        """与常见系统对比"""
        print("\n🏆 性能对比参考")
        print("=" * 50)
        
        comparisons = [
            {"system": "当前记忆技能", "records": 42, "size": "15KB", "search": "<1ms"},
            {"system": "浏览器Cookie", "records": 3000, "size": "5MB", "search": "<5ms"},
            {"system": "SQLite数据库", "records": "100K+", "size": "10MB+", "search": "<10ms"},
            {"system": "Redis缓存", "records": "1M+", "size": "100MB+", "search": "<1ms"}
        ]
        
        print(f"{'系统':<15} {'记录数':<10} {'大小':<10} {'搜索时间':<10}")
        print("-" * 50)
        
        for comp in comparisons:
            print(f"{comp['system']:<15} {comp['records']:<10} {comp['size']:<10} {comp['search']:<10}")
    
    def run_full_analysis(self):
        """运行完整分析"""
        self.analyze_current_performance()
        self.simulate_capacity_test()
        self.performance_recommendations()
        self.benchmark_comparison()

def main():
    """主函数"""
    analyzer = MemoryPerformanceAnalyzer()
    analyzer.run_full_analysis()

if __name__ == "__main__":
    main()
