#!/usr/bin/env python3
"""
记忆客户端 - 技能本地化版本
直接操作技能目录内的记忆文件
"""

import json
import time
import os
from pathlib import Path

class MemoryClient:
    def __init__(self, memory_file_path=None):
        if memory_file_path is None:
            # 默认使用技能目录内的记忆文件
            skill_dir = Path(__file__).parent.parent
            memory_dir = skill_dir / "memory_data"
            memory_file_path = memory_dir / "user_memories.json"
        
        self.memory_file = Path(memory_file_path)
        self.memory_dir = self.memory_file.parent
        
        # 确保记忆目录存在
        self.memory_dir.mkdir(exist_ok=True)
    
    def load_memories(self):
        """加载记忆"""
        if not self.memory_file.exists():
            return {}
        
        try:
            with open(self.memory_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        except (json.JSONDecodeError, FileNotFoundError):
            return {}
    
    def save_memories(self, memories):
        """保存记忆"""
        with open(self.memory_file, 'w', encoding='utf-8') as f:
            json.dump(memories, f, ensure_ascii=False, indent=2)
    
    def recall_memory(self, question):
        """智能回忆记忆"""
        memories = self.load_memories()
        
        if not memories:
            return {"use_memory": False, "memory_response": "暂无记忆"}
        
        question_lower = question.lower()
        
        # 1. 检查称呼偏好
        if any(word in question_lower for word in ["称呼", "叫什么", "怎么叫"]):
            for key, memory in memories.items():
                if "preferred_name" in key.lower() or "称呼偏好" in key.lower():
                    return {
                        "use_memory": True,
                        "memory_response": f"根据记忆，{memory['value']}",
                        "source": "skill_memory"
                    }
        
        # 2. 检查姓名
        if any(word in question_lower for word in ["名字", "叫什么", "姓名"]):
            for key, memory in memories.items():
                if "user_name" in key.lower() or "姓名" in key.lower():
                    return {
                        "use_memory": True,
                        "memory_response": f"根据记忆，您的姓名是{memory['value']}",
                        "source": "skill_memory"
                    }
        
        # 3. 检查工作信息
        if any(word in question_lower for word in ["公司", "工作", "单位"]):
            for key, memory in memories.items():
                if "公司" in memory['value'] or "工作" in memory['value']:
                    return {
                        "use_memory": True,
                        "memory_response": f"根据记忆，{memory['value']}",
                        "source": "skill_memory"
                    }
        
        # 4. 检查技能
        if any(word in question_lower for word in ["技能", "会什么", "能力"]):
            skills = []
            for key, memory in memories.items():
                if "技能" in memory['value'] or "会" in memory['value']:
                    skills.append(memory['value'])
            
            if skills:
                return {
                    "use_memory": True,
                    "memory_response": f"根据记忆，您掌握以下技能: {', '.join(skills)}",
                    "source": "skill_memory"
                }
        
        # 5. 关键词搜索
        for key, memory in memories.items():
            if any(word in question_lower for word in memory['value'].lower().split()):
                return {
                    "use_memory": True,
                    "memory_response": f"根据记忆，{memory['value']}",
                    "source": "skill_memory"
                }
        
        return {"use_memory": False, "memory_response": "没有找到相关记忆"}
    
    def store_memory(self, key, value, category="user_preference"):
        """存储记忆"""
        memories = self.load_memories()
        
        memories[key] = {
            "value": value,
            "category": category,
            "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            "metadata": {
                "source": "memory_skill",
                "skill_version": "1.0.0"
            }
        }
        
        self.save_memories(memories)
        
        return {
            "success": True,
            "message": f"记忆 '{key}' 已存储到技能目录",
            "location": str(self.memory_file)
        }
    
    def get_status(self):
        """获取记忆状态"""
        memories = self.load_memories()
        
        # 统计记忆类型
        categories = {}
        user_name = None
        preferred_name = None
        
        for key, memory in memories.items():
            category = memory.get("category", "unknown")
            categories[category] = categories.get(category, 0) + 1
            
            if "user_name" in key.lower():
                user_name = memory["value"]
            elif "preferred_name" in key.lower():
                preferred_name = memory["value"]
        
        return {
            "total_memories": len(memories),
            "categories": categories,
            "user_name": user_name,
            "preferred_name": preferred_name,
            "memory_location": str(self.memory_file),
            "skill_initialized": True
        }
    
    def search_memories(self, query):
        """搜索记忆"""
        memories = self.load_memories()
        results = []
        
        query_lower = query.lower()
        
        for key, memory in memories.items():
            if (query_lower in key.lower() or 
                query_lower in memory["value"].lower()):
                results.append({
                    "key": key,
                    "memory": memory
                })
        
        return {
            "success": True,
            "results": results,
            "count": len(results)
        }
    
    def process_conversation(self, user_input, ai_response):
        """处理对话并提取记忆"""
        memories = self.load_memories()
        extracted = []
        
        user_input_lower = user_input.lower()
        
        # 提取姓名
        if "我叫" in user_input:
            import re
            match = re.search(r'我叫([^\n，。！？]+)', user_input)
            if match:
                name = match.group(1).strip()
                key = f"extracted_name_{int(time.time())}"
                self.store_memory(key, f"用户的姓名是{name}", "personal")
                extracted.append(f"用户姓名: {name}")
        
        # 提取称呼偏好
        if "叫我" in user_input or "称呼我" in user_input:
            import re
            match = re.search(r'(?:叫我|称呼我)([^\n，。！？]+)', user_input)
            if match:
                preference = match.group(1).strip()
                key = f"extracted_preference_{int(time.time())}"
                self.store_memory(key, f"用户希望被称为{preference}", "preference")
                extracted.append(f"称呼偏好: {preference}")
        
        # 提取工作信息
        if "在" in user_input and ("工作" in user_input or "公司" in user_input):
            import re
            match = re.search(r'在(.+?)(?:工作|公司)', user_input)
            if match:
                company = match.group(1).strip()
                key = f"extracted_work_{int(time.time())}"
                self.store_memory(key, f"用户在{company}工作", "work")
                extracted.append(f"工作单位: {company}")
        
        return {
            "success": True,
            "memories_found": len(extracted),
            "extracted_memories": extracted
        }

def main():
    """命令行接口"""
    import sys
    
    if len(sys.argv) < 2:
        print("记忆客户端 - 技能本地化版本")
        print("用法:")
        print("  python3 memory_client.py recall <问题>")
        print("  python3 memory_client.py store <key> <value>")
        print("  python3 memory_client.py status")
        print("  python3 memory_client.py search <查询>")
        print("  python3 memory_client.py process <用户输入>")
        return
    
    client = MemoryClient()
    command = sys.argv[1].lower()
    
    if command == "recall" and len(sys.argv) > 2:
        question = " ".join(sys.argv[2:])
        result = client.recall_memory(question)
        
        if result["use_memory"]:
            print(f"🧠 {result['memory_response']}")
        else:
            print("❌ 没有找到相关记忆")
    
    elif command == "store" and len(sys.argv) > 3:
        key = sys.argv[2]
        value = " ".join(sys.argv[3:])
        result = client.store_memory(key, value)
        
        if result["success"]:
            print(f"✅ {result['message']}")
        else:
            print(f"❌ 存储失败")
    
    elif command == "status":
        status = client.get_status()
        print("🧠 记忆系统状态:")
        print(f"  总记忆数: {status['total_memories']}")
        print(f"  记忆位置: {status['memory_location']}")
        print(f"  用户姓名: {status['user_name'] or '未设置'}")
        print(f"  偏好称呼: {status['preferred_name'] or '未设置'}")
        print(f"  记忆分类: {status['categories']}")
    
    elif command == "search" and len(sys.argv) > 2:
        query = " ".join(sys.argv[2:])
        result = client.search_memories(query)
        
        if result["success"] and result["count"] > 0:
            print(f"🔍 找到 {result['count']} 条相关记忆:")
            for item in result["results"]:
                print(f"  {item['key']}: {item['memory']['value']}")
        else:
            print("❌ 没有找到相关记忆")
    
    elif command == "process" and len(sys.argv) > 2:
        user_input = " ".join(sys.argv[2:])
        result = client.process_conversation(user_input, "AI回复")
        
        if result["success"] and result["memories_found"] > 0:
            print(f"📝 提取了 {result['memories_found']} 条记忆:")
            for memory in result["extracted_memories"]:
                print(f"  - {memory}")
        else:
            print("📝 本次对话无新记忆需要提取")
    
    else:
        print("❌ 未知命令或参数不足")

if __name__ == "__main__":
    main()
