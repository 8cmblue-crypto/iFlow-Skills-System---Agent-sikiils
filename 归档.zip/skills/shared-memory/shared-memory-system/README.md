# 记忆技能使用说明

## 🎯 快速开始

这个记忆技能可以让任何iflow实例共享记忆系统！

### 方法一：直接使用脚本
```bash
# 查看记忆状态
PYTHONPATH=/vol1/1000/iflow python3 /vol1/1000/iflow/skills/shared-memory-system/scripts/simple_memory_skill.py status

# 智能回忆记忆
PYTHONPATH=/vol1/1000/iflow python3 /vol1/1000/iflow/skills/shared-memory-system/scripts/simple_memory_skill.py recall "我应该怎么称呼自己？"

# 存储新记忆
PYTHONPATH=/vol1/1000/iflow python3 /vol1/1000/iflow/skills/shared-memory-system/scripts/simple_memory_skill.py store "新信息" "内容"
```

### 方法二：复制整个技能文件夹
```bash
# 复制技能到任何位置
cp -r /vol1/1000/iflow/skills/shared-memory-system /your/iflow/location/skills/

# 在新位置使用
cd /your/iflow/location
PYTHONPATH=/vol1/1000/iflow python3 skills/shared-memory-system/scripts/simple_memory_skill.py status
```

### 方法三：集成到Python代码
```python
import sys
sys.path.insert(0, '/vol1/1000/iflow')

from skills.shared_memory_system.scripts.simple_memory_skill import recall_memory, store_memory

# 使用记忆功能
result = recall_memory("我叫什么名字？")
if result["use_memory"]:
    print(result["memory_response"])
```

## 📁 技能结构
```
shared-memory-system/
├── SKILL.md                    # 技能说明文档
├── scripts/
│   ├── memory_skill.py         # 完整功能脚本
│   └── simple_memory_skill.py  # 简化版脚本（推荐）
├── references/
│   └── QUICK_REFERENCE.md      # 快速参考
└── assets/
    └── config.json             # 配置文件
```

## ✅ 测试结果
- ✅ 记忆状态查询正常
- ✅ 智能回忆功能正常
- ✅ 跨实例访问正常
- ✅ 技能结构完整

## 🎪 使用场景
1. **新iflow实例启动** - 复制技能文件夹即可获得记忆能力
2. **多实例协作** - 所有实例共享同一记忆库
3. **个性化AI** - 记住用户偏好和习惯
4. **知识管理** - 持久化重要信息

## 💡 核心优势
- **零配置** - 复制即用，无需安装
- **跨实例** - 所有iflow实例共享记忆
- **智能检索** - Agent Zero风格语义搜索
- **有温度记忆** - 自然语言描述，避免机械标签

老大，现在您只需要复制这个技能文件夹到任何iflow实例，就能立即获得完整的记忆功能！