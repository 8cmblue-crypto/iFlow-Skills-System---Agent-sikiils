
#!/usr/bin/env python3
"""
iFlow记忆客户端 - 在任何iflow实例中使用共享记忆
"""

import json
import subprocess
from typing import Dict, Any, List, Optional

class SharedMemoryClient:
    def __init__(self):
        self.config_file = "/vol1/1000/iflow/iflow_memory_config.json"
        self.load_config()
    
    def load_config(self):
        """加载配置"""
        try:
            with open(self.config_file, 'r', encoding='utf-8') as f:
                self.config = json.load(f)
        except Exception as e:
            print(f"❌ 加载配置失败: {e}")
            self.config = {}
    
    def call_mcp_tool(self, tool_name: str, arguments: Dict[str, Any]) -> Dict[str, Any]:
        """调用MCP工具"""
        try:
            # 这里应该使用真正的MCP客户端
            # 暂时用简化版本
            cmd = [
                "python3", "/vol1/1000/iflow/memory_mcp_client.py",
                tool_name, json.dumps(arguments)
            ]
            
            result = subprocess.run(cmd, capture_output=True, text=True)
            
            if result.returncode == 0:
                return json.loads(result.stdout)
            else:
                return {"error": result.stderr}
                
        except Exception as e:
            return {"error": str(e)}
    
    def store_memory(self, key: str, value: str, category: str = "general") -> Dict[str, Any]:
        """存储记忆"""
        return self.call_mcp_tool("store_memory", {
            "key": key,
            "value": value,
            "category": category
        })
    
    def retrieve_memory(self, key: str) -> Dict[str, Any]:
        """检索记忆"""
        return self.call_mcp_tool("retrieve_memory", {"key": key})
    
    def search_memories(self, query: str, category: str = None) -> Dict[str, Any]:
        """搜索记忆"""
        args = {"query": query}
        if category:
            args["category"] = category
        return self.call_mcp_tool("search_memories", args)
    
    def process_conversation(self, user_input: str, ai_response: str = None) -> Dict[str, Any]:
        """处理对话"""
        args = {"user_input": user_input}
        if ai_response:
            args["ai_response"] = ai_response
        return self.call_mcp_tool("process_conversation", args)
    
    def recall_memory(self, question: str, context: List[str] = None) -> Dict[str, Any]:
        """回忆记忆"""
        args = {"question": question}
        if context:
            args["context"] = context
        return self.call_mcp_tool("recall_memory", args)
    
    def list_all_memories(self) -> Dict[str, Any]:
        """列出所有记忆"""
        return self.call_mcp_tool("list_all_memories", {})
    
    def delete_memory(self, key: str) -> Dict[str, Any]:
        """删除记忆"""
        return self.call_mcp_tool("delete_memory", {"key": key})

# 使用示例
def example_usage():
    """使用示例"""
    client = SharedMemoryClient()
    
    # 存储记忆
    result = client.store_memory("test_key", "测试记忆内容")
    print("存储结果:", result)
    
    # 检索记忆
    result = client.retrieve_memory("test_key")
    print("检索结果:", result)
    
    # 处理对话
    result = client.process_conversation("我叫张三", "很高兴认识您，张三！")
    print("对话处理:", result)
    
    # 回忆记忆
    result = client.recall_memory("我叫什么名字？")
    print("回忆结果:", result)

if __name__ == "__main__":
    example_usage()
