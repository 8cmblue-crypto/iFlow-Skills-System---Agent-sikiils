#!/usr/bin/env python3
"""
Skills记忆同步服务端
提供HTTP API接收和同步skills记忆数据
"""

import json
import time
import threading
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
from datetime import datetime
from pathlib import Path
import sys
import os

# 添加当前目录到路径
sys.path.insert(0, str(Path(__file__).parent))

from skills_memory_receiver import SkillsMemoryReceiver

class MemoryAPIHandler(BaseHTTPRequestHandler):
    """记忆API请求处理器"""
    
    def __init__(self, *args, receiver=None, **kwargs):
        self.receiver = receiver
        super().__init__(*args, **kwargs)
    
    def do_GET(self):
        """处理GET请求"""
        parsed_path = urlparse(self.path)
        path = parsed_path.path
        query_params = parse_qs(parsed_path.query)
        
        try:
            if path == "/health":
                self._send_response({"status": "ok", "timestamp": datetime.now().isoformat()})
            
            elif path == "/stats":
                stats = self.receiver.get_memory_stats()
                self._send_response(stats)
            
            elif path == "/search":
                query = query_params.get("q", [None])[0]
                category = query_params.get("category", [None])[0]
                source = query_params.get("source", [None])[0]
                tags = query_params.get("tags", [None])[0]
                limit = int(query_params.get("limit", [50])[0])
                
                tag_list = tags.split(",") if tags else None
                results = self.receiver.search_memory(query, category, source, tag_list, limit)
                self._send_response({"results": results, "total": len(results)})
            
            elif path == "/export":
                category = query_params.get("category", [None])[0]
                result = self.receiver.export_memory(category=category)
                if result["success"]:
                    self._send_response(result)
                else:
                    self._send_error(500, result["error"])
            
            else:
                self._send_error(404, "API endpoint not found")
        
        except Exception as e:
            self._send_error(500, str(e))
    
    def do_POST(self):
        """处理POST请求"""
        parsed_path = urlparse(self.path)
        path = parsed_path.path
        
        try:
            content_length = int(self.headers["Content-Length"])
            post_data = self.rfile.read(content_length).decode("utf-8")
            
            if path == "/receive":
                data = json.loads(post_data)
                
                # 验证必需字段
                required_fields = ["content"]
                for field in required_fields:
                    if field not in data:
                        self._send_error(400, f"Missing required field: {field}")
                        return
                
                # 接收记忆
                result = self.receiver.receive_memory(
                    content=data["content"],
                    category=data.get("category", "skills"),
                    source=data.get("source", "api"),
                    tags=data.get("tags", []),
                    metadata=data.get("metadata", {})
                )
                
                if result["success"]:
                    self._send_response(result)
                else:
                    self._send_error(400, result["error"])
            
            elif path == "/batch_receive":
                data = json.loads(post_data)
                memories = data.get("memories", [])
                
                results = []
                for memory in memories:
                    result = self.receiver.receive_memory(
                        content=memory["content"],
                        category=memory.get("category", "skills"),
                        source=memory.get("source", "api"),
                        tags=memory.get("tags", []),
                        metadata=memory.get("metadata", {})
                    )
                    results.append(result)
                
                success_count = sum(1 for r in results if r["success"])
                self._send_response({
                    "total": len(results),
                    "success": success_count,
                    "failed": len(results) - success_count,
                    "results": results
                })
            
            else:
                self._send_error(404, "API endpoint not found")
        
        except json.JSONDecodeError:
            self._send_error(400, "Invalid JSON data")
        except Exception as e:
            self._send_error(500, str(e))
    
    def do_DELETE(self):
        """处理DELETE请求"""
        parsed_path = urlparse(self.path)
        path = parsed_path.path
        
        try:
            if path == "/cleanup":
                query_params = parse_qs(parsed_path.query)
                days = int(query_params.get("days", [30])[0])
                
                result = self.receiver.cleanup_old_memories(days)
                self._send_response(result)
            
            else:
                self._send_error(404, "API endpoint not found")
        
        except Exception as e:
            self._send_error(500, str(e))
    
    def _send_response(self, data, status_code=200):
        """发送响应"""
        self.send_response(status_code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()
        
        response_data = json.dumps(data, ensure_ascii=False, indent=2)
        self.wfile.write(response_data.encode("utf-8"))
    
    def _send_error(self, status_code, message):
        """发送错误响应"""
        error_data = {
            "error": True,
            "status_code": status_code,
            "message": message,
            "timestamp": datetime.now().isoformat()
        }
        self._send_response(error_data, status_code)
    
    def do_OPTIONS(self):
        """处理OPTIONS请求（CORS预检）"""
        self.send_response(200)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()
    
    def log_message(self, format, *args):
        """自定义日志格式"""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        print(f"[{timestamp}] {format % args}")

class SkillsMemoryServer:
    """Skills记忆服务器"""
    
    def __init__(self, host="localhost", port=8888, iflow_root=None):
        self.host = host
        self.port = port
        self.receiver = SkillsMemoryReceiver(iflow_root)
        self.server = None
        self.server_thread = None
    
    def start(self):
        """启动服务器"""
        try:
            # 创建处理器工厂
            def handler_factory(*args, **kwargs):
                return MemoryAPIHandler(*args, receiver=self.receiver, **kwargs)
            
            # 创建服务器
            self.server = HTTPServer((self.host, self.port), handler_factory)
            
            # 在单独线程中启动服务器
            self.server_thread = threading.Thread(target=self.server.serve_forever)
            self.server_thread.daemon = True
            self.server_thread.start()
            
            print(f"🚀 Skills记忆服务器启动成功!")
            print(f"   服务地址: http://{self.host}:{self.port}")
            print(f"   API文档:")
            print(f"     GET  /health      - 健康检查")
            print(f"     GET  /stats       - 记忆统计")
            print(f"     GET  /search      - 搜索记忆")
            print(f"     POST /receive     - 接收单条记忆")
            print(f"     POST /batch_receive - 批量接收记忆")
            print(f"     GET  /export      - 导出记忆")
            print(f"     DELETE /cleanup    - 清理旧记忆")
            
            return True
            
        except Exception as e:
            print(f"❌ 服务器启动失败: {e}")
            return False
    
    def stop(self):
        """停止服务器"""
        if self.server:
            self.server.shutdown()
            self.server.server_close()
            if self.server_thread:
                self.server_thread.join()
            print("🛑 Skills记忆服务器已停止")
    
    def is_running(self):
        """检查服务器是否运行中"""
        return self.server is not None and self.server_thread.is_alive()

def main():
    """主函数"""
    import argparse
    
    parser = argparse.ArgumentParser(description="Skills记忆同步服务器")
    parser.add_argument("--host", default="localhost", help="服务器主机地址")
    parser.add_argument("--port", type=int, default=8888, help="服务器端口")
    parser.add_argument("--iflow-root", help="iFlow根目录路径")
    
    args = parser.parse_args()
    
    # 创建并启动服务器
    server = SkillsMemoryServer(args.host, args.port, args.iflow_root)
    
    if server.start():
        try:
            print("按 Ctrl+C 停止服务器...")
            while server.is_running():
                time.sleep(1)
        except KeyboardInterrupt:
            print("\n收到停止信号...")
        finally:
            server.stop()
    else:
        print("❌ 服务器启动失败")
        sys.exit(1)

if __name__ == "__main__":
    main()