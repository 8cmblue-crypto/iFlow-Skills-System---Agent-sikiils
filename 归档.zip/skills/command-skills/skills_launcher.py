#!/usr/bin/env python3
"""
Skills一键启动脚本
自动扫描、配置并启动所有可用技能
"""

import sys
import subprocess
from pathlib import Path
from skills_manager import SkillsManager

def main():
    """一键启动所有skills"""
    print("🚀 Skills一键启动系统")
    print("=" * 50)
    
    # 1. 初始化skills管理器
    manager = SkillsManager()
    
    # 2. 自动加载所有技能配置
    print("📡 正在扫描和加载技能配置...")
    result = manager.auto_load_all_skills()
    
    if result['total_skills'] == 0:
        print("❌ 未发现任何skills")
        return
    
    print(f"✅ 发现 {result['total_skills']} 个技能")
    print(f"📊 成功加载: {len(result['loaded_skills'])} 个")
    
    if result['failed_skills']:
        print(f"⚠️ 加载失败: {len(result['failed_skills'])} 个")
        for failed in result['failed_skills']:
            print(f"   • {failed['skill']}: {failed['error']}")
    
    print("\n🎯 技能详情:")
    
    # 3. 显示每个技能的详细信息
    for skill in result['loaded_skills']:
        skill_name = skill['skill']
        info = manager.get_skill_info(skill_name)
        
        print(f"\n🔸 {info['name']} v{info['version']}")
        print(f"   📝 描述: {info['description']}")
        print(f"   📁 路径: {info['path']}")
        print(f"   🔧 脚本: {len(info['scripts'])} 个")
        
        # 4. 检查技能状态
        if skill_name == 'context-compressor':
            print("   ✅ 状态检查中...")
            try:
                status_cmd = [
                    'python3', 
                    str(Path(info['path']) / 'scripts' / 'enhanced_compressor.py'), 
                    'status'
                ]
                result = subprocess.run(status_cmd, capture_output=True, text=True, timeout=10)
                if result.returncode == 0:
                    print("   ✅ 上下文压缩系统运行正常")
                else:
                    print("   ⚠️ 上下文压缩系统状态异常")
            except Exception as e:
                print(f"   ❌ 状态检查失败: {str(e)}")
        
        elif skill_name == 'shared-memory-system':
            print("   ✅ 记忆系统已就绪")
            
        elif skill_name == 'context-monitor':
            print("   ✅ 上下文监控系统已就绪")
    
    # 5. 生成快速使用指南
    print("\n" + "=" * 50)
    print("📖 快速使用指南:")
    print()
    
    # 上下文压缩使用
    print("🔧 上下文压缩:")
    print("   python3 skills/context-compressor/scripts/enhanced_compressor.py status")
    print("   python3 skills/context-compressor/scripts/enhanced_compressor.py compress --input file.json --auto-reload")
    print("   python3 iflow_context_controller.py list")
    print()
    
    # 记忆系统使用
    print("🧠 记忆系统:")
    print("   python3 skills/shared-memory-system/scripts/memory_skill.py")
    print("   python3 memory_mcp_client.py store_memory '{\"key\": \"test\", \"value\": \"数据\"}'")
    print()
    
    # 上下文监控使用
    print("📊 上下文监控:")
    print("   python3 skills/context-monitor/scripts/monitor.py")
    print("   python3 skills/context-monitor/scripts/token_counter.py --input file.json")
    print()
    
    print("🎉 所有skills已自动配置完成！")
    print("💡 技能移动到skills目录即可自动发现和配置")

if __name__ == "__main__":
    main()