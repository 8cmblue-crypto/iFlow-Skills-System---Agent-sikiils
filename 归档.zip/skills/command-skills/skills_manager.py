#!/usr/bin/env python3
"""
Skills自动配置和加载管理器
自动扫描skills目录，加载所有可用技能的配置
"""

import json
import os
import sys
from pathlib import Path
from typing import Dict, List, Any
from datetime import datetime

class SkillsManager:
    def __init__(self, skills_root: str = None):
        if skills_root is None:
            self.skills_root = Path(__file__).parent / "skills"
        else:
            self.skills_root = Path(skills_root)
        
        self.loaded_skills = {}
        self.skill_configs = {}
        
    def scan_skills_directory(self) -> List[str]:
        """扫描skills目录，返回所有可用的技能名称"""
        skills = []
        if self.skills_root.exists():
            for item in self.skills_root.iterdir():
                if item.is_dir() and (item / "assets" / "config.json").exists():
                    skills.append(item.name)
        return skills
    
    def load_skill_config(self, skill_name: str) -> Dict[str, Any]:
        """加载指定技能的配置"""
        config_file = self.skills_root / skill_name / "assets" / "config.json"
        
        if not config_file.exists():
            return {"error": f"技能配置文件不存在: {config_file}"}
        
        try:
            with open(config_file, 'r', encoding='utf-8') as f:
                config = json.load(f)
            
            # 添加技能元信息
            config["skill_name"] = skill_name
            config["skill_path"] = str(self.skills_root / skill_name)
            config["loaded_at"] = datetime.now().isoformat()
            
            return config
        except Exception as e:
            return {"error": f"加载配置失败: {str(e)}"}
    
    def auto_load_all_skills(self) -> Dict[str, Any]:
        """自动加载所有可用技能"""
        skills = self.scan_skills_directory()
        
        results = {
            "total_skills": len(skills),
            "loaded_skills": [],
            "failed_skills": [],
            "timestamp": datetime.now().isoformat()
        }
        
        for skill_name in skills:
            config = self.load_skill_config(skill_name)
            
            if "error" in config:
                results["failed_skills"].append({
                    "skill": skill_name,
                    "error": config["error"]
                })
            else:
                self.skill_configs[skill_name] = config
                results["loaded_skills"].append({
                    "skill": skill_name,
                    "name": config.get("name", skill_name),
                    "version": config.get("version", "unknown"),
                    "description": config.get("description", "")
                })
        
        return results
    
    def get_skill_info(self, skill_name: str) -> Dict[str, Any]:
        """获取指定技能的详细信息"""
        if skill_name not in self.skill_configs:
            config = self.load_skill_config(skill_name)
            if "error" in config:
                return config
            self.skill_configs[skill_name] = config
        
        config = self.skill_configs[skill_name]
        
        # 获取技能脚本信息
        scripts_dir = Path(config["skill_path"]) / "scripts"
        scripts = []
        if scripts_dir.exists():
            for script_file in scripts_dir.glob("*.py"):
                scripts.append(script_file.name)
        
        return {
            "name": config.get("name", skill_name),
            "version": config.get("version", "unknown"),
            "description": config.get("description", ""),
            "path": config["skill_path"],
            "scripts": scripts,
            "config": config,
            "loaded_at": config.get("loaded_at")
        }
    
    def list_all_skills(self) -> Dict[str, Any]:
        """列出所有技能的基本信息"""
        auto_load_result = self.auto_load_all_skills()
        
        return {
            "skills_count": auto_load_result["total_skills"],
            "skills": [
                {
                    "name": skill["name"],
                    "skill": skill["skill"],
                    "version": skill["version"],
                    "description": skill["description"]
                }
                for skill in auto_load_result["loaded_skills"]
            ],
            "failed": auto_load_result["failed_skills"],
            "timestamp": auto_load_result["timestamp"]
        }

def main():
    """主函数 - 演示skills管理器功能"""
    manager = SkillsManager()
    
    print("🔧 Skills自动配置和加载管理器")
    print("=" * 50)
    
    # 自动加载所有技能
    result = manager.auto_load_all_skills()
    
    print(f"📊 扫描结果: 发现 {result['total_skills']} 个技能")
    print(f"✅ 成功加载: {len(result['loaded_skills'])} 个")
    print(f"❌ 加载失败: {len(result['failed_skills'])} 个")
    print()
    
    # 显示成功加载的技能
    if result['loaded_skills']:
        print("🎯 已加载的技能:")
        for skill in result['loaded_skills']:
            print(f"  • {skill['name']} v{skill['version']} - {skill['description']}")
        print()
    
    # 显示加载失败的技能
    if result['failed_skills']:
        print("⚠️ 加载失败的技能:")
        for failed in result['failed_skills']:
            print(f"  • {failed['skill']}: {failed['error']}")
        print()
    
    # 显示详细技能信息
    print("📋 技能详细信息:")
    all_skills = manager.list_all_skills()
    for skill in all_skills['skills']:
        info = manager.get_skill_info(skill['skill'])
        print(f"\n🔸 {info['name']}")
        print(f"   版本: {info['version']}")
        print(f"   描述: {info['description']}")
        print(f"   脚本: {', '.join(info['scripts'])}")
        print(f"   路径: {info['path']}")

if __name__ == "__main__":
    main()