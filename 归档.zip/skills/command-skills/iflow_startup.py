#!/usr/bin/env python3
"""
iFlow启动脚本 - 自动加载所有skills
"""

def load_skills_on_startup():
    """iFlow启动时自动加载skills"""
    try:
        # 导入必要的模块
        from pathlib import Path
        import json
        from datetime import datetime
        
        # 导入并运行技能加载测试
        exec(open('test_skills_load.py').read())
        
        # 将已加载的技能注册到全局变量
        import builtins
        builtins.IFLOW_SKILLS_LOADED = True
        
        print("\n🎯 iFlow启动完成 - 所有skills已自动加载")
        print("💡 新技能移动到skills目录即可自动发现")
        
        return True
        
    except Exception as e:
        print(f"❌ Skills自动加载失败: {str(e)}")
        return False

# iFlow启动时调用
if __name__ == "__main__":
    load_skills_on_startup()