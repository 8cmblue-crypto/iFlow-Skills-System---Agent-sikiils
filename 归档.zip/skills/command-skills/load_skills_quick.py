#!/usr/bin/env python3
"""
iFlow技能一键快速加载脚本
为AI对话场景提供最优的技能加载体验
"""

import sys
import time
from pathlib import Path

# 添加当前目录到Python路径
sys.path.insert(0, str(Path(__file__).parent))

from quick_skills_loader import QuickSkillsLoader

def print_banner():
    """显示加载横幅"""
    print("⚡ iFlow技能快速加载系统")
    print("=" * 50)
    print("🚀 为AI对话场景优化的极速加载器")
    print()

def load_skills_with_progress():
    """带进度显示的技能加载"""
    loader = QuickSkillsLoader()
    
    print("📡 正在快速加载技能...")
    start_time = time.time()
    
    result = loader.load_skills()
    load_time = time.time() - start_time
    
    # 显示加载结果
    if result['cache_hit']:
        print("⚡ 使用缓存超快加载!")
    else:
        print("📡 扫描并加载技能...")
    
    print(f"✅ 加载完成! 耗时: {load_time:.4f}秒")
    print(f"📊 总技能数: {result['total_skills']}")
    print(f"✅ 成功: {len(result['loaded_skills'])}")
    print(f"❌ 失败: {len(result['failed_skills'])}")
    
    if result['loaded_skills']:
        print("\n🎯 已加载技能:")
        for i, skill in enumerate(result['loaded_skills'], 1):
            print(f"  {i}. {skill['skill']} v{skill['version']}")
            if skill['description']:
                print(f"     📝 {skill['description']}")
    
    if result['failed_skills']:
        print("\n⚠️ 加载失败的技能:")
        for failed in result['failed_skills']:
            print(f"  ❌ {failed['skill']}: {failed['error']}")
    
    return loader, result

def show_quick_guide():
    """显示快速使用指南"""
    print("\n" + "=" * 50)
    print("📖 快速使用指南")
    print("=" * 50)
    
    print("\n🔧 技能快速加载:")
    print("   python3 load_skills_quick.py              # 快速加载")
    print("   python3 load_skills_quick.py reload       # 强制重新加载")
    print("   python3 load_skills_quick.py status       # 查看缓存状态")
    print("   python3 load_skills_quick.py clear        # 清理缓存")
    
    print("\n🎯 核心技能使用:")
    print("   📊 上下文监控:")
    print("      python3 skills/context-monitor/scripts/monitor.py")
    print("   🗜️ 上下文压缩:")
    print("      python3 skills/context-compressor/scripts/enhanced_compressor.py status")
    print("   🧠 记忆系统:")
    print("      python3 skills/shared-memory-system/scripts/memory_skill.py")
    print("   🤖 子Agent管理:")
    print("      python3 skills/subagent-manager/scripts/subagent_manager.py")
    print("   🎯 任务协调:")
    print("      python3 skills/task-coordinator/scripts/task_coordinator.py")
    
    print("\n💡 性能优化:")
    print("   • 首次加载会扫描所有技能并建立缓存")
    print("   • 后续加载使用缓存，速度提升90%+")
    print("   • 技能文件更新后自动失效缓存")
    print("   • 支持并行加载，充分利用多核CPU")

def main():
    """主函数"""
    print_banner()
    
    # 处理命令行参数
    if len(sys.argv) > 1:
        command = sys.argv[1]
        loader = QuickSkillsLoader()
        
        if command == "reload":
            print("🔄 强制重新加载技能...")
            result = loader.load_skills(force_reload=True)
            print(f"✅ 重新加载完成! 耗时: {result['load_time']:.4f}秒")
            print(f"📊 总技能数: {result['total_skills']}, 成功: {len(result['loaded_skills'])}")
            
        elif command == "status":
            status = loader.get_cache_status()
            print("📊 缓存状态:")
            print(f"   快速缓存: {'✅ 有效' if status['quick_cache_valid'] else '❌ 无效/过期'}")
            print(f"   缓存文件数: {status['cache_files_count']}")
            print(f"   总大小: {status['total_cache_size_kb']:.2f} KB")
            print(f"   内存缓存: {'✅ 已加载' if status['internal_cache_loaded'] else '❌ 未加载'}")
            
        elif command == "clear":
            print("🧹 清理缓存...")
            loader.clear_cache()
            
        elif command == "help":
            show_quick_guide()
            
        else:
            print(f"❌ 未知命令: {command}")
            print("💡 可用命令: reload, status, clear, help")
            return 1
    else:
        # 默认快速加载
        try:
            loader, result = load_skills_with_progress()
            
            # 显示性能提示
            if result['load_time'] > 0.01:
                print(f"\n💡 下次加载将更快 (缓存已建立)")
            else:
                print(f"\n⚡ 极速加载! (使用缓存)")
            
            # 显示快速指南
            show_quick_guide()
            
        except KeyboardInterrupt:
            print("\n⚠️ 用户取消加载")
            return 1
        except Exception as e:
            print(f"\n❌ 加载失败: {e}")
            return 1
    
    return 0

if __name__ == "__main__":
    sys.exit(main())