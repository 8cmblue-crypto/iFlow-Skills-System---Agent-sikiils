#!/usr/bin/env python3
"""
iFlow技能快速加载器 - 优化版
专为AI对话场景设计，提供最快、最稳定的技能加载体验
"""

import json
import os
import sys
import time
import pickle
import hashlib
from pathlib import Path
from typing import Dict, List, Any, Optional
from datetime import datetime, timedelta
from functools import lru_cache
import concurrent.futures

class QuickSkillsLoader:
    """快速技能加载器 - 专为AI对话优化"""
    
    def __init__(self, iflow_root: str = None):
        self.iflow_root = Path(iflow_root) if iflow_root else Path(__file__).parent
        self.skills_dir = self.iflow_root / "skills"
        self.cache_dir = self.iflow_root / ".skills_cache"
        self.cache_dir.mkdir(exist_ok=True)
        
        # 快速加载配置
        self.quick_cache_file = self.cache_dir / "quick_skills_cache.pkl"
        self.cache_ttl = 3600  # 1小时缓存有效期
        self.max_workers = min(4, os.cpu_count() or 2)
        
        # 预加载技能缓存
        self._skills_cache = None
        self._cache_timestamp = None
        
    def _get_quick_cache_key(self) -> str:
        """生成快速缓存键"""
        # 基于skills目录的修改时间生成缓存键
        try:
            latest_mtime = 0
            for item in self.skills_dir.rglob("*"):
                if item.is_file():
                    latest_mtime = max(latest_mtime, item.stat().st_mtime)
            
            cache_key = f"skills_{latest_mtime}_{len(list(self.skills_dir.iterdir()))}"
            return hashlib.md5(cache_key.encode()).hexdigest()
        except:
            return "fallback_cache_key"
    
    def _is_quick_cache_valid(self) -> bool:
        """检查快速缓存是否有效"""
        if not self.quick_cache_file.exists():
            return False
        
        try:
            cache_mtime = self.quick_cache_file.stat().st_mtime
            cache_age = time.time() - cache_mtime
            
            if cache_age > self.cache_ttl:
                return False
            
            # 检查skills目录是否有更新
            cache_key = self._get_quick_cache_key()
            with open(self.quick_cache_file, 'rb') as f:
                cache_data = pickle.load(f)
                return cache_data.get('cache_key') == cache_key
                
        except Exception:
            return False
    
    def _save_quick_cache(self, skills_data: Dict[str, Any]):
        """保存快速缓存"""
        try:
            cache_data = {
                'cache_key': self._get_quick_cache_key(),
                'timestamp': time.time(),
                'skills_data': skills_data
            }
            
            with open(self.quick_cache_file, 'wb') as f:
                pickle.dump(cache_data, f, protocol=pickle.HIGHEST_PROTOCOL)
                
        except Exception as e:
            print(f"⚠️ 缓存保存失败: {e}")
    
    def _load_quick_cache(self) -> Optional[Dict[str, Any]]:
        """加载快速缓存"""
        try:
            with open(self.quick_cache_file, 'rb') as f:
                cache_data = pickle.load(f)
                return cache_data.get('skills_data')
        except Exception:
            return None
    
    def _load_single_skill_config(self, skill_name: str) -> tuple:
        """加载单个技能配置（用于并行处理）"""
        try:
            config_file = self.skills_dir / skill_name / "assets" / "config.json"
            
            if not config_file.exists():
                return skill_name, {"error": f"配置文件不存在: {config_file}"}
            
            with open(config_file, 'r', encoding='utf-8') as f:
                config = json.load(f)
            
            # 添加元信息
            config.update({
                "skill_name": skill_name,
                "skill_path": str(self.skills_dir / skill_name),
                "loaded_at": datetime.now().isoformat()
            })
            
            return skill_name, config
            
        except Exception as e:
            return skill_name, {"error": f"加载失败: {str(e)}"}
    
    def _scan_skills_fast(self) -> List[str]:
        """快速扫描技能目录"""
        skills = []
        try:
            for item in self.skills_dir.iterdir():
                if item.is_dir() and (item / "assets" / "config.json").exists():
                    skills.append(item.name)
        except Exception as e:
            print(f"⚠️ 扫描技能目录失败: {e}")
        
        return skills
    
    def load_skills(self, force_reload: bool = False) -> Dict[str, Any]:
        """快速加载所有技能"""
        start_time = time.time()
        
        # 检查快速缓存
        if not force_reload and self._is_quick_cache_valid():
            cached_data = self._load_quick_cache()
            if cached_data:
                load_time = time.time() - start_time
                cached_data['load_time'] = load_time
                cached_data['cache_hit'] = True
                return cached_data
        
        # 执行实际加载
        skills = self._scan_skills_fast()
        
        result = {
            "total_skills": len(skills),
            "loaded_skills": [],
            "failed_skills": [],
            "timestamp": datetime.now().isoformat(),
            "cache_hit": False
        }
        
        if not skills:
            result['load_time'] = time.time() - start_time
            return result
        
        # 并行加载技能配置
        skills_data = {}
        with concurrent.futures.ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            future_to_skill = {
                executor.submit(self._load_single_skill_config, skill_name): skill_name
                for skill_name in skills
            }
            
            for future in concurrent.futures.as_completed(future_to_skill):
                skill_name, config = future.result()
                
                if "error" in config:
                    result["failed_skills"].append({
                        "skill": skill_name,
                        "error": config["error"]
                    })
                else:
                    skills_data[skill_name] = config
                    result["loaded_skills"].append({
                        "skill": skill_name,
                        "name": config.get("name", skill_name),
                        "version": config.get("version", "unknown"),
                        "description": config.get("description", "")
                    })
        
        # 保存到快速缓存
        self._save_quick_cache(skills_data)
        
        # 更新内部缓存
        self._skills_cache = skills_data
        self._cache_timestamp = time.time()
        
        result['load_time'] = time.time() - start_time
        result['skills_data'] = skills_data
        
        return result
    
    def get_skill_info(self, skill_name: str) -> Dict[str, Any]:
        """获取技能信息"""
        # 优先从缓存获取
        if self._skills_cache and skill_name in self._skills_cache:
            return self._skills_cache[skill_name]
        
        # 从快速缓存获取
        if not self._is_quick_cache_valid():
            self.load_skills()
        
        if self._skills_cache and skill_name in self._skills_cache:
            return self._skills_cache[skill_name]
        
        # 实时加载
        _, config = self._load_single_skill_config(skill_name)
        return config
    
    def list_skills(self) -> List[str]:
        """列出所有可用技能"""
        return self._scan_skills_fast()
    
    def clear_cache(self):
        """清理缓存"""
        try:
            if self.quick_cache_file.exists():
                self.quick_cache_file.unlink()
            
            # 清理旧缓存文件
            cache_files = list(self.cache_dir.glob("*.cache"))
            if len(cache_files) > 50:  # 保留最新50个文件
                cache_files.sort(key=lambda f: f.stat().st_mtime, reverse=True)
                for old_cache in cache_files[50:]:
                    old_cache.unlink()
            
            self._skills_cache = None
            self._cache_timestamp = None
            
            print("✅ 缓存已清理")
            
        except Exception as e:
            print(f"⚠️ 清理缓存失败: {e}")
    
    def get_cache_status(self) -> Dict[str, Any]:
        """获取缓存状态"""
        cache_files = list(self.cache_dir.glob("*.cache"))
        total_size = sum(f.stat().st_size for f in cache_files)
        
        return {
            "quick_cache_exists": self.quick_cache_file.exists(),
            "quick_cache_valid": self._is_quick_cache_valid(),
            "cache_files_count": len(cache_files),
            "total_cache_size_kb": total_size / 1024,
            "internal_cache_loaded": self._skills_cache is not None
        }

def main():
    """命令行入口"""
    loader = QuickSkillsLoader()
    
    if len(sys.argv) > 1:
        command = sys.argv[1]
        
        if command == "status":
            status = loader.get_cache_status()
            print("📊 缓存状态:")
            print(f"   快速缓存存在: {'✅' if status['quick_cache_exists'] else '❌'}")
            print(f"   快速缓存有效: {'✅' if status['quick_cache_valid'] else '❌'}")
            print(f"   缓存文件数: {status['cache_files_count']}")
            print(f"   总缓存大小: {status['total_cache_size_kb']:.2f} KB")
            print(f"   内部缓存已加载: {'✅' if status['internal_cache_loaded'] else '❌'}")
            
        elif command == "clear":
            loader.clear_cache()
            
        elif command == "reload":
            result = loader.load_skills(force_reload=True)
            print(f"🔄 强制重新加载完成:")
            print(f"   总技能数: {result['total_skills']}")
            print(f"   成功: {len(result['loaded_skills'])}")
            print(f"   失败: {len(result['failed_skills'])}")
            print(f"   耗时: {result['load_time']:.4f}秒")
            
        else:
            print("❌ 未知命令。可用命令: status, clear, reload")
    else:
        # 默认加载技能
        result = loader.load_skills()
        
        if result['cache_hit']:
            print("⚡ 使用缓存快速加载!")
        else:
            print("📡 扫描并加载技能...")
        
        print(f"✅ 加载完成! 耗时: {result['load_time']:.4f}秒")
        print(f"📊 总技能数: {result['total_skills']}")
        print(f"✅ 成功: {len(result['loaded_skills'])}")
        print(f"❌ 失败: {len(result['failed_skills'])}")
        
        if result['loaded_skills']:
            print("\n🎯 已加载技能:")
            for skill in result['loaded_skills'][:5]:  # 只显示前5个
                print(f"  • {skill['skill']} v{skill['version']}")
                if skill['description']:
                    print(f"    {skill['description']}")
            
            if len(result['loaded_skills']) > 5:
                print(f"  ... 还有 {len(result['loaded_skills']) - 5} 个技能")

if __name__ == "__main__":
    main()