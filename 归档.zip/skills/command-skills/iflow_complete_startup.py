#!/usr/bin/env python3
"""
iFlow完整启动脚本 - 自动加载所有skills
"""

import json
from pathlib import Path
from datetime import datetime

def load_skills_on_startup():
    """iFlow启动时自动加载skills"""
    print("🚀 iFlow启动 - 自动加载Skills")
    print("=" * 50)
    
    # 扫描skills目录
    skills_dir = Path("skills")
    
    if not skills_dir.exists():
        print("❌ skills目录不存在")
        return False
    
    print(f"📁 扫描目录: {skills_dir}")
    
    # 查找所有有效技能
    valid_skills = []
    for skill_dir in skills_dir.iterdir():
        if not skill_dir.is_dir():
            continue
            
        # 检查必要文件
        skill_file = skill_dir / "SKILL.md"
        config_file = skill_dir / "assets" / "config.json"
        
        if skill_file.exists() and config_file.exists():
            valid_skills.append(skill_dir.name)
    
    print(f"📊 发现 {len(valid_skills)} 个技能")
    
    # 加载每个技能
    loaded_count = 0
    for skill_name in valid_skills:
        config_file = skills_dir / skill_name / "assets" / "config.json"
        
        try:
            with open(config_file, 'r', encoding='utf-8') as f:
                config = json.load(f)
            
            print(f"✅ {config.get('name', skill_name)} v{config.get('version', 'unknown')}")
            loaded_count += 1
            
        except Exception as e:
            print(f"❌ {skill_name}: {str(e)}")
    
    print(f"\n🎉 Skills加载完成: {loaded_count}/{len(valid_skills)}")
    print("💡 新技能移动到skills目录即可自动发现")
    
    # 设置全局标志
    import builtins
    builtins.IFLOW_SKILLS_LOADED = True
    builtins.IFLOW_SKILLS_COUNT = loaded_count
    
    return loaded_count > 0

if __name__ == "__main__":
    success = load_skills_on_startup()
    if success:
        print("\n✅ iFlow启动成功 - 所有skills已就绪")
    else:
        print("\n⚠️ iFlow启动完成 - 部分skills加载失败")